/* Disciplina: Técnicas de Policiamento Ostensivo (62 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz01-001",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "alterações fisiológicas e funções mentais",
  "enunciado": "Os estados de prontidão são definidos por um conjunto de alterações:",
  "alts": [
   {
    "t": "exclusivamente musculares, ligadas ao porte físico do policial."
   },
   {
    "t": "somente tecnológicas, relacionadas ao armamento disponível."
   },
   {
    "t": "fisiológicas (frequência cardíaca, ritmo respiratório) e das funções mentais (atenção, percepção, emotividade).",
    "ok": true
   },
   {
    "t": "apenas administrativas, definidas pela patente do militar."
   }
  ],
  "resolucao": "==Gabarito: fisiológicas (frequência cardíaca, ritmo respiratório) e das funções mentais (atenção, percepção, emotividade).== Tópico 2 — alterações fisiológicas e funções mentais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, alterações fisiológicas e funções mentais"
 },
 {
  "id": "bz01-002",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "fatores condicionantes",
  "enunciado": "Entre os fatores subjetivos que condicionam o estado de prontidão de cada policial estão:",
  "alts": [
   {
    "t": "a cor da viatura e o horário do serviço."
   },
   {
    "t": "experiências anteriores, domínio técnico e relacionamento com a equipe de trabalho.",
    "ok": true
   },
   {
    "t": "o número de multas aplicadas no mês."
   },
   {
    "t": "a idade do suspeito e o tipo de arma apreendida."
   }
  ],
  "resolucao": "==Gabarito: experiências anteriores, domínio técnico e relacionamento com a equipe de trabalho.== Tópico 2 — fatores condicionantes.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, fatores condicionantes"
 },
 {
  "id": "bz01-003",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Estado relaxado (branco)",
  "enunciado": "O estado relaxado, de cor BRANCA, caracteriza-se por:",
  "alts": [
   {
    "t": "sobrecarga física e emocional diante de ameaça desconhecida."
   },
   {
    "t": "atenção difusa em 360°, com vigilância constante."
   },
   {
    "t": "atenção concentrada na ameaça, com resposta necessária."
   },
   {
    "t": "distração em relação ao que acontece ao redor, pensamento disperso e relaxamento psíquico.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: distração em relação ao que acontece ao redor, pensamento disperso e relaxamento psíquico.== Tópico 2.1 — Estado relaxado (branco).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Estado relaxado (branco)"
 },
 {
  "id": "bz01-004",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 2.1",
  "enunciado": "Um policial em patrulhamento que escuta música com fone de ouvido encontra-se, segundo a doutrina, no estado de prontidão de cor:",
  "alts": [
   {
    "t": "laranja."
   },
   {
    "t": "branca.",
    "ok": true
   },
   {
    "t": "vermelha."
   },
   {
    "t": "amarela."
   }
  ],
  "resolucao": "==Gabarito: branca.== Tópico 2.1 — o fone de ouvido desvia a atenção e coloca todos em risco.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 2.1"
 },
 {
  "id": "bz01-005",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Estado de atenção (amarelo)",
  "enunciado": "A observação multidirecional e a atenção difusa (360°) são características do estado de:",
  "alts": [
   {
    "t": "pânico — cor preta."
   },
   {
    "t": "relaxado — cor branca."
   },
   {
    "t": "atenção — cor amarela.",
    "ok": true
   },
   {
    "t": "alerta — cor laranja."
   }
  ],
  "resolucao": "==Gabarito: atenção — cor amarela.== Tópico 2.2 — Estado de atenção (amarelo).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Estado de atenção (amarelo)"
 },
 {
  "id": "bz01-006",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "exemplo de estado amarelo",
  "enunciado": "O policial que se desloca fardado ou à paisana durante a folga, atento ao ambiente mas sem tensão, está no estado:",
  "alts": [
   {
    "t": "de atenção — amarelo.",
    "ok": true
   },
   {
    "t": "de alarme — vermelho."
   },
   {
    "t": "de pânico — preto."
   },
   {
    "t": "relaxado — branco."
   }
  ],
  "resolucao": "==Gabarito: de atenção — amarelo.== Tópico 2.2 — exemplo de estado amarelo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, exemplo de estado amarelo"
 },
 {
  "id": "bz01-007",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Estado de alerta (laranja)",
  "enunciado": "No estado de alerta (laranja), o policial:",
  "alts": [
   {
    "t": "já precisa reagir de imediato à ameaça concentrada."
   },
   {
    "t": "está distraído e com o pensamento disperso."
   },
   {
    "t": "detecta um problema, sabe que um confronto é provável e calcula o nível de resposta adequado.",
    "ok": true
   },
   {
    "t": "perde o controle e atira de forma instintiva."
   }
  ],
  "resolucao": "==Gabarito: detecta um problema, sabe que um confronto é provável e calcula o nível de resposta adequado.== Tópico 2.3 — Estado de alerta (laranja).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Estado de alerta (laranja)"
 },
 {
  "id": "bz01-008",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "exemplo de estado laranja",
  "enunciado": "Um policial acionado via rádio para roubo à mão armada em sua região, deslocando-se para tentar a prisão, encontra-se no estado:",
  "alts": [
   {
    "t": "relaxado — branco."
   },
   {
    "t": "de pânico — preto."
   },
   {
    "t": "de atenção — amarelo."
   },
   {
    "t": "de alerta — laranja.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: de alerta — laranja.== Tópico 2.3 — exemplo de estado laranja.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, exemplo de estado laranja"
 },
 {
  "id": "bz01-009",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Estado de alarme (vermelho)",
  "enunciado": "No estado de alarme (vermelho), é importante:",
  "alts": [
   {
    "t": "aguardar o relaxamento psíquico da guarnição."
   },
   {
    "t": "manter atenção difusa em todo o perímetro, sem foco."
   },
   {
    "t": "evitar qualquer intervenção verbal."
   },
   {
    "t": "focalizar a ameaça (atenção concentrada) e ter em mente a ação adequada para controlá-la.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: focalizar a ameaça (atenção concentrada) e ter em mente a ação adequada para controlá-la.== Tópico 2.4 — Estado de alarme (vermelho).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Estado de alarme (vermelho)"
 },
 {
  "id": "bz01-010",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "exemplos do estado vermelho",
  "enunciado": "Perseguição a um veículo que acaba de ser tomado de assalto é exemplo de estado de prontidão:",
  "alts": [
   {
    "t": "relaxado — branco."
   },
   {
    "t": "de alerta — laranja."
   },
   {
    "t": "de alarme — vermelho.",
    "ok": true
   },
   {
    "t": "de atenção — amarelo."
   }
  ],
  "resolucao": "==Gabarito: de alarme — vermelho.== Tópico 2.4 — exemplos do estado vermelho.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, exemplos do estado vermelho"
 },
 {
  "id": "bz01-011",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Estado de pânico (preto)",
  "enunciado": "O estado de pânico (preto) ocorre quando o policial:",
  "alts": [
   {
    "t": "está em folga, almoçando com a família."
   },
   {
    "t": "calcula com serenidade o nível de resposta."
   },
   {
    "t": "interage tranquilamente com comerciantes."
   },
   {
    "t": "se depara com ameaça para a qual não está preparado ou se mantém em tensão por período muito prolongado.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: se depara com ameaça para a qual não está preparado ou se mantém em tensão por período muito prolongado.== Tópico 2.5 — Estado de pânico (preto).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Estado de pânico (preto)"
 },
 {
  "id": "bz01-012",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "exemplos do estado preto",
  "enunciado": "É exemplo de estado de pânico (preto) o policial que:",
  "alts": [
   {
    "t": "conversa com comerciantes durante o patrulhamento."
   },
   {
    "t": "verbaliza com firmeza e mantém o controle da ameaça."
   },
   {
    "t": "recebe o chamado de rádio e se desloca ao local."
   },
   {
    "t": "abandona o abrigo e atraca-se fisicamente com o agressor.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: abandona o abrigo e atraca-se fisicamente com o agressor.== Tópico 2.5 — exemplos do estado preto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, exemplos do estado preto"
 },
 {
  "id": "bz01-013",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "fontes de informação",
  "enunciado": "Para realizar bem o preparo mental, o policial deve estar munido do maior número de informações possíveis, que podem ser solicitadas:",
  "alts": [
   {
    "t": "apenas ao comandante do batalhão, por escrito."
   },
   {
    "t": "à Central de Operações, a transeuntes e a denunciantes.",
    "ok": true
   },
   {
    "t": "exclusivamente à imprensa local."
   },
   {
    "t": "somente ao suspeito, antes de abordá-lo."
   }
  ],
  "resolucao": "==Gabarito: à Central de Operações, a transeuntes e a denunciantes.== Tópico 3.1 — fontes de informação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, fontes de informação"
 },
 {
  "id": "bz01-014",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "finalidades do preparo mental",
  "enunciado": "Constitui finalidade do preparo mental:",
  "alts": [
   {
    "t": "reduzir a prontidão do policial para evitar tensão."
   },
   {
    "t": "dispensar o apoio da Central de Operações."
   },
   {
    "t": "avaliar a necessidade de apoio, considerando o número de pessoas, o local e o histórico de ocorrências.",
    "ok": true
   },
   {
    "t": "evitar a análise dos direitos e garantias fundamentais envolvidos."
   }
  ],
  "resolucao": "==Gabarito: avaliar a necessidade de apoio, considerando o número de pessoas, o local e o histórico de ocorrências.== Tópico 3.2 — finalidades do preparo mental.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, finalidades do preparo mental"
 },
 {
  "id": "bz01-015",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "conceito de risco",
  "enunciado": "Na doutrina de abordagem, risco é:",
  "alts": [
   {
    "t": "a probabilidade de concretização de uma ameaça contra pessoas e bens.",
    "ok": true
   },
   {
    "t": "o dano já consumado contra o patrimônio."
   },
   {
    "t": "a diferença entre o efetivo da equipe e o do suspeito."
   },
   {
    "t": "a certeza de que o suspeito está armado."
   }
  ],
  "resolucao": "==Gabarito: a probabilidade de concretização de uma ameaça contra pessoas e bens.== Tópico 4 — conceito de risco.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, conceito de risco"
 },
 {
  "id": "bz01-016",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 4",
  "enunciado": "A metodologia de avaliação de riscos compreende quantas etapas?",
  "alts": [
   {
    "t": "Cinco.",
    "ok": true
   },
   {
    "t": "Três."
   },
   {
    "t": "Sete."
   },
   {
    "t": "Dez."
   }
  ],
  "resolucao": "==Gabarito: Cinco.== Tópico 4 — cinco etapas (a classificação de risco, na etapa 3, é que tem 3 níveis).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 4"
 },
 {
  "id": "bz01-017",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Etapa 1",
  "enunciado": "A etapa da avaliação de risco que consiste em identificar qual direito ou garantia está exposto, os bens sujeitos a dano e o histórico dos fatos é a:",
  "alts": [
   {
    "t": "identificação de direitos e garantias sob ameaça (etapa 1).",
    "ok": true
   },
   {
    "t": "avaliação das ameaças (etapa 2)."
   },
   {
    "t": "avaliação dos possíveis resultados (etapa 5)."
   },
   {
    "t": "análise das vulnerabilidades (etapa 4)."
   }
  ],
  "resolucao": "==Gabarito: identificação de direitos e garantias sob ameaça (etapa 1).== Tópico 4 — Etapa 1.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Etapa 1"
 },
 {
  "id": "bz01-018",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Etapa 2",
  "enunciado": "Obter dados do infrator em potencial, como idade, sexo, compleição física, estado emocional e motivação contra policiais, corresponde à etapa de:",
  "alts": [
   {
    "t": "avaliação das ameaças.",
    "ok": true
   },
   {
    "t": "análise das vulnerabilidades."
   },
   {
    "t": "classificação de risco."
   },
   {
    "t": "avaliação dos possíveis resultados."
   }
  ],
  "resolucao": "==Gabarito: avaliação das ameaças.== Tópico 4 — Etapa 2.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Etapa 2"
 },
 {
  "id": "bz01-019",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Etapa 4",
  "enunciado": "A análise das vulnerabilidades consiste em analisar:",
  "alts": [
   {
    "t": "a quantidade de direitos garantidos pela Constituição."
   },
   {
    "t": "o histórico criminal do suspeito."
   },
   {
    "t": "os recursos existentes para responder à ameaça (competência profissional, efetivo e meios disponíveis).",
    "ok": true
   },
   {
    "t": "a imagem da instituição na mídia."
   }
  ],
  "resolucao": "==Gabarito: os recursos existentes para responder à ameaça (competência profissional, efetivo e meios disponíveis).== Tópico 4 — Etapa 4.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Etapa 4"
 },
 {
  "id": "bz01-020",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Etapa 5",
  "enunciado": "A etapa de avaliação dos possíveis resultados trata de:",
  "alts": [
   {
    "t": "descrever a compleição física do infrator."
   },
   {
    "t": "identificar o bem jurídico ameaçado."
   },
   {
    "t": "analisar a relação custo-benefício da intervenção diante de cada situação de risco.",
    "ok": true
   },
   {
    "t": "verificar se há efetivo suficiente para a supremacia de força."
   }
  ],
  "resolucao": "==Gabarito: analisar a relação custo-benefício da intervenção diante de cada situação de risco.== Tópico 4 — Etapa 5.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Etapa 5"
 },
 {
  "id": "bz01-021",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Risco Nível I (prontidão: amarelo)",
  "enunciado": "O risco de nível I caracteriza-se por:",
  "alts": [
   {
    "t": "concretização do dano ou risco real e iminente."
   },
   {
    "t": "reduzida possibilidade de ameaças; situações rotineiras e intervenções preventivas, educativas e assistenciais.",
    "ok": true
   },
   {
    "t": "real possibilidade de ameaça com fundada suspeita."
   },
   {
    "t": "intervenção exclusivamente repressiva."
   }
  ],
  "resolucao": "==Gabarito: reduzida possibilidade de ameaças; situações rotineiras e intervenções preventivas, educativas e assistenciais.== Tópico 4 — Risco Nível I (prontidão: amarelo).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Risco Nível I (prontidão: amarelo)"
 },
 {
  "id": "bz01-022",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Risco Nível II",
  "enunciado": "O risco de nível II é aquele em que há fundada suspeita e a intervenção consiste em averiguação preventiva; o estado de prontidão coerente é o de:",
  "alts": [
   {
    "t": "pânico (preto)."
   },
   {
    "t": "alerta (laranja).",
    "ok": true
   },
   {
    "t": "atenção (amarelo)."
   },
   {
    "t": "alarme (vermelho)."
   }
  ],
  "resolucao": "==Gabarito: alerta (laranja).== Tópico 4 — Risco Nível II.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Risco Nível II"
 },
 {
  "id": "bz01-023",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Risco Nível III",
  "enunciado": "O risco de nível III, de caráter repressivo, em que há dano concretizado ou risco real e iminente, exige prontidão de:",
  "alts": [
   {
    "t": "atenção (amarelo)."
   },
   {
    "t": "alerta (laranja)."
   },
   {
    "t": "relaxamento (branco)."
   },
   {
    "t": "alarme (vermelho).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: alarme (vermelho).== Tópico 4 — Risco Nível III.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Risco Nível III"
 },
 {
  "id": "bz01-024",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "diferença entre fundada suspeita e fundadas razões",
  "enunciado": "As “fundadas razões” aplicam-se à:",
  "alts": [
   {
    "t": "busca domiciliar, exigindo indícios razoáveis de materialidade e autoria e lastro em prova pré-constituída.",
    "ok": true
   },
   {
    "t": "busca pessoal em pedestres."
   },
   {
    "t": "abordagem de rotina sem qualquer indício."
   },
   {
    "t": "revista em veículos em blitz."
   }
  ],
  "resolucao": "==Gabarito: busca domiciliar, exigindo indícios razoáveis de materialidade e autoria e lastro em prova pré-constituída.== Tópico 5 — diferença entre fundada suspeita e fundadas razões.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, diferença entre fundada suspeita e fundadas razões"
 },
 {
  "id": "bz01-025",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Art. 240, § 2º, CPP",
  "enunciado": "O dispositivo do CPP que prevê que se procederá à busca pessoal quando houver fundada suspeita de que alguém oculte consigo arma proibida ou objetos é o:",
  "alts": [
   {
    "t": "Art. 249."
   },
   {
    "t": "Art. 5º, II, CF."
   },
   {
    "t": "Art. 144, CF."
   },
   {
    "t": "Art. 240, § 2º.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: Art. 240, § 2º.== Tópico 5 — Art. 240, § 2º, CPP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Art. 240, § 2º, CPP"
 },
 {
  "id": "bz01-026",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Art. 244, CPP",
  "enunciado": "Segundo o Art. 244 do CPP, a busca pessoal independe de mandado, entre outras hipóteses:",
  "alts": [
   {
    "t": "sempre que o policial julgar conveniente, sem qualquer indício."
   },
   {
    "t": "apenas quando o suspeito autorizar por escrito."
   },
   {
    "t": "somente à noite."
   },
   {
    "t": "no caso de prisão ou quando a medida for determinada no curso de busca domiciliar.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: no caso de prisão ou quando a medida for determinada no curso de busca domiciliar.== Tópico 5 — Art. 244, CPP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Art. 244, CPP"
 },
 {
  "id": "bz01-027",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "dez etapas, na ordem apresentada",
  "enunciado": "A abordagem desenvolve-se em quantas etapas?",
  "alts": [
   {
    "t": "Sete."
   },
   {
    "t": "Cinco."
   },
   {
    "t": "Doze."
   },
   {
    "t": "Dez.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: Dez.== Tópico 6 — dez etapas, na ordem apresentada.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, dez etapas, na ordem apresentada"
 },
 {
  "id": "bz01-028",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "2ª etapa: aproximação",
  "enunciado": "Na aproximação, a equipe deve aproximar-se preferencialmente:",
  "alts": [
   {
    "t": "pelas costas ou diagonalmente à retaguarda, a uma distância em que as ordens sejam naturalmente audíveis.",
    "ok": true
   },
   {
    "t": "em alta velocidade, sem sinais luminosos."
   },
   {
    "t": "de frente, para ser vista pelo abordado."
   },
   {
    "t": "pela lateral, a mais de 50 metros do abordado."
   }
  ],
  "resolucao": "==Gabarito: pelas costas ou diagonalmente à retaguarda, a uma distância em que as ordens sejam naturalmente audíveis.== Tópico 6 — 2ª etapa: aproximação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 2ª etapa: aproximação"
 },
 {
  "id": "bz01-029",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "3ª etapa: semidesembarque",
  "enunciado": "Antes do semidesembarque, o Comandante da equipe deve:",
  "alts": [
   {
    "t": "acionar os sinais luminosos e sonoros da viatura, salvo se a abordagem exigir caráter furtivo.",
    "ok": true
   },
   {
    "t": "desembarcar sem comunicar a equipe."
   },
   {
    "t": "solicitar o mandado de busca."
   },
   {
    "t": "desligar os faróis e a sirene em qualquer caso."
   }
  ],
  "resolucao": "==Gabarito: acionar os sinais luminosos e sonoros da viatura, salvo se a abordagem exigir caráter furtivo.== Tópico 6 — 3ª etapa: semidesembarque.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 3ª etapa: semidesembarque"
 },
 {
  "id": "bz01-030",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "4ª etapa: comandos verbais",
  "enunciado": "Na etapa dos comandos verbais, a verbalização:",
  "alts": [
   {
    "t": "é dispensada quando o suspeito parece calmo."
   },
   {
    "t": "começa em tom baixo e aumenta até o fim da abordagem."
   },
   {
    "t": "começa de maneira enérgica e reduz a intensidade à medida que a equipe estabelece o controle.",
    "ok": true
   },
   {
    "t": "mantém o mesmo tom gritado do início ao fim."
   }
  ],
  "resolucao": "==Gabarito: começa de maneira enérgica e reduz a intensidade à medida que a equipe estabelece o controle.== Tópico 6 — 4ª etapa: comandos verbais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 4ª etapa: comandos verbais"
 },
 {
  "id": "bz01-031",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "5ª etapa: desembarque",
  "enunciado": "Ao desembarcar, os policiais fecham as portas da viatura e se posicionam:",
  "alts": [
   {
    "t": "à frente do veículo, de costas para os abordados."
   },
   {
    "t": "ao lado do condutor, sem alinhamento."
   },
   {
    "t": "alinhados com o bloco do motor, à retaguarda dos abordados.",
    "ok": true
   },
   {
    "t": "dentro da viatura, até o fim da busca."
   }
  ],
  "resolucao": "==Gabarito: alinhados com o bloco do motor, à retaguarda dos abordados.== Tópico 6 — 5ª etapa: desembarque.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 5ª etapa: desembarque"
 },
 {
  "id": "bz01-032",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "5ª etapa: medidas do leque",
  "enunciado": "Na abertura de leque (triangulação), mantêm-se:",
  "alts": [
   {
    "t": "4 metros entre os policiais e 3 metros em relação ao abordado.",
    "ok": true
   },
   {
    "t": "3 metros entre os policiais e 4 metros do abordado."
   },
   {
    "t": "10 metros entre os policiais e 5 metros do abordado."
   },
   {
    "t": "1 metro entre os policiais e 1 metro do abordado."
   }
  ],
  "resolucao": "==Gabarito: 4 metros entre os policiais e 3 metros em relação ao abordado.== Tópico 6 — 5ª etapa: medidas do leque.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 5ª etapa: medidas do leque"
 },
 {
  "id": "bz01-033",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "6ª etapa: busca pessoal",
  "enunciado": "Na busca pessoal, o militar se aproxima a uma distância mínima de:",
  "alts": [
   {
    "t": "meio metro, com a arma apontada ao abordado."
   },
   {
    "t": "2 metros (distância de contato), sem desfazer o contato visual, colocando a arma no coldre e abotoando-o.",
    "ok": true
   },
   {
    "t": "5 metros, mantendo a arma empunhada."
   },
   {
    "t": "10 metros, sem contato visual."
   }
  ],
  "resolucao": "==Gabarito: 2 metros (distância de contato), sem desfazer o contato visual, colocando a arma no coldre e abotoando-o.== Tópico 6 — 6ª etapa: busca pessoal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 6ª etapa: busca pessoal"
 },
 {
  "id": "bz01-034",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "regras de execução da busca pessoal",
  "enunciado": "Segundo as regras de execução da busca pessoal, esta só deve ser iniciada:",
  "alts": [
   {
    "t": "quando o abordado estiver contido.",
    "ok": true
   },
   {
    "t": "antes de dar qualquer comando verbal."
   },
   {
    "t": "após a chegada da imprensa."
   },
   {
    "t": "quando o abordado estiver sentado e algemado, sempre."
   }
  ],
  "resolucao": "==Gabarito: quando o abordado estiver contido.== Tópico 6 — regras de execução da busca pessoal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, regras de execução da busca pessoal"
 },
 {
  "id": "bz01-035",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "divisão por quadrantes",
  "enunciado": "A busca pessoal deve priorizar a linha de cintura e, depois, ser dividida em quadrantes. Quais são eles?",
  "alts": [
   {
    "t": "Superior direito e esquerdo, e inferior direito e esquerdo.",
    "ok": true
   },
   {
    "t": "Anterior, posterior e lateral."
   },
   {
    "t": "Três setores, de 1 a 3."
   },
   {
    "t": "Cabeça, tronco e membros, apenas."
   }
  ],
  "resolucao": "==Gabarito: Superior direito e esquerdo, e inferior direito e esquerdo.== Tópico 6 — divisão por quadrantes.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, divisão por quadrantes"
 },
 {
  "id": "bz01-036",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "observações específicas",
  "enunciado": "Na abordagem de mulher transexual e travesti, a busca é:",
  "alts": [
   {
    "t": "prioritariamente realizada pelo efetivo feminino, respeitando os procedimentos de segurança e avaliando o grau de risco.",
    "ok": true
   },
   {
    "t": "realizada apenas por delegado de polícia."
   },
   {
    "t": "dispensada em qualquer hipótese."
   },
   {
    "t": "obrigatoriamente realizada por policial masculino."
   }
  ],
  "resolucao": "==Gabarito: prioritariamente realizada pelo efetivo feminino, respeitando os procedimentos de segurança e avaliando o grau de risco.== Tópico 6 — observações específicas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, observações específicas"
 },
 {
  "id": "bz01-037",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "observações específicas",
  "enunciado": "Na abordagem de deficiente auditivo, a doutrina prevê:",
  "alts": [
   {
    "t": "a presença obrigatória de intérprete credenciado antes de qualquer ação."
   },
   {
    "t": "o uso exclusivo de comandos verbais em tom mais alto."
   },
   {
    "t": "um policial na segurança e outro gesticulando para que o suspeito compreenda e obedeça às determinações.",
    "ok": true
   },
   {
    "t": "a dispensa da busca pessoal."
   }
  ],
  "resolucao": "==Gabarito: um policial na segurança e outro gesticulando para que o suspeito compreenda e obedeça às determinações.== Tópico 6 — observações específicas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, observações específicas"
 },
 {
  "id": "bz01-038",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "observações específicas",
  "enunciado": "Na busca pessoal de deficiente físico, empregam-se quantos policiais?",
  "alts": [
   {
    "t": "Três: dois auxiliam a levantá-lo e mantê-lo de pé, e o terceiro realiza a busca.",
    "ok": true
   },
   {
    "t": "Um, que realiza todos os atos sozinho."
   },
   {
    "t": "Cinco, para evitar fuga."
   },
   {
    "t": "Dois, sendo um apenas observador."
   }
  ],
  "resolucao": "==Gabarito: Três: dois auxiliam a levantá-lo e mantê-lo de pé, e o terceiro realiza a busca.== Tópico 6 — observações específicas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, observações específicas"
 },
 {
  "id": "bz01-039",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "7ª etapa",
  "enunciado": "Na checagem de documentos (7ª etapa), o Comandante:",
  "alts": [
   {
    "t": "recolhe os documentos e encerra a abordagem sem checagem."
   },
   {
    "t": "solicita os documentos pessoais (ou exige que a pessoa se identifique) e passa os dados a outro militar para checagem.",
    "ok": true
   },
   {
    "t": "dispensa a conferência de dados quando o abordado parece tranquilo."
   },
   {
    "t": "executa pessoalmente todas as checagens, sem apoio."
   }
  ],
  "resolucao": "==Gabarito: solicita os documentos pessoais (ou exige que a pessoa se identifique) e passa os dados a outro militar para checagem.== Tópico 6 — 7ª etapa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 7ª etapa"
 },
 {
  "id": "bz01-040",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "8ª etapa",
  "enunciado": "Na checagem e busca no veículo, a revista deve ser:",
  "alts": [
   {
    "t": "visualizada pelo motorista/condutor/proprietário.",
    "ok": true
   },
   {
    "t": "realizada apenas pelo lado externo."
   },
   {
    "t": "feita sem a presença do condutor."
   },
   {
    "t": "dispensada se o veículo estiver regular."
   }
  ],
  "resolucao": "==Gabarito: visualizada pelo motorista/condutor/proprietário.== Tópico 6 — 8ª etapa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 8ª etapa"
 },
 {
  "id": "bz01-041",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "8ª etapa: quadrantes do veículo",
  "enunciado": "Para organizar a revista do automóvel, recomenda-se dividi-lo em:",
  "alts": [
   {
    "t": "quadrantes (setores internos, dianteiro, traseiro e externo, de 1 a 7).",
    "ok": true
   },
   {
    "t": "duas metades: frente e fundos."
   },
   {
    "t": "dez setores numerados de 1 a 10."
   },
   {
    "t": "três quadrantes: motor, cabine e porta-malas."
   }
  ],
  "resolucao": "==Gabarito: quadrantes (setores internos, dianteiro, traseiro e externo, de 1 a 7).== Tópico 6 — 8ª etapa: quadrantes do veículo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 8ª etapa: quadrantes do veículo"
 },
 {
  "id": "bz01-042",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "9ª etapa",
  "enunciado": "A busca no perímetro (9ª etapa) tem o intuito de:",
  "alts": [
   {
    "t": "localizar objetos ilícitos que estavam em posse dos abordados e foram dispensados.",
    "ok": true
   },
   {
    "t": "revistar os transeuntes que passam pelo local."
   },
   {
    "t": "verificar a regularidade do licenciamento do veículo."
   },
   {
    "t": "identificar o proprietário do imóvel mais próximo."
   }
  ],
  "resolucao": "==Gabarito: localizar objetos ilícitos que estavam em posse dos abordados e foram dispensados.== Tópico 6 — 9ª etapa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 9ª etapa"
 },
 {
  "id": "bz01-043",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "10ª etapa",
  "enunciado": "A entrevista policial, última etapa da abordagem, é conduzida:",
  "alts": [
   {
    "t": "pelo motorista da viatura, sempre."
   },
   {
    "t": "pelo Comandante, podendo ser auxiliado por outro componente da equipe.",
    "ok": true
   },
   {
    "t": "exclusivamente por delegado de polícia."
   },
   {
    "t": "por um civil designado no local."
   }
  ],
  "resolucao": "==Gabarito: pelo Comandante, podendo ser auxiliado por outro componente da equipe.== Tópico 6 — 10ª etapa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, 10ª etapa"
 },
 {
  "id": "bz01-044",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Ação vigorosa",
  "enunciado": "A “ação vigorosa” é caracterizada por:",
  "alts": [
   {
    "t": "uso imediato da força letal."
   },
   {
    "t": "postura do policial mais entonação de voz, inibindo reações e favorecendo o acatamento das ordens.",
    "ok": true
   },
   {
    "t": "agir de forma afobada e sem planejamento."
   },
   {
    "t": "falar baixo para não alarmar o abordado."
   }
  ],
  "resolucao": "==Gabarito: postura do policial mais entonação de voz, inibindo reações e favorecendo o acatamento das ordens.== Tópico 1.2 — Ação vigorosa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Ação vigorosa"
 },
 {
  "id": "bz01-045",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Necessidade",
  "enunciado": "O princípio legal segundo o qual o militar deve verificar a real necessidade de realizar a abordagem, visando à segurança da equipe, do público e dos suspeitos, é o da:",
  "alts": [
   {
    "t": "legalidade."
   },
   {
    "t": "oportunidade."
   },
   {
    "t": "proporcionalidade."
   },
   {
    "t": "necessidade.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: necessidade.== Tópico 1.3 — Necessidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Necessidade"
 },
 {
  "id": "bz01-046",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Simplicidade",
  "enunciado": "Segundo o princípio da simplicidade, o policial deve:",
  "alts": [
   {
    "t": "manter a abordagem simples, porém taticamente segura e funcional, emitindo ordens claras e concisas.",
    "ok": true
   },
   {
    "t": "adiar as ordens até o reforço chegar."
   },
   {
    "t": "usar o maior número possível de comandos complexos."
   },
   {
    "t": "improvisar sem observar a tática."
   }
  ],
  "resolucao": "==Gabarito: manter a abordagem simples, porém taticamente segura e funcional, emitindo ordens claras e concisas.== Tópico 1.2 — Simplicidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Simplicidade"
 },
 {
  "id": "bz01-047",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 2.1",
  "enunciado": "(Certo ou Errado) O estado de prontidão de cor branca pode ser ocasionado por percepção errônea da ausência de perigo ou por cansaço.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2.1 — Estado relaxado (branco)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2.1 — Estado relaxado (branco).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 2.1"
 },
 {
  "id": "bz01-048",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 2.2",
  "enunciado": "(Certo ou Errado) No estado de atenção (amarelo), o policial encontra-se tenso e com a atenção concentrada em uma única ameaça.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2.2 — no amarelo o policial está atento e precavido, mas NÃO tenso; a atenção é difusa."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2.2 — no amarelo o policial está atento e precavido, mas NÃO tenso; a atenção é difusa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 2.2"
 },
 {
  "id": "bz01-049",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 2.3",
  "enunciado": "(Certo ou Errado) No estado de alerta (laranja), ainda não há necessidade imediata de reação, embora o policial identifique prováveis riscos que exijam o uso da força.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2.3 — Estado de alerta."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2.3 — Estado de alerta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 2.3"
 },
 {
  "id": "bz01-050",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 2.5",
  "enunciado": "(Certo ou Errado) O estado de pânico (preto) pode decorrer de tensão mantida por período muito prolongado, levando o organismo à sobrecarga física e emocional.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2.5 — Estado de pânico."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2.5 — Estado de pânico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 2.5"
 },
 {
  "id": "bz01-051",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 3.2",
  "enunciado": "(Certo ou Errado) O preparo mental dispensa a avaliação dos direitos e garantias fundamentais que podem ser limitados durante a intervenção.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.2 — o preparo mental serve, entre outros fins, para ponderar esses direitos e garantias."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.2 — o preparo mental serve, entre outros fins, para ponderar esses direitos e garantias.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 3.2"
 },
 {
  "id": "bz01-052",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) A classificação de risco estrutura-se em três níveis e auxilia na escolha do comportamento tático mais adequado.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — Etapa 3: Classificação de risco."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — Etapa 3: Classificação de risco.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 4"
 },
 {
  "id": "bz01-053",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) A fundada suspeita aplica-se à busca domiciliar, enquanto as fundadas razões aplicam-se à busca pessoal.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5 — o inverso: fundada suspeita = busca pessoal; fundadas razões = busca domiciliar."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5 — o inverso: fundada suspeita = busca pessoal; fundadas razões = busca domiciliar.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 5"
 },
 {
  "id": "bz01-054",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) A busca pessoal independe de mandado quando a medida for determinada no curso de busca domiciliar (Art. 244, CPP).",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — Art. 244, CPP."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — Art. 244, CPP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 5"
 },
 {
  "id": "bz01-055",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Na aproximação, a equipe deve preferencialmente aproximar-se de frente, para que o abordado a veja claramente.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — a aproximação é preferencialmente pelas costas ou diagonalmente à retaguarda."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — a aproximação é preferencialmente pelas costas ou diagonalmente à retaguarda.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-056",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Na etapa dos comandos verbais, os exemplos de ordens apresentados são meramente exemplificativos, devendo-se manter a abordagem simples e segura.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — 4ª etapa."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — 4ª etapa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-057",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Ao desembarcar, os policiais podem deixar as portas da viatura abertas, pois isso facilita o embarque rápido.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — 5ª etapa: os policiais fecham as portas da viatura."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — 5ª etapa: os policiais fecham as portas da viatura.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-058",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Na busca pessoal, a regra é não perder o contato com o abordado e manter suas pernas afastadas.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — regras de execução da busca pessoal."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — regras de execução da busca pessoal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-059",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) A busca pessoal em mulher deve ser feita sempre por policial masculino, independentemente de haver policial feminina disponível.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — Art. 249, CPP: será feita por outra mulher, se não importar retardamento ou prejuízo da diligência."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — Art. 249, CPP: será feita por outra mulher, se não importar retardamento ou prejuízo da diligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-060",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Na abordagem de pessoa com deficiência física que usa cadeira de rodas, após a busca no abordado realiza-se a busca na cadeira de rodas e, por fim, recoloca-se o abordado nela.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — observações específicas (deficientes físicos)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — observações específicas (deficientes físicos).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-061",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) A busca no perímetro dispensa qualquer minúcia, pois é sempre realizada de forma superficial.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — 9ª etapa: pode exigir busca perimetral mais minuciosa, conforme o que se procura."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — 9ª etapa: pode exigir busca perimetral mais minuciosa, conforme o que se procura.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 6"
 },
 {
  "id": "bz01-062",
  "disc": "Técnicas de Policiamento Ostensivo",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) Na avaliação dos possíveis resultados, o policial deve considerar, entre outros aspectos, a imagem da PMMS.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — Etapa 5."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — Etapa 5.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 1, Tópico 4"
 }
]);
