/* Disciplina: Policiamento em Eventos (37 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz02-001",
  "disc": "Policiamento em Eventos",
  "assunto": "conceito de policiamento em eventos",
  "enunciado": "O policiamento em eventos consiste no emprego de táticas policiais específicas voltadas para a manutenção da ordem pública em:",
  "alts": [
   {
    "t": "locais com presença de multidão permitida.",
    "ok": true
   },
   {
    "t": "apenas estabelecimentos prisionais."
   },
   {
    "t": "residências particulares sem aglomeração."
   },
   {
    "t": "áreas de mata fechada, sem público."
   }
  ],
  "resolucao": "==Gabarito: locais com presença de multidão permitida.== Tópico 1 — conceito de policiamento em eventos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, conceito de policiamento em eventos"
 },
 {
  "id": "bz02-002",
  "disc": "Policiamento em Eventos",
  "assunto": "finalidade",
  "enunciado": "A finalidade do policiamento em eventos é, como modalidade de policiamento ostensivo dirigido a todos os cidadãos reunidos por um objetivo comum, atuar:",
  "alts": [
   {
    "t": "somente na fiscalização tributária do evento."
   },
   {
    "t": "apenas no atendimento pré-hospitalar dos participantes."
   },
   {
    "t": "exclusivamente na investigação de crimes já consumados."
   },
   {
    "t": "na prevenção de crimes, no controle de multidões e na resposta rápida a incidentes.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: na prevenção de crimes, no controle de multidões e na resposta rápida a incidentes.== Tópico 1 — finalidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, finalidade"
 },
 {
  "id": "bz02-003",
  "disc": "Policiamento em Eventos",
  "assunto": "Patrulha Observadora",
  "enunciado": "A Patrulha Observadora é composta por:",
  "alts": [
   {
    "t": "4 a 5 policiais, com atuação restrita."
   },
   {
    "t": "até 3 policiais (admite-se 2), monitorando o ambiente e subsidiando as patrulhas de intervenção.",
    "ok": true
   },
   {
    "t": "mais de 20 policiais, sempre montados."
   },
   {
    "t": "7 a 12 policiais, com armamento específico."
   }
  ],
  "resolucao": "==Gabarito: até 3 policiais (admite-se 2), monitorando o ambiente e subsidiando as patrulhas de intervenção.== Tópico 2 — Patrulha Observadora.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Patrulha Observadora"
 },
 {
  "id": "bz02-004",
  "disc": "Policiamento em Eventos",
  "assunto": "Patrulha Interventora",
  "enunciado": "A patrulha composta geralmente por 7 a 12 policiais (fração de Choque), dotada de armamento e equipamento específicos, que atua no controle de distúrbios e dispersão, é a:",
  "alts": [
   {
    "t": "Patrulha de Reconhecimento."
   },
   {
    "t": "Patrulha Interventora.",
    "ok": true
   },
   {
    "t": "Patrulha Limitada."
   },
   {
    "t": "Patrulha Observadora."
   }
  ],
  "resolucao": "==Gabarito: Patrulha Interventora.== Tópico 2 — Patrulha Interventora.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Patrulha Interventora"
 },
 {
  "id": "bz02-005",
  "disc": "Policiamento em Eventos",
  "assunto": "classificação por área de interesse",
  "enunciado": "Um simpósio de áreas da ciência é classificado, por área de interesse, como evento:",
  "alts": [
   {
    "t": "cívico."
   },
   {
    "t": "técnico/científico.",
    "ok": true
   },
   {
    "t": "artístico/cultural."
   },
   {
    "t": "desportivo."
   }
  ],
  "resolucao": "==Gabarito: técnico/científico.== Tópico 3.1 — classificação por área de interesse.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, classificação por área de interesse"
 },
 {
  "id": "bz02-006",
  "disc": "Policiamento em Eventos",
  "assunto": "eventos cívicos",
  "enunciado": "Datas comemorativas e celebrações ligadas à pátria enquadram-se como eventos:",
  "alts": [
   {
    "t": "turísticos."
   },
   {
    "t": "cívicos.",
    "ok": true
   },
   {
    "t": "técnicos."
   },
   {
    "t": "religiosos."
   }
  ],
  "resolucao": "==Gabarito: cívicos.== Tópico 3.1 — eventos cívicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, eventos cívicos"
 },
 {
  "id": "bz02-007",
  "disc": "Policiamento em Eventos",
  "assunto": "empresariais, turísticos e sociais",
  "enunciado": "Casamentos e formaturas são exemplos de eventos classificados como:",
  "alts": [
   {
    "t": "empresariais, turísticos e sociais.",
    "ok": true
   },
   {
    "t": "políticos."
   },
   {
    "t": "técnicos/científicos."
   },
   {
    "t": "religiosos."
   }
  ],
  "resolucao": "==Gabarito: empresariais, turísticos e sociais.== Tópico 3.1 — empresariais, turísticos e sociais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, empresariais, turísticos e sociais"
 },
 {
  "id": "bz02-008",
  "disc": "Policiamento em Eventos",
  "assunto": "médios eventos",
  "enunciado": "Os médios eventos reúnem público de:",
  "alts": [
   {
    "t": "até 300 pessoas."
   },
   {
    "t": "300 a 5.000 pessoas.",
    "ok": true
   },
   {
    "t": "100 a 1.000 pessoas."
   },
   {
    "t": "mais de 5.000 pessoas."
   }
  ],
  "resolucao": "==Gabarito: 300 a 5.000 pessoas.== Tópico 3.2 — médios eventos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, médios eventos"
 },
 {
  "id": "bz02-009",
  "disc": "Policiamento em Eventos",
  "assunto": "pequenos eventos",
  "enunciado": "Os pequenos eventos têm público de até:",
  "alts": [
   {
    "t": "5.000 pessoas."
   },
   {
    "t": "1.000 pessoas."
   },
   {
    "t": "100 pessoas."
   },
   {
    "t": "300 pessoas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 300 pessoas.== Tópico 3.2 — pequenos eventos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, pequenos eventos"
 },
 {
  "id": "bz02-010",
  "disc": "Policiamento em Eventos",
  "assunto": "ambiente misto",
  "enunciado": "Palcos e áreas cercadas em exposições agropecuárias exemplificam o ambiente:",
  "alts": [
   {
    "t": "aberto."
   },
   {
    "t": "isolado."
   },
   {
    "t": "fechado."
   },
   {
    "t": "misto.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: misto.== Tópico 4 — ambiente misto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, ambiente misto"
 },
 {
  "id": "bz02-011",
  "disc": "Policiamento em Eventos",
  "assunto": "Aglomeração",
  "enunciado": "O agrupamento temporário e aleatório de indivíduos desorganizados, que pensam e agem isoladamente (como em estações de transporte), é denominado:",
  "alts": [
   {
    "t": "turba."
   },
   {
    "t": "manifestação."
   },
   {
    "t": "multidão."
   },
   {
    "t": "aglomeração.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: aglomeração.== Tópico 5 — Aglomeração.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Aglomeração"
 },
 {
  "id": "bz02-012",
  "disc": "Policiamento em Eventos",
  "assunto": "tipos de turba",
  "enunciado": "A turba que busca depredação e saques é classificada como:",
  "alts": [
   {
    "t": "organizada."
   },
   {
    "t": "agressiva."
   },
   {
    "t": "predatória.",
    "ok": true
   },
   {
    "t": "em pânico."
   }
  ],
  "resolucao": "==Gabarito: predatória.== Tópico 5 — tipos de turba.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, tipos de turba"
 },
 {
  "id": "bz02-013",
  "disc": "Policiamento em Eventos",
  "assunto": "tipos de turba",
  "enunciado": "A turba em pânico caracteriza-se pela:",
  "alts": [
   {
    "t": "busca cega por fuga.",
    "ok": true
   },
   {
    "t": "obediência às ordens policiais."
   },
   {
    "t": "busca de depredação e saques."
   },
   {
    "t": "prática deliberada de violência."
   }
  ],
  "resolucao": "==Gabarito: busca cega por fuga.== Tópico 5 — tipos de turba.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, tipos de turba"
 },
 {
  "id": "bz02-014",
  "disc": "Policiamento em Eventos",
  "assunto": "fatores exógenos",
  "enunciado": "O consumo de bebidas alcoólicas, drogas, fome e exaltação emocional são fatores:",
  "alts": [
   {
    "t": "exógenos.",
    "ok": true
   },
   {
    "t": "ambientais e naturais."
   },
   {
    "t": "legais."
   },
   {
    "t": "psicológicos."
   }
  ],
  "resolucao": "==Gabarito: exógenos.== Tópico 5 — fatores exógenos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, fatores exógenos"
 },
 {
  "id": "bz02-015",
  "disc": "Policiamento em Eventos",
  "assunto": "fatores ambientais e naturais",
  "enunciado": "Limpeza do local, saneamento, conforto das instalações, filas e calor excessivo são fatores:",
  "alts": [
   {
    "t": "doutrinários."
   },
   {
    "t": "psicológicos."
   },
   {
    "t": "exógenos."
   },
   {
    "t": "ambientais e naturais.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: ambientais e naturais.== Tópico 5 — fatores ambientais e naturais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, fatores ambientais e naturais"
 },
 {
  "id": "bz02-016",
  "disc": "Policiamento em Eventos",
  "assunto": "prazo de solicitação",
  "enunciado": "O organizador deve protocolar o pedido de vistoria junto à OPM com antecedência mínima de:",
  "alts": [
   {
    "t": "5 dias."
   },
   {
    "t": "72 horas."
   },
   {
    "t": "60 dias."
   },
   {
    "t": "20 (vinte) dias.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 20 (vinte) dias.== Tópico 7 — prazo de solicitação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, prazo de solicitação"
 },
 {
  "id": "bz02-017",
  "disc": "Policiamento em Eventos",
  "assunto": "inspeção in loco",
  "enunciado": "A inspeção in loco para a vistoria deve ser executada com antecedência mínima de:",
  "alts": [
   {
    "t": "20 dias do evento."
   },
   {
    "t": "72 horas do evento, na presença dos responsáveis.",
    "ok": true
   },
   {
    "t": "30 dias do evento."
   },
   {
    "t": "24 horas do evento."
   }
  ],
  "resolucao": "==Gabarito: 72 horas do evento, na presença dos responsáveis.== Tópico 7 — inspeção in loco.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, inspeção in loco"
 },
 {
  "id": "bz02-018",
  "disc": "Policiamento em Eventos",
  "assunto": "ingresso e identificação",
  "enunciado": "Segundo o Art. 158 da Lei Geral do Esporte, para o acesso ao recinto esportivo exige-se o cadastro biométrico facial para maiores de 16 anos em arenas com capacidade superior a:",
  "alts": [
   {
    "t": "10 mil pessoas."
   },
   {
    "t": "5 mil pessoas."
   },
   {
    "t": "50 mil pessoas."
   },
   {
    "t": "20 mil pessoas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 20 mil pessoas.== Tópico 8 — ingresso e identificação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, ingresso e identificação"
 },
 {
  "id": "bz02-019",
  "disc": "Policiamento em Eventos",
  "assunto": "penalidade imediata",
  "enunciado": "A recusa em consentir com a revista pessoal de prevenção e segurança no recinto esportivo gera:",
  "alts": [
   {
    "t": "a negativa de entrada ou o afastamento compulsório imediato do recinto.",
    "ok": true
   },
   {
    "t": "nenhuma consequência."
   },
   {
    "t": "apenas uma advertência verbal."
   },
   {
    "t": "multa a ser paga ao final do evento."
   }
  ],
  "resolucao": "==Gabarito: a negativa de entrada ou o afastamento compulsório imediato do recinto.== Tópico 8 — penalidade imediata.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, penalidade imediata"
 },
 {
  "id": "bz02-020",
  "disc": "Policiamento em Eventos",
  "assunto": "Art. 166",
  "enunciado": "Vender ou portar para venda ingressos por preço superior ao estampado no bilhete é conduta prevista no:",
  "alts": [
   {
    "t": "Art. 144."
   },
   {
    "t": "Art. 158."
   },
   {
    "t": "Art. 165."
   },
   {
    "t": "Art. 166.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: Art. 166.== Tópico 9 — Art. 166.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Art. 166"
 },
 {
  "id": "bz02-021",
  "disc": "Policiamento em Eventos",
  "assunto": "Atos preparatórios (POP 7.01)",
  "enunciado": "Na reunião preparatória de segurança, o alinhamento do plano de contingência e das responsabilidades é feito com:",
  "alts": [
   {
    "t": "apenas os torcedores organizados."
   },
   {
    "t": "exclusivamente os atletas."
   },
   {
    "t": "organizadores, segurança privada e órgãos públicos.",
    "ok": true
   },
   {
    "t": "somente a imprensa."
   }
  ],
  "resolucao": "==Gabarito: organizadores, segurança privada e órgãos públicos.== Tópico 10 — Atos preparatórios (POP 7.01).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Atos preparatórios (POP 7.01)"
 },
 {
  "id": "bz02-022",
  "disc": "Policiamento em Eventos",
  "assunto": "1ª fase",
  "enunciado": "Na 1ª fase do policiamento (pré-evento), o deslocamento tem foco no:",
  "alts": [
   {
    "t": "recolhimento de ingressos."
   },
   {
    "t": "sigilo absoluto, sem presença visível."
   },
   {
    "t": "convencimento de chegada (demonstração de força e superioridade).",
    "ok": true
   },
   {
    "t": "encerramento imediato do evento."
   }
  ],
  "resolucao": "==Gabarito: convencimento de chegada (demonstração de força e superioridade).== Tópico 11 — 1ª fase.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, 1ª fase"
 },
 {
  "id": "bz02-023",
  "disc": "Policiamento em Eventos",
  "assunto": "2ª fase",
  "enunciado": "Durante o evento (2ª fase), a doutrina orienta:",
  "alts": [
   {
    "t": "efetivo mínimo nos portões e foco no interior das arquibancadas e instalações.",
    "ok": true
   },
   {
    "t": "manter a tropa estática, sem remanejamento."
   },
   {
    "t": "efetivo máximo nos portões e nenhum policial no interior."
   },
   {
    "t": "dispensar o monitoramento de torcidas rivais."
   }
  ],
  "resolucao": "==Gabarito: efetivo mínimo nos portões e foco no interior das arquibancadas e instalações.== Tópico 11 — 2ª fase.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, 2ª fase"
 },
 {
  "id": "bz02-024",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) A Patrulha Interventora é composta geralmente por 7 a 12 policiais (fração de Choque) e atua no controle de distúrbios e dispersão, quando necessário.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — Patrulha Interventora."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — Patrulha Interventora.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 2"
 },
 {
  "id": "bz02-025",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 3.2",
  "enunciado": "(Certo ou Errado) Um evento com público de 3.000 pessoas é classificado como grande evento.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.2 — de 300 a 5.000 pessoas = médio evento; grande é acima de 5.000."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.2 — de 300 a 5.000 pessoas = médio evento; grande é acima de 5.000.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 3.2"
 },
 {
  "id": "bz02-026",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) No ambiente fechado, o perímetro é totalmente delimitado por estruturas físicas e dotado de portões de acesso.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — ambiente fechado."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — ambiente fechado.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 4"
 },
 {
  "id": "bz02-027",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) Tumulto é a desordem de pequena proporção, surgida repentinamente ou não.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — Tumulto."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — Tumulto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 5"
 },
 {
  "id": "bz02-028",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) A turba agressiva caracteriza-se pela busca cega por fuga.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5 — a busca cega por fuga é da turba em pânico; a agressiva pratica deliberadamente violência e confronto."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5 — a busca cega por fuga é da turba em pânico; a agressiva pratica deliberadamente violência e confronto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 5"
 },
 {
  "id": "bz02-029",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Compete à PMMS a fiscalização e o cumprimento das diretrizes do Ministério do Esporte / Anesporte e da Lei Geral do Esporte.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — competência da PMMS."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — competência da PMMS.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 6"
 },
 {
  "id": "bz02-030",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 7",
  "enunciado": "(Certo ou Errado) A inspeção in loco para a vistoria prévia deve ocorrer com antecedência mínima de 20 dias, e o pedido do organizador, com 72 horas.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 7 — invertido: pedido com 20 dias; inspeção in loco com 72 horas."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 7 — invertido: pedido com 20 dias; inspeção in loco com 72 horas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 7"
 },
 {
  "id": "bz02-031",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) Ostentar cartazes ou entoar cânticos de cunho racista, homofóbico, sexista ou xenófobo é conduta proibida no recinto esportivo.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 8 — itens e condutas proibidas."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 8 — itens e condutas proibidas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 8"
 },
 {
  "id": "bz02-032",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 9",
  "enunciado": "(Certo ou Errado) A sanção de proibição de comparecer a praças esportivas aplicada à torcida organizada não se estende aos seus associados.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 9 — a sanção é estendida a todos os seus associados."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 9 — a sanção é estendida a todos os seus associados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 9"
 },
 {
  "id": "bz02-033",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) A Vistoria Preliminar de Segurança, com antecedência de 72h, serve para a conferência física do local e a correção de vulnerabilidades.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 10 — atos preparatórios."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 10 — atos preparatórios.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 10"
 },
 {
  "id": "bz02-034",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) Na 1ª fase do policiamento ocorrem o recebimento da Ordem de Serviço, a revista e preleção da tropa e a instalação do Posto de Comando.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 11 — 1ª fase."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 11 — 1ª fase.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 11"
 },
 {
  "id": "bz02-035",
  "disc": "Policiamento em Eventos",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) Na 3ª fase do policiamento, a tropa é imediatamente desmobilizada, sem necessidade de monitorar terminais de ônibus e itinerários de transporte.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 11 — 3ª fase: há monitoramento de itinerários e terminais antes da desmobilização final."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 11 — 3ª fase: há monitoramento de itinerários e terminais antes da desmobilização final.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Tópico 11"
 },
 {
  "id": "bz02-036",
  "disc": "Policiamento em Eventos",
  "assunto": "impedimento de frequência (reforço)",
  "enunciado": "Em um jogo, uma torcida organizada invade a área técnica e promove atos discriminatórios. Segundo o Resumão, a sanção prevista é:",
  "alts": [
   {
    "t": "suspensão por 6 meses das atividades da torcida, sem extensão aos associados."
   },
   {
    "t": "proibição de comparecer a praças esportivas por até 1 ano, restrita aos líderes da torcida."
   },
   {
    "t": "proibição de comparecer a praças esportivas por até 5 anos, estendida a todos os seus associados.",
    "ok": true
   },
   {
    "t": "proibição de comparecer a praças esportivas por até 10 anos, restrita à diretoria da torcida."
   }
  ],
  "resolucao": "==Gabarito: proibição de comparecer a praças esportivas por até 5 anos, estendida a todos os seus associados.== Tópico 9 — impedimento de frequência (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, impedimento de frequência (reforço)"
 },
 {
  "id": "bz02-037",
  "disc": "Policiamento em Eventos",
  "assunto": "Crimes contra a Paz no Esporte (reforço)",
  "enunciado": "Torcedores brigam, portando artefatos violentos, a 3.000 metros da arena, no trajeto até o estádio. Essa conduta, dentro do raio de até 5.000 metros, sujeita os envolvidos a:",
  "alts": [
   {
    "t": "apenas multa, com afastamento imediato do recinto esportivo."
   },
   {
    "t": "reclusão de 2 a 4 anos e multa, como na corrupção privada no esporte."
   },
   {
    "t": "detenção de 6 meses a 1 ano, sem multa e sem agravantes."
   },
   {
    "t": "reclusão de 1 a 2 anos e multa, com agravantes para lideranças de torcidas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: reclusão de 1 a 2 anos e multa, com agravantes para lideranças de torcidas.== Tópico 9 — Crimes contra a Paz no Esporte (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 2, Crimes contra a Paz no Esporte (reforço)"
 }
]);
