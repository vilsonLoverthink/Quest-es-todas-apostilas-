/* Disciplina: Uso da Força (33 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz03-001",
  "disc": "Uso da Força",
  "assunto": "conceito",
  "enunciado": "O uso diferenciado da força consiste na:",
  "alts": [
   {
    "t": "proibição absoluta de qualquer intervenção coercitiva."
   },
   {
    "t": "aplicação sempre máxima da força disponível."
   },
   {
    "t": "escolha do equipamento mais caro disponível."
   },
   {
    "t": "seleção apropriada do nível de força a ser empregado pelo profissional em resposta a uma ameaça real ou potencial.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: seleção apropriada do nível de força a ser empregado pelo profissional em resposta a uma ameaça real ou potencial.== Tópico 1 — conceito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, conceito"
 },
 {
  "id": "bz03-002",
  "disc": "Uso da Força",
  "assunto": "objetivo",
  "enunciado": "O objetivo do uso diferenciado da força é:",
  "alts": [
   {
    "t": "demonstrar superioridade numérica."
   },
   {
    "t": "minimizar o uso de meios que possam causar ofensas, ferimentos ou mortes.",
    "ok": true
   },
   {
    "t": "evitar o registro da ocorrência."
   },
   {
    "t": "punir o infrator de forma exemplar."
   }
  ],
  "resolucao": "==Gabarito: minimizar o uso de meios que possam causar ofensas, ferimentos ou mortes.== Tópico 1 — objetivo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, objetivo"
 },
 {
  "id": "bz03-003",
  "disc": "Uso da Força",
  "assunto": "1. Perceber (o ambiente)",
  "enunciado": "Na primeira etapa do ciclo 2PDA, o profissional analisa:",
  "alts": [
   {
    "t": "o nível de força legal a ser selecionado."
   },
   {
    "t": "a percepção situacional e o cenário (terreno, edificações, iluminação, veículos).",
    "ok": true
   },
   {
    "t": "a execução da resposta escolhida."
   },
   {
    "t": "o estado de ânimo e o nível de cooperação do abordado."
   }
  ],
  "resolucao": "==Gabarito: a percepção situacional e o cenário (terreno, edificações, iluminação, veículos).== Tópico 2 — 1. Perceber (o ambiente).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, 1. Perceber (o ambiente)"
 },
 {
  "id": "bz03-004",
  "disc": "Uso da Força",
  "assunto": "3. Decidir",
  "enunciado": "A etapa “Decidir” do ciclo 2PDA consiste em:",
  "alts": [
   {
    "t": "registrar a ocorrência no BO."
   },
   {
    "t": "um processo mental de julgamento para a seleção do nível de força legal, técnico e adequado.",
    "ok": true
   },
   {
    "t": "executar a resposta escolhida."
   },
   {
    "t": "analisar o terreno e a iluminação."
   }
  ],
  "resolucao": "==Gabarito: um processo mental de julgamento para a seleção do nível de força legal, técnico e adequado.== Tópico 2 — 3. Decidir.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, 3. Decidir"
 },
 {
  "id": "bz03-005",
  "disc": "Uso da Força",
  "assunto": "4. Aplicar; o modelo é dinâmico e contínuo",
  "enunciado": "Na etapa “Aplicar”, o profissional pode:",
  "alts": [
   {
    "t": "encerrar a avaliação após a primeira ação."
   },
   {
    "t": "apenas intensificar a força, nunca reduzi-la."
   },
   {
    "t": "manter, reduzir, interromper ou intensificar a força conforme a evolução da crise.",
    "ok": true
   },
   {
    "t": "apenas manter a força inicial até o fim."
   }
  ],
  "resolucao": "==Gabarito: manter, reduzir, interromper ou intensificar a força conforme a evolução da crise.== Tópico 2 — 4. Aplicar; o modelo é dinâmico e contínuo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, 4. Aplicar; o modelo é dinâmico e contínuo"
 },
 {
  "id": "bz03-006",
  "disc": "Uso da Força",
  "assunto": "Princípio da Não Discriminação",
  "enunciado": "O princípio que veda qualquer preconceito de raça, etnia, cor, gênero, orientação sexual, religião, nacionalidade, origem social ou deficiência é o da:",
  "alts": [
   {
    "t": "legalidade."
   },
   {
    "t": "não discriminação.",
    "ok": true
   },
   {
    "t": "necessidade."
   },
   {
    "t": "proporcionalidade."
   }
  ],
  "resolucao": "==Gabarito: não discriminação.== Tópico 3 — Princípio da Não Discriminação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Princípio da Não Discriminação"
 },
 {
  "id": "bz03-007",
  "disc": "Uso da Força",
  "assunto": "finalidade da intervenção",
  "enunciado": "A intervenção policial tem como foco legal preservar:",
  "alts": [
   {
    "t": "somente a integridade dos policiais."
   },
   {
    "t": "apenas a imagem da instituição."
   },
   {
    "t": "exclusivamente o patrimônio público."
   },
   {
    "t": "a ordem pública, a incolumidade física das pessoas e o patrimônio.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: a ordem pública, a incolumidade física das pessoas e o patrimônio.== Tópico 4 — finalidade da intervenção.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, finalidade da intervenção"
 },
 {
  "id": "bz03-008",
  "disc": "Uso da Força",
  "assunto": "finalidade",
  "enunciado": "A finalidade dos IMPO é servir de alternativa tática para:",
  "alts": [
   {
    "t": "causar dor como forma de punição."
   },
   {
    "t": "dispensar o registro da ocorrência."
   },
   {
    "t": "substituir o diálogo em qualquer abordagem."
   },
   {
    "t": "conter, debilitar ou incapacitar temporariamente o infrator, poupando vidas e reduzindo a letalidade.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: conter, debilitar ou incapacitar temporariamente o infrator, poupando vidas e reduzindo a letalidade.== Tópico 5 — finalidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, finalidade"
 },
 {
  "id": "bz03-009",
  "disc": "Uso da Força",
  "assunto": "técnicas de menor potencial ofensivo",
  "enunciado": "As técnicas de menor potencial ofensivo são métodos de:",
  "alts": [
   {
    "t": "vigilância eletrônica."
   },
   {
    "t": "interrogatório prolongado."
   },
   {
    "t": "imobilização, condução física e manuseio tático voltados a neutralizar a resistência sem produzir lesões graves.",
    "ok": true
   },
   {
    "t": "disparo de arma de fogo de longo alcance."
   }
  ],
  "resolucao": "==Gabarito: imobilização, condução física e manuseio tático voltados a neutralizar a resistência sem produzir lesões graves.== Tópico 5 — técnicas de menor potencial ofensivo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, técnicas de menor potencial ofensivo"
 },
 {
  "id": "bz03-010",
  "disc": "Uso da Força",
  "assunto": "IMPO de incapacitação",
  "enunciado": "Os dispositivos elétricos incapacitantes (como Spark e Taser) são exemplos de IMPO de:",
  "alts": [
   {
    "t": "debilitação, por reduzirem a energia da pessoa."
   },
   {
    "t": "incapacitação, pois atuam no sistema neuromuscular, provocando perda do controle motor.",
    "ok": true
   },
   {
    "t": "contenção física sem equipamento."
   },
   {
    "t": "munição de impacto controlado."
   }
  ],
  "resolucao": "==Gabarito: incapacitação, pois atuam no sistema neuromuscular, provocando perda do controle motor.== Tópico 6 — IMPO de incapacitação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, IMPO de incapacitação"
 },
 {
  "id": "bz03-011",
  "disc": "Uso da Força",
  "assunto": "Necessidade",
  "enunciado": "O princípio do uso da força que determina o emprego apenas quando não houver outra opção menos gravosa (último recurso viável) é o da:",
  "alts": [
   {
    "t": "legalidade."
   },
   {
    "t": "necessidade.",
    "ok": true
   },
   {
    "t": "razoabilidade."
   },
   {
    "t": "precaução."
   }
  ],
  "resolucao": "==Gabarito: necessidade.== Tópico 7 — Necessidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Necessidade"
 },
 {
  "id": "bz03-012",
  "disc": "Uso da Força",
  "assunto": "Razoabilidade",
  "enunciado": "O princípio que se traduz em bom senso, prudência e equilíbrio (ato lógico e moderado) é o da:",
  "alts": [
   {
    "t": "necessidade."
   },
   {
    "t": "precaução."
   },
   {
    "t": "não discriminação."
   },
   {
    "t": "razoabilidade.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: razoabilidade.== Tópico 7 — Razoabilidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Razoabilidade"
 },
 {
  "id": "bz03-013",
  "disc": "Uso da Força",
  "assunto": "Responsabilização",
  "enunciado": "O princípio que envolve devido processo legal, prestação de contas e ampla defesa, com apuração de excessos e abusos, é o da:",
  "alts": [
   {
    "t": "legalidade."
   },
   {
    "t": "precaução."
   },
   {
    "t": "proporcionalidade."
   },
   {
    "t": "responsabilização.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: responsabilização.== Tópico 7 — Responsabilização.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Responsabilização"
 },
 {
  "id": "bz03-014",
  "disc": "Uso da Força",
  "assunto": "Resistente passivo",
  "enunciado": "O abordado que se recusa a cumprir a determinação legal, sem violência ou ameaça (permanece estático, deita no chão, não sai do carro), é:",
  "alts": [
   {
    "t": "resistente ativo com agressão potencialmente letal."
   },
   {
    "t": "resistente passivo.",
    "ok": true
   },
   {
    "t": "resistente ativo."
   },
   {
    "t": "cooperativo."
   }
  ],
  "resolucao": "==Gabarito: resistente passivo.== Tópico 8 — Resistente passivo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Resistente passivo"
 },
 {
  "id": "bz03-015",
  "disc": "Uso da Força",
  "assunto": "Resistente ativo com agressão não letal",
  "enunciado": "Socos e arremesso de objetos contra a equipe, sem instrumentos de letalidade imediata, caracterizam o resistente:",
  "alts": [
   {
    "t": "cooperativo."
   },
   {
    "t": "ativo com agressão não letal.",
    "ok": true
   },
   {
    "t": "passivo."
   },
   {
    "t": "ativo com agressão potencialmente letal."
   }
  ],
  "resolucao": "==Gabarito: ativo com agressão não letal.== Tópico 8 — Resistente ativo com agressão não letal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Resistente ativo com agressão não letal"
 },
 {
  "id": "bz03-016",
  "disc": "Uso da Força",
  "assunto": "Resistente ativo com agressão potencialmente letal",
  "enunciado": "Agressão com arma de fogo, arma branca ou objeto capaz de gerar risco real de morte ou lesão grave caracteriza o resistente:",
  "alts": [
   {
    "t": "cooperativo."
   },
   {
    "t": "passivo."
   },
   {
    "t": "ativo com agressão não letal."
   },
   {
    "t": "ativo com agressão potencialmente letal.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: ativo com agressão potencialmente letal.== Tópico 8 — Resistente ativo com agressão potencialmente letal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Resistente ativo com agressão potencialmente letal"
 },
 {
  "id": "bz03-017",
  "disc": "Uso da Força",
  "assunto": "quando não usar",
  "enunciado": "É hipótese em que NÃO se deve usar o IMPO:",
  "alts": [
   {
    "t": "diante de resistência ativa com verbalização insuficiente."
   },
   {
    "t": "contra abordados em atitude puramente cooperativa.",
    "ok": true
   },
   {
    "t": "diante de agressão física quando a contenção de contato falhou."
   },
   {
    "t": "como alternativa antes da força letal, sem risco extra."
   }
  ],
  "resolucao": "==Gabarito: contra abordados em atitude puramente cooperativa.== Tópico 9 — quando não usar.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, quando não usar"
 },
 {
  "id": "bz03-018",
  "disc": "Uso da Força",
  "assunto": "descontaminação",
  "enunciado": "Após o uso de agentes químicos/lacrimogêneos, a descontaminação inclui:",
  "alts": [
   {
    "t": "manter o indivíduo no ambiente para que o efeito passe."
   },
   {
    "t": "aplicar novo agente para neutralizar o primeiro."
   },
   {
    "t": "deixar de avaliar a necessidade de socorro médico."
   },
   {
    "t": "remover o indivíduo do ambiente saturado, ventilar o local e lavar as partes afetadas com água corrente.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: remover o indivíduo do ambiente saturado, ventilar o local e lavar as partes afetadas com água corrente.== Tópico 11 — descontaminação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, descontaminação"
 },
 {
  "id": "bz03-019",
  "disc": "Uso da Força",
  "assunto": "algemas",
  "enunciado": "Quanto ao uso de algemas, a regra geral é que:",
  "alts": [
   {
    "t": "são vedadas em qualquer circunstância."
   },
   {
    "t": "devem ser usadas em todos os abordados."
   },
   {
    "t": "podem ser usadas sem qualquer justificativa."
   },
   {
    "t": "se trata de medida excepcional, cuja necessidade deve ser justificada por escrito no registro da ocorrência.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: se trata de medida excepcional, cuja necessidade deve ser justificada por escrito no registro da ocorrência.== Tópico 12 — algemas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, algemas"
 },
 {
  "id": "bz03-020",
  "disc": "Uso da Força",
  "assunto": "requisitos",
  "enunciado": "São requisitos para o uso de algemas:",
  "alts": [
   {
    "t": "apenas o horário noturno."
   },
   {
    "t": "resistência à ordem legal, fundado receio de fuga ou perigo à integridade física própria ou alheia.",
    "ok": true
   },
   {
    "t": "somente a gravidade da pena do crime."
   },
   {
    "t": "a vontade pessoal do policial."
   }
  ],
  "resolucao": "==Gabarito: resistência à ordem legal, fundado receio de fuga ou perigo à integridade física própria ou alheia.== Tópico 12 — requisitos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, requisitos"
 },
 {
  "id": "bz03-021",
  "disc": "Uso da Força",
  "assunto": "arma de fogo (regra geral)",
  "enunciado": "Pela regra geral da Portaria 855/2025, a renovação da habilitação para arma de fogo ocorre a cada:",
  "alts": [
   {
    "t": "06 meses."
   },
   {
    "t": "05 anos."
   },
   {
    "t": "10 anos."
   },
   {
    "t": "02 anos, mediante aprovação em exames técnicos e psicológicos.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 02 anos, mediante aprovação em exames técnicos e psicológicos.== Tópico 13 — arma de fogo (regra geral).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, arma de fogo (regra geral)"
 },
 {
  "id": "bz03-022",
  "disc": "Uso da Força",
  "assunto": "IMPO",
  "enunciado": "A capacitação e a reciclagem para uso e porte dos IMPO devem ser realizadas, preferencialmente, de forma:",
  "alts": [
   {
    "t": "trienal e à distância."
   },
   {
    "t": "única, no curso de formação."
   },
   {
    "t": "anual e presencial.",
    "ok": true
   },
   {
    "t": "bienal e à distância."
   }
  ],
  "resolucao": "==Gabarito: anual e presencial.== Tópico 13 — IMPO.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, IMPO"
 },
 {
  "id": "bz03-023",
  "disc": "Uso da Força",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O ciclo 2PDA é um processo dinâmico e contínuo de avaliação e reavaliação.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — Modelo SENASP."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — Modelo SENASP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 2"
 },
 {
  "id": "bz03-024",
  "disc": "Uso da Força",
  "assunto": "Tópico 3",
  "enunciado": "(Certo ou Errado) O princípio da não discriminação admite tratamento diferenciado em razão de origem social ou religião.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3 — é vedado qualquer preconceito, inclusive de origem social e religião."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3 — é vedado qualquer preconceito, inclusive de origem social e religião.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 3"
 },
 {
  "id": "bz03-025",
  "disc": "Uso da Força",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) A finalidade da intervenção policial é preservar a ordem pública, a incolumidade física das pessoas e o patrimônio.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — finalidade da intervenção."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — finalidade da intervenção.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 4"
 },
 {
  "id": "bz03-026",
  "disc": "Uso da Força",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Os IMPO de incapacitação reduzem temporariamente a capacidade combativa por meio de espargidores químicos (OC/CS).",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — espargidores são de debilitação; os de incapacitação atuam no sistema neuromuscular."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — espargidores são de debilitação; os de incapacitação atuam no sistema neuromuscular.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 6"
 },
 {
  "id": "bz03-027",
  "disc": "Uso da Força",
  "assunto": "Tópico 7",
  "enunciado": "(Certo ou Errado) Pelo princípio da necessidade, a força só deve ser usada quando os meios menores forem insuficientes.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 7 — Necessidade."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 7 — Necessidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 7"
 },
 {
  "id": "bz03-028",
  "disc": "Uso da Força",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) O resistente passivo é aquele que emprega violência física contra a equipe.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 8 — passivo = recusa sem violência ou ameaça; violência física é resistência ativa com agressão."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 8 — passivo = recusa sem violência ou ameaça; violência física é resistência ativa com agressão.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 8"
 },
 {
  "id": "bz03-029",
  "disc": "Uso da Força",
  "assunto": "Tópico 9",
  "enunciado": "(Certo ou Errado) O IMPO pode ser usado como instrumento de castigo ou punição prévia ao abordado.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 9 — é vedado o uso como castigo, tortura ou punição prévia."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 9 — é vedado o uso como castigo, tortura ou punição prévia.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 9"
 },
 {
  "id": "bz03-030",
  "disc": "Uso da Força",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) As técnicas de desescalonamento atuam como um freio tático para impedir a evolução do ciclo de agressão.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 10 — desescalonamento."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 10 — desescalonamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 10"
 },
 {
  "id": "bz03-031",
  "disc": "Uso da Força",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) Após o uso de IMPO, é obrigatório facilitar o atendimento médico ou conduzir o indivíduo à avaliação médica caso haja sintomas graves, ferimentos ou complicações.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 11 — socorro e assistência médica."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 11 — socorro e assistência médica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 11"
 },
 {
  "id": "bz03-032",
  "disc": "Uso da Força",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) O uso de algemas é regra geral em qualquer abordagem, dispensando justificativa por escrito.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 12 — o uso é excepcional e deve ser justificado detalhadamente por escrito."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 12 — o uso é excepcional e deve ser justificado detalhadamente por escrito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 12"
 },
 {
  "id": "bz03-033",
  "disc": "Uso da Força",
  "assunto": "Tópico 14",
  "enunciado": "(Certo ou Errado) Os equipamentos e EPIs usados com agentes químicos, cartuchos elétricos e projéteis de elastômero devem estar dentro do prazo de validade estipulado pelo fabricante.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 14 — validade dos equipamentos."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 14 — validade dos equipamentos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 3, Tópico 14"
 }
]);
