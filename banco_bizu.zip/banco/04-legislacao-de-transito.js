/* Disciplina: Legislação de Trânsito (45 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz04-001",
  "disc": "Legislação de Trânsito",
  "assunto": "Agente de trânsito",
  "enunciado": "O Agente de Trânsito, em sentido estrito, é:",
  "alts": [
   {
    "t": "somente o policial militar da reserva."
   },
   {
    "t": "qualquer cidadão credenciado pelo município."
   },
   {
    "t": "o servidor civil efetivo de carreira do órgão executivo de trânsito ou rodoviário (Detran, Agesul, Agetran, DNIT).",
    "ok": true
   },
   {
    "t": "o motorista de viatura oficial."
   }
  ],
  "resolucao": "==Gabarito: o servidor civil efetivo de carreira do órgão executivo de trânsito ou rodoviário (Detran, Agesul, Agetran, DNIT).== Tópico 1.1 — Agente de trânsito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Agente de trânsito"
 },
 {
  "id": "bz04-002",
  "disc": "Legislação de Trânsito",
  "assunto": "Agente da Autoridade de Trânsito",
  "enunciado": "O conceito de Agente da Autoridade de Trânsito, mais amplo, engloba:",
  "alts": [
   {
    "t": "apenas agentes civis do Detran."
   },
   {
    "t": "agentes civis de trânsito, PRF, policiais militares da ativa (mediante convênio) e guardas municipais.",
    "ok": true
   },
   {
    "t": "qualquer policial militar, mesmo sem convênio."
   },
   {
    "t": "somente policiais rodoviários federais."
   }
  ],
  "resolucao": "==Gabarito: agentes civis de trânsito, PRF, policiais militares da ativa (mediante convênio) e guardas municipais.== Tópico 1.1 — Agente da Autoridade de Trânsito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Agente da Autoridade de Trânsito"
 },
 {
  "id": "bz04-003",
  "disc": "Legislação de Trânsito",
  "assunto": "convênio e credenciamento",
  "enunciado": "É requisito para o PM atuar na fiscalização de trânsito:",
  "alts": [
   {
    "t": "convênio vigente entre a SEJUSP/PMMS e o órgão executivo com circunscrição sobre a via, e credenciamento publicado no DOE-MS.",
    "ok": true
   },
   {
    "t": "autorização verbal do comandante da viatura."
   },
   {
    "t": "possuir veículo particular caracterizado."
   },
   {
    "t": "estar de folga e à paisana."
   }
  ],
  "resolucao": "==Gabarito: convênio vigente entre a SEJUSP/PMMS e o órgão executivo com circunscrição sobre a via, e credenciamento publicado no DOE-MS.== Tópico 1.2 — convênio e credenciamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, convênio e credenciamento"
 },
 {
  "id": "bz04-004",
  "disc": "Legislação de Trânsito",
  "assunto": "diferença entre policiamento e fiscalização",
  "enunciado": "O policiamento ostensivo de trânsito, em comparação com a fiscalização, é:",
  "alts": [
   {
    "t": "atividade típica de segurança pública, executada primordialmente pelas Polícias Militares.",
    "ok": true
   },
   {
    "t": "atribuição privativa do CONTRAN."
   },
   {
    "t": "função exclusiva do Detran."
   },
   {
    "t": "polícia administrativa, atribuição original dos órgãos executivos de trânsito."
   }
  ],
  "resolucao": "==Gabarito: atividade típica de segurança pública, executada primordialmente pelas Polícias Militares.== Tópico 2 — diferença entre policiamento e fiscalização.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, diferença entre policiamento e fiscalização"
 },
 {
  "id": "bz04-005",
  "disc": "Legislação de Trânsito",
  "assunto": "segurança viária",
  "enunciado": "Segundo o Art. 144 da CF/88, a segurança viária compreende:",
  "alts": [
   {
    "t": "apenas o policiamento ostensivo."
   },
   {
    "t": "exclusivamente a engenharia de tráfego."
   },
   {
    "t": "somente a aplicação de multas."
   },
   {
    "t": "educação, engenharia e fiscalização de trânsito.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: educação, engenharia e fiscalização de trânsito.== Tópico 3 — segurança viária.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, segurança viária"
 },
 {
  "id": "bz04-006",
  "disc": "Legislação de Trânsito",
  "assunto": "implicação prática",
  "enunciado": "Como consequência da competência privativa da União, os Estados e Municípios:",
  "alts": [
   {
    "t": "podem revogar artigos do CTB."
   },
   {
    "t": "podem criar livremente novas infrações."
   },
   {
    "t": "podem alterar as penalidades do CTB."
   },
   {
    "t": "não podem criar infrações, penalidades ou normas gerais de trânsito que inovem sobre o CTB.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: não podem criar infrações, penalidades ou normas gerais de trânsito que inovem sobre o CTB.== Tópico 4 — implicação prática.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, implicação prática"
 },
 {
  "id": "bz04-007",
  "disc": "Legislação de Trânsito",
  "assunto": "vigência do CTB",
  "enunciado": "O CTB entrou em vigor em:",
  "alts": [
   {
    "t": "5 de outubro de 1988."
   },
   {
    "t": "23 de setembro de 1997."
   },
   {
    "t": "1º de janeiro de 2000."
   },
   {
    "t": "22 de janeiro de 1998.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 22 de janeiro de 1998.== Tópico 5 — vigência do CTB.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, vigência do CTB"
 },
 {
  "id": "bz04-008",
  "disc": "Legislação de Trânsito",
  "assunto": "CETRAN e CONTRANDIFE",
  "enunciado": "Os Conselhos Estaduais e do DF, normativos, consultivos e coordenadores regionais, são:",
  "alts": [
   {
    "t": "DNIT e DER."
   },
   {
    "t": "CETRAN e CONTRANDIFE.",
    "ok": true
   },
   {
    "t": "JARI e SENATRAN."
   },
   {
    "t": "Detran e AGETRAN."
   }
  ],
  "resolucao": "==Gabarito: CETRAN e CONTRANDIFE.== Tópico 6 — CETRAN e CONTRANDIFE.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, CETRAN e CONTRANDIFE"
 },
 {
  "id": "bz04-009",
  "disc": "Legislação de Trânsito",
  "assunto": "órgãos executivos rodoviários",
  "enunciado": "São órgãos executivos rodoviários:",
  "alts": [
   {
    "t": "DNIT (federal), DER/AGESUL (estadual/DF) e órgãos rodoviários municipais.",
    "ok": true
   },
   {
    "t": "CONTRAN e CETRAN."
   },
   {
    "t": "JARI e CONTRANDIFE."
   },
   {
    "t": "SENATRAN e DETRAN."
   }
  ],
  "resolucao": "==Gabarito: DNIT (federal), DER/AGESUL (estadual/DF) e órgãos rodoviários municipais.== Tópico 6 — órgãos executivos rodoviários.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, órgãos executivos rodoviários"
 },
 {
  "id": "bz04-010",
  "disc": "Legislação de Trânsito",
  "assunto": "normativos x executivos",
  "enunciado": "A função de criar resoluções, deliberar e regulamentar a legislação de trânsito cabe aos órgãos:",
  "alts": [
   {
    "t": "executivos (SENATRAN, DETRAN e DNIT)."
   },
   {
    "t": "à Polícia Militar."
   },
   {
    "t": "aos guardas municipais."
   },
   {
    "t": "normativos e consultivos (CONTRAN, CETRAN e CONTRANDIFE).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: normativos e consultivos (CONTRAN, CETRAN e CONTRANDIFE).== Tópico 7 — normativos x executivos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, normativos x executivos"
 },
 {
  "id": "bz04-011",
  "disc": "Legislação de Trânsito",
  "assunto": "competência das PMs",
  "enunciado": "A competência da PM na fiscalização de trânsito é a de executá-la:",
  "alts": [
   {
    "t": "quando e conforme convênio firmado, como agente concomitantemente com os demais agentes credenciados.",
    "ok": true
   },
   {
    "t": "apenas em eventos esportivos."
   },
   {
    "t": "de forma originária, independentemente de convênio."
   },
   {
    "t": "somente nas rodovias federais."
   }
  ],
  "resolucao": "==Gabarito: quando e conforme convênio firmado, como agente concomitantemente com os demais agentes credenciados.== Tópico 8 — competência das PMs.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, competência das PMs"
 },
 {
  "id": "bz04-012",
  "disc": "Legislação de Trânsito",
  "assunto": "condição indispensável",
  "enunciado": "Os veículos de emergência gozam de prioridade de passagem, livre circulação, livre parada e livre estacionamento, desde que:",
  "alts": [
   {
    "t": "estejam fora de serviço."
   },
   {
    "t": "o condutor esteja à paisana."
   },
   {
    "t": "estejam no efetivo serviço de urgência, de policiamento ostensivo ou de preservação da ordem pública.",
    "ok": true
   },
   {
    "t": "tenham apenas o giroflex desligado."
   }
  ],
  "resolucao": "==Gabarito: estejam no efetivo serviço de urgência, de policiamento ostensivo ou de preservação da ordem pública.== Tópico 9 — condição indispensável.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, condição indispensável"
 },
 {
  "id": "bz04-013",
  "disc": "Legislação de Trânsito",
  "assunto": "livre estacionamento",
  "enunciado": "Para o livre estacionamento, o veículo de emergência necessita de:",
  "alts": [
   {
    "t": "somente sirene."
   },
   {
    "t": "sirene e giroflex."
   },
   {
    "t": "apenas iluminação intermitente (giroflex).",
    "ok": true
   },
   {
    "t": "nenhum sinal."
   }
  ],
  "resolucao": "==Gabarito: apenas iluminação intermitente (giroflex).== Tópico 9 — livre estacionamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, livre estacionamento"
 },
 {
  "id": "bz04-014",
  "disc": "Legislação de Trânsito",
  "assunto": "responsabilidade pelas infrações",
  "enunciado": "O proprietário do veículo é responsável pela:",
  "alts": [
   {
    "t": "habilitação de qualquer cidadão."
   },
   {
    "t": "direção do veículo, mesmo quando outro conduz."
   },
   {
    "t": "infração de excesso de peso, sempre."
   },
   {
    "t": "regularidade documental, habilitação dos condutores que autorizar a dirigir, equipamentos obrigatórios e estado de conservação.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: regularidade documental, habilitação dos condutores que autorizar a dirigir, equipamentos obrigatórios e estado de conservação.== Tópico 10 — responsabilidade pelas infrações.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, responsabilidade pelas infrações"
 },
 {
  "id": "bz04-015",
  "disc": "Legislação de Trânsito",
  "assunto": "transportador",
  "enunciado": "O transportador responde pelo excesso de peso quando:",
  "alts": [
   {
    "t": "transportar carga de mais de um embarcador.",
    "ok": true
   },
   {
    "t": "o condutor estiver de folga."
   },
   {
    "t": "for o único remetente da carga."
   },
   {
    "t": "o proprietário for pessoa jurídica."
   }
  ],
  "resolucao": "==Gabarito: transportar carga de mais de um embarcador.== Tópico 10 — transportador.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, transportador"
 },
 {
  "id": "bz04-016",
  "disc": "Legislação de Trânsito",
  "assunto": "AIT",
  "enunciado": "O AIT é uma peça informativa que:",
  "alts": [
   {
    "t": "substitui o Boletim de Ocorrência criminal."
   },
   {
    "t": "subsidia a Autoridade de Trânsito na instauração do processo administrativo e na aplicação das penalidades.",
    "ok": true
   },
   {
    "t": "aplica diretamente a multa ao condutor."
   },
   {
    "t": "dispensa a atuação da Autoridade de Trânsito."
   }
  ],
  "resolucao": "==Gabarito: subsidia a Autoridade de Trânsito na instauração do processo administrativo e na aplicação das penalidades.== Tópico 11 — AIT.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, AIT"
 },
 {
  "id": "bz04-017",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 11",
  "enunciado": "Quando há infrações com a mesma raiz (mesmos 3 primeiros dígitos), lavra-se:",
  "alts": [
   {
    "t": "dois AITs com numeração distinta."
   },
   {
    "t": "um AIT para cada infração."
   },
   {
    "t": "apenas uma autuação, anotando-se a segunda em observações.",
    "ok": true
   },
   {
    "t": "nenhum AIT."
   }
  ],
  "resolucao": "==Gabarito: apenas uma autuação, anotando-se a segunda em observações.== Tópico 11 — infrações com a mesma raiz (ex.: falta de estepe e extintor inoperante).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 11"
 },
 {
  "id": "bz04-018",
  "disc": "Legislação de Trânsito",
  "assunto": "concorrentes",
  "enunciado": "Nas infrações concorrentes, lavra-se:",
  "alts": [
   {
    "t": "um AIT para cada infração."
   },
   {
    "t": "nenhum auto."
   },
   {
    "t": "um auto por dia de infração."
   },
   {
    "t": "apenas uma autuação (a mais específica ou mais gravosa).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: apenas uma autuação (a mais específica ou mais gravosa).== Tópico 12 — concorrentes.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, concorrentes"
 },
 {
  "id": "bz04-019",
  "disc": "Legislação de Trânsito",
  "assunto": "continuadas",
  "enunciado": "Transitar pela contramão por vários cruzamentos em sequência é exemplo de infração:",
  "alts": [
   {
    "t": "concorrente."
   },
   {
    "t": "concomitante."
   },
   {
    "t": "continuada.",
    "ok": true
   },
   {
    "t": "sucessiva."
   }
  ],
  "resolucao": "==Gabarito: continuada.== Tópico 12 — continuadas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, continuadas"
 },
 {
  "id": "bz04-020",
  "disc": "Legislação de Trânsito",
  "assunto": "classificação das infrações",
  "enunciado": "Conforme a tabela de classificação das infrações, a infração de natureza GRAVE vale:",
  "alts": [
   {
    "t": "7 pontos e R$ 293,47."
   },
   {
    "t": "5 pontos e R$ 195,23.",
    "ok": true
   },
   {
    "t": "3 pontos e R$ 88,38."
   },
   {
    "t": "4 pontos e R$ 130,16."
   }
  ],
  "resolucao": "==Gabarito: 5 pontos e R$ 195,23.== Tópico 13 — classificação das infrações.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, classificação das infrações"
 },
 {
  "id": "bz04-021",
  "disc": "Legislação de Trânsito",
  "assunto": "classificação das infrações",
  "enunciado": "A infração de natureza MÉDIA vale:",
  "alts": [
   {
    "t": "7 pontos e R$ 293,47."
   },
   {
    "t": "4 pontos e R$ 130,16.",
    "ok": true
   },
   {
    "t": "5 pontos e R$ 195,23."
   },
   {
    "t": "3 pontos e R$ 88,38."
   }
  ],
  "resolucao": "==Gabarito: 4 pontos e R$ 130,16.== Tópico 13 — classificação das infrações.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, classificação das infrações"
 },
 {
  "id": "bz04-022",
  "disc": "Legislação de Trânsito",
  "assunto": "medidas administrativas",
  "enunciado": "As medidas administrativas, segundo a apostila, são:",
  "alts": [
   {
    "t": "penas aplicadas no fim do processo."
   },
   {
    "t": "providências preventivas e coercitivas de execução imediata pelo agente no local da infração (não são penas).",
    "ok": true
   },
   {
    "t": "penalidades aplicadas somente pela JARI."
   },
   {
    "t": "sanções criminais."
   }
  ],
  "resolucao": "==Gabarito: providências preventivas e coercitivas de execução imediata pelo agente no local da infração (não são penas).== Tópico 14 — medidas administrativas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, medidas administrativas"
 },
 {
  "id": "bz04-023",
  "disc": "Legislação de Trânsito",
  "assunto": "remoção",
  "enunciado": "Na remoção do veículo, quando não oferecer risco, o prazo de liberação para sanar a irregularidade é de até:",
  "alts": [
   {
    "t": "30 dias, sem exceção."
   },
   {
    "t": "5 dias, sem exceção."
   },
   {
    "t": "15 dias (exceto licenciamento vencido e transporte clandestino remunerado).",
    "ok": true
   },
   {
    "t": "90 dias."
   }
  ],
  "resolucao": "==Gabarito: 15 dias (exceto licenciamento vencido e transporte clandestino remunerado).== Tópico 14 — remoção.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, remoção"
 },
 {
  "id": "bz04-024",
  "disc": "Legislação de Trânsito",
  "assunto": "documentos digitais",
  "enunciado": "Em documentos digitais (CNH-e / CRLV-e), o “recolhimento” se dá por meio de:",
  "alts": [
   {
    "t": "apreensão do celular do condutor."
   },
   {
    "t": "multa imediata."
   },
   {
    "t": "bloqueio administrativo eletrônico no RENACH ou RENAVAM.",
    "ok": true
   },
   {
    "t": "retirada física da CNH impressa."
   }
  ],
  "resolucao": "==Gabarito: bloqueio administrativo eletrônico no RENACH ou RENAVAM.== Tópico 14 — documentos digitais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, documentos digitais"
 },
 {
  "id": "bz04-025",
  "disc": "Legislação de Trânsito",
  "assunto": "porte de documentos",
  "enunciado": "São documentos de porte obrigatório do condutor:",
  "alts": [
   {
    "t": "documento de habilitação (CNH, PPD ou ACC) e CRLV/CLA.",
    "ok": true
   },
   {
    "t": "somente o título de eleitor."
   },
   {
    "t": "o passaporte, sempre."
   },
   {
    "t": "apenas o CPF."
   }
  ],
  "resolucao": "==Gabarito: documento de habilitação (CNH, PPD ou ACC) e CRLV/CLA.== Tópico 16 — porte de documentos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, porte de documentos"
 },
 {
  "id": "bz04-026",
  "disc": "Legislação de Trânsito",
  "assunto": "atos vinculados",
  "enunciado": "A lavratura do AIT é ato administrativo:",
  "alts": [
   {
    "t": "estritamente vinculado, sem discricionariedade do agente.",
    "ok": true
   },
   {
    "t": "dependente da concordância do infrator."
   },
   {
    "t": "facultativo em infrações leves."
   },
   {
    "t": "discricionário, a critério do agente."
   }
  ],
  "resolucao": "==Gabarito: estritamente vinculado, sem discricionariedade do agente.== Tópico 17 — atos vinculados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, atos vinculados"
 },
 {
  "id": "bz04-027",
  "disc": "Legislação de Trânsito",
  "assunto": "CNH com valor de identidade",
  "enunciado": "A CNH, quanto à identificação civil:",
  "alts": [
   {
    "t": "tem fé pública e valor de identidade em todo o território nacional, mesmo com exame médico vencido.",
    "ok": true
   },
   {
    "t": "só vale no estado emissor."
   },
   {
    "t": "perde o valor de identidade se o exame médico estiver vencido."
   },
   {
    "t": "nunca vale como identidade."
   }
  ],
  "resolucao": "==Gabarito: tem fé pública e valor de identidade em todo o território nacional, mesmo com exame médico vencido.== Tópico 18 — CNH com valor de identidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, CNH com valor de identidade"
 },
 {
  "id": "bz04-028",
  "disc": "Legislação de Trânsito",
  "assunto": "advertência por escrito",
  "enunciado": "A advertência por escrito pode ser aplicada a infrações de natureza leve ou média, se o infrator:",
  "alts": [
   {
    "t": "não tiver cometido nenhuma outra infração nos últimos 12 meses.",
    "ok": true
   },
   {
    "t": "for primário em crime."
   },
   {
    "t": "estiver com a CNH vencida."
   },
   {
    "t": "tiver mais de 60 anos."
   }
  ],
  "resolucao": "==Gabarito: não tiver cometido nenhuma outra infração nos últimos 12 meses.== Tópico 19 — advertência por escrito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, advertência por escrito"
 },
 {
  "id": "bz04-029",
  "disc": "Legislação de Trânsito",
  "assunto": "Art. 306",
  "enunciado": "A pena do crime do Art. 306 do CTB (embriaguez ao volante) é:",
  "alts": [
   {
    "t": "detenção de 6 meses a 3 anos, multa e suspensão/proibição do direito de dirigir.",
    "ok": true
   },
   {
    "t": "apenas multa."
   },
   {
    "t": "detenção de 6 meses a 1 ano, ou multa."
   },
   {
    "t": "reclusão de 1 a 2 anos."
   }
  ],
  "resolucao": "==Gabarito: detenção de 6 meses a 3 anos, multa e suspensão/proibição do direito de dirigir.== Tópico 20 — Art. 306.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Art. 306"
 },
 {
  "id": "bz04-030",
  "disc": "Legislação de Trânsito",
  "assunto": "critérios técnicos",
  "enunciado": "No exame de sangue, a concentração que configura o Art. 306 é igual ou superior a:",
  "alts": [
   {
    "t": "1 dg/L."
   },
   {
    "t": "20 dg/L."
   },
   {
    "t": "6 decigramas de álcool por litro de sangue (6 dg/L).",
    "ok": true
   },
   {
    "t": "2 dg/L."
   }
  ],
  "resolucao": "==Gabarito: 6 decigramas de álcool por litro de sangue (6 dg/L).== Tópico 20 — critérios técnicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, critérios técnicos"
 },
 {
  "id": "bz04-031",
  "disc": "Legislação de Trânsito",
  "assunto": "sinais clínicos",
  "enunciado": "Se o condutor apresentar apenas um sinal isolado (odor etílico), autua-se:",
  "alts": [
   {
    "t": "no Art. 165-A, sem configurar o crime do Art. 306.",
    "ok": true
   },
   {
    "t": "em nenhuma infração."
   },
   {
    "t": "no Art. 309."
   },
   {
    "t": "no Art. 306, com prisão em flagrante."
   }
  ],
  "resolucao": "==Gabarito: no Art. 165-A, sem configurar o crime do Art. 306.== Tópico 20 — sinais clínicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, sinais clínicos"
 },
 {
  "id": "bz04-032",
  "disc": "Legislação de Trânsito",
  "assunto": "critério de perigo",
  "enunciado": "O crime do Art. 309 é considerado de:",
  "alts": [
   {
    "t": "dano consumado."
   },
   {
    "t": "perigo concreto, exigindo que a conduta gere perigo real e demonstrado de dano.",
    "ok": true
   },
   {
    "t": "mera conduta, sem resultado."
   },
   {
    "t": "perigo abstrato, sem necessidade de prova."
   }
  ],
  "resolucao": "==Gabarito: perigo concreto, exigindo que a conduta gere perigo real e demonstrado de dano.== Tópico 20 — critério de perigo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, critério de perigo"
 },
 {
  "id": "bz04-033",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 1.2",
  "enunciado": "(Certo ou Errado) O PM, em viatura caracterizada e fardado, com convênio vigente e credenciamento no DOE-MS, pode lavrar AIT.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1.2 — requisitos obrigatórios."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1.2 — requisitos obrigatórios.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 1.2"
 },
 {
  "id": "bz04-034",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) A PM possui competência originária para a fiscalização administrativa de trânsito.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 8 — a PM NÃO tem competência originária; atua por delegação e em cooperação técnica."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 8 — a PM NÃO tem competência originária; atua por delegação e em cooperação técnica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 8"
 },
 {
  "id": "bz04-035",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) Os Estados e Municípios podem criar infrações de trânsito que inovem sobre o CTB.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 4 — competência privativa da União."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 4 — competência privativa da União.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 4"
 },
 {
  "id": "bz04-036",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 9",
  "enunciado": "(Certo ou Errado) Os veículos de emergência podem estacionar livremente com apenas a iluminação intermitente ligada, desde que em efetivo serviço.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 9 — livre estacionamento."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 9 — livre estacionamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 9"
 },
 {
  "id": "bz04-037",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) O transportador responde pelo excesso de peso quando for o único remetente da carga.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 10 — quem responde nesse caso é o embarcador; o transportador responde quando transporta carga de mais de um embarcador."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 10 — quem responde nesse caso é o embarcador; o transportador responde quando transporta carga de mais de um embarcador.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 10"
 },
 {
  "id": "bz04-038",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) Cada AIT deve registrar apenas 1 infração.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 11 — requisitos formais."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 11 — requisitos formais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 11"
 },
 {
  "id": "bz04-039",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) Infrações concomitantes ensejam um único AIT, pois são cometidas simultaneamente.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 12 — concomitantes têm previsões legais independentes: lavram-se AITs distintos."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 12 — concomitantes têm previsões legais independentes: lavram-se AITs distintos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 12"
 },
 {
  "id": "bz04-040",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 14",
  "enunciado": "(Certo ou Errado) As medidas administrativas são penas aplicadas ao final do processo administrativo.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 14 — são providências preventivas e coercitivas de execução imediata, não penas."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 14 — são providências preventivas e coercitivas de execução imediata, não penas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 14"
 },
 {
  "id": "bz04-041",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 18",
  "enunciado": "(Certo ou Errado) A CNH física na versão papel-moeda, para o porte na condução, não pode estar plastificada.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 18 — CNH com valor de identidade."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 18 — CNH com valor de identidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 18"
 },
 {
  "id": "bz04-042",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 19",
  "enunciado": "(Certo ou Errado) A cassação da CNH significa a perda definitiva da carteira.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 19 — penalidades."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 19 — penalidades.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 19"
 },
 {
  "id": "bz04-043",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 20",
  "enunciado": "(Certo ou Errado) Se o condutor apresentar apenas o odor etílico, configura-se automaticamente o crime do Art. 306.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 20 — com um único sinal autua-se no Art. 165-A, sem crime do Art. 306."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 20 — com um único sinal autua-se no Art. 165-A, sem crime do Art. 306.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 20"
 },
 {
  "id": "bz04-044",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 20",
  "enunciado": "(Certo ou Errado) A pessoa inabilitada que dirige com prudência, sem gerar perigo de dano, comete apenas infração administrativa.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 20 — Art. 309 (perigo concreto)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 20 — Art. 309 (perigo concreto).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 20"
 },
 {
  "id": "bz04-045",
  "disc": "Legislação de Trânsito",
  "assunto": "Tópico 21",
  "enunciado": "(Certo ou Errado) A apreensão do veículo continua sendo medida administrativa válida na legislação de trânsito.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 21 — foi expressamente revogada; é pegadinha de prova."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 21 — foi expressamente revogada; é pegadinha de prova.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 4, Tópico 21"
 }
]);
