/* Disciplina: Armamento e Munição I (22 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz05-001",
  "disc": "Armamento e Munição I",
  "assunto": "manuseio seguro",
  "enunciado": "As normas de segurança com armas de fogo devem ser incutidas pela repetição constante na instrução até que:",
  "alts": [
   {
    "t": "o policial deixe de usar arma."
   },
   {
    "t": "o instrutor dispense os exercícios."
   },
   {
    "t": "sua observância se torne um ato reflexo no manuseio.",
    "ok": true
   },
   {
    "t": "o armamento seja substituído."
   }
  ],
  "resolucao": "==Gabarito: sua observância se torne um ato reflexo no manuseio.== Tópico 1 — manuseio seguro.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, manuseio seguro"
 },
 {
  "id": "bz05-002",
  "disc": "Armamento e Munição I",
  "assunto": "regras de segurança",
  "enunciado": "A regra de segurança que determina tratar a arma em qualquer circunstância é:",
  "alts": [
   {
    "t": "tratar como se SEMPRE estivesse carregada.",
    "ok": true
   },
   {
    "t": "tratar como carregada apenas no estande."
   },
   {
    "t": "tratar como descarregada se estiver no coldre."
   },
   {
    "t": "tratar como brinquedo fora de serviço."
   }
  ],
  "resolucao": "==Gabarito: tratar como se SEMPRE estivesse carregada.== Tópico 1 — regras de segurança.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, regras de segurança"
 },
 {
  "id": "bz05-003",
  "disc": "Armamento e Munição I",
  "assunto": "regras de segurança",
  "enunciado": "As armas e munições devem ser guardadas:",
  "alts": [
   {
    "t": "separadamente e em locais fora do alcance de curiosos.",
    "ok": true
   },
   {
    "t": "na viatura, sempre carregadas."
   },
   {
    "t": "em local de livre acesso."
   },
   {
    "t": "juntas, na mesma gaveta, para agilizar o uso."
   }
  ],
  "resolucao": "==Gabarito: separadamente e em locais fora do alcance de curiosos.== Tópico 1 — regras de segurança.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, regras de segurança"
 },
 {
  "id": "bz05-004",
  "disc": "Armamento e Munição I",
  "assunto": "regras de segurança",
  "enunciado": "Ao mostrar uma arma a alguém, deve-se fazê-lo com:",
  "alts": [
   {
    "t": "a arma apontada para a pessoa."
   },
   {
    "t": "o ferrolho fechado e o carregador inserido."
   },
   {
    "t": "o ferrolho aberto, sem o carregador e com a câmara vazia.",
    "ok": true
   },
   {
    "t": "a câmara carregada, por segurança."
   }
  ],
  "resolucao": "==Gabarito: o ferrolho aberto, sem o carregador e com a câmara vazia.== Tópico 1 — regras de segurança.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, regras de segurança"
 },
 {
  "id": "bz05-005",
  "disc": "Armamento e Munição I",
  "assunto": "quanto ao tipo",
  "enunciado": "Quanto ao tipo, a arma que pode ser conduzida no coldre por seu pouco peso e dimensões reduzidas é a:",
  "alts": [
   {
    "t": "coletiva."
   },
   {
    "t": "de porte.",
    "ok": true
   },
   {
    "t": "não portátil."
   },
   {
    "t": "portátil."
   }
  ],
  "resolucao": "==Gabarito: de porte.== Tópico 3.1 — quanto ao tipo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, quanto ao tipo"
 },
 {
  "id": "bz05-006",
  "disc": "Armamento e Munição I",
  "assunto": "não portátil",
  "enunciado": "São exemplos de armas não portáteis:",
  "alts": [
   {
    "t": "submetralhadoras apenas."
   },
   {
    "t": "carabinas e espingardas."
   },
   {
    "t": "revólveres e pistolas."
   },
   {
    "t": "metralhadoras, morteiros e canhões.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: metralhadoras, morteiros e canhões.== Tópico 3.1 — não portátil.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, não portátil"
 },
 {
  "id": "bz05-007",
  "disc": "Armamento e Munição I",
  "assunto": "quanto ao funcionamento",
  "enunciado": "A arma que, após cada disparo, exige força física sobre um componente do mecanismo para as operações prévias ao disparo seguinte é a:",
  "alts": [
   {
    "t": "de repetição.",
    "ok": true
   },
   {
    "t": "automática."
   },
   {
    "t": "semiautomática."
   },
   {
    "t": "de tiro unitário com alma lisa."
   }
  ],
  "resolucao": "==Gabarito: de repetição.== Tópico 3.3 — quanto ao funcionamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, quanto ao funcionamento"
 },
 {
  "id": "bz05-008",
  "disc": "Armamento e Munição I",
  "assunto": "automático",
  "enunciado": "A arma automática realiza automaticamente todas as fases do funcionamento:",
  "alts": [
   {
    "t": "exceto a ejeção."
   },
   {
    "t": "apenas a alimentação."
   },
   {
    "t": "incluindo o disparo.",
    "ok": true
   },
   {
    "t": "exceto o disparo."
   }
  ],
  "resolucao": "==Gabarito: incluindo o disparo.== Tópico 3.3 — automático.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, automático"
 },
 {
  "id": "bz05-009",
  "disc": "Armamento e Munição I",
  "assunto": "força muscular do atirador",
  "enunciado": "O sistema de alavanca (Lever Action) é exemplificado pela:",
  "alts": [
   {
    "t": "mosquetão M968."
   },
   {
    "t": "pistola TS9."
   },
   {
    "t": "espingarda cal. 12."
   },
   {
    "t": "carabina Puma.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: carabina Puma.== Tópico 3.4 — força muscular do atirador.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, força muscular do atirador"
 },
 {
  "id": "bz05-010",
  "disc": "Armamento e Munição I",
  "assunto": "ação híbrida",
  "enunciado": "Segundo a Norma Técnica SENASP nº 001/2020, a ação híbrida caracteriza-se porque, com o carregamento da arma:",
  "alts": [
   {
    "t": "o cão fica totalmente armado."
   },
   {
    "t": "o ferrolho trava aberto."
   },
   {
    "t": "a mola do percussor fica semi-engatilhada (“1/3 pressionada”).",
    "ok": true
   },
   {
    "t": "a arma só dispara em ação dupla."
   }
  ],
  "resolucao": "==Gabarito: a mola do percussor fica semi-engatilhada (“1/3 pressionada”).== Tópico 3.5 — ação híbrida.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, ação híbrida"
 },
 {
  "id": "bz05-011",
  "disc": "Armamento e Munição I",
  "assunto": "alma do cano",
  "enunciado": "Quanto à alma do cano, a espingarda cal. 12 é de alma:",
  "alts": [
   {
    "t": "raiada."
   },
   {
    "t": "dupla."
   },
   {
    "t": "ondulada."
   },
   {
    "t": "lisa.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: lisa.== Tópico 3.6 — alma do cano.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, alma do cano"
 },
 {
  "id": "bz05-012",
  "disc": "Armamento e Munição I",
  "assunto": "municiar",
  "enunciado": "“Municiar”, na terminologia da apostila, é:",
  "alts": [
   {
    "t": "descarregar a arma."
   },
   {
    "t": "colocar o cartucho na câmara em condições de disparo."
   },
   {
    "t": "colocar a munição no carregador.",
    "ok": true
   },
   {
    "t": "colocar a munição na arma através do carregador."
   }
  ],
  "resolucao": "==Gabarito: colocar a munição no carregador.== Tópico 3.7 — municiar.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, municiar"
 },
 {
  "id": "bz05-013",
  "disc": "Armamento e Munição I",
  "assunto": "refrigeração",
  "enunciado": "Quanto à refrigeração, as armas podem ser refrigeradas a:",
  "alts": [
   {
    "t": "ar, água, ou ar e água.",
    "ok": true
   },
   {
    "t": "óleo."
   },
   {
    "t": "apenas gelo."
   },
   {
    "t": "somente a ar."
   }
  ],
  "resolucao": "==Gabarito: ar, água, ou ar e água.== Tópico 3.7 — refrigeração.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, refrigeração"
 },
 {
  "id": "bz05-014",
  "disc": "Armamento e Munição I",
  "assunto": "carabina",
  "enunciado": "A arma portátil semelhante a um fuzil, de dimensões reduzidas, cano longo (relativamente menor que o do fuzil) e alma raiada, é a:",
  "alts": [
   {
    "t": "pistola."
   },
   {
    "t": "carabina.",
    "ok": true
   },
   {
    "t": "submetralhadora."
   },
   {
    "t": "espingarda."
   }
  ],
  "resolucao": "==Gabarito: carabina.== Tópico 4 — carabina.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, carabina"
 },
 {
  "id": "bz05-015",
  "disc": "Armamento e Munição I",
  "assunto": "revólver",
  "enunciado": "A arma de porte, de repetição, com cilindro giratório atrás do cano que serve de carregador e câmara é o:",
  "alts": [
   {
    "t": "pistola."
   },
   {
    "t": "revólver.",
    "ok": true
   },
   {
    "t": "fuzil."
   },
   {
    "t": "mosquetão."
   }
  ],
  "resolucao": "==Gabarito: revólver.== Tópico 4 — revólver.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, revólver"
 },
 {
  "id": "bz05-016",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 1",
  "enunciado": "(Certo ou Errado) Ao receber uma arma, nunca se deve pegá-la com o cano apontado em sua direção.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1 — regras de segurança."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1 — regras de segurança.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 1"
 },
 {
  "id": "bz05-017",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 1",
  "enunciado": "(Certo ou Errado) É permitido testar as travas de segurança da arma apontando-a para um local seguro, pois os dispositivos mecânicos são infalíveis.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 1 — NUNCA teste as travas de segurança; os dispositivos são mecânicos e não substituem o bom senso."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 1 — NUNCA teste as travas de segurança; os dispositivos são mecânicos e não substituem o bom senso.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 1"
 },
 {
  "id": "bz05-018",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 3.1",
  "enunciado": "(Certo ou Errado) A arma não portátil é aquela que só pode ser conduzida por uma viatura ou dividida em fardos por vários homens.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3.1 — não portátil."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3.1 — não portátil.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 3.1"
 },
 {
  "id": "bz05-019",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 3.3",
  "enunciado": "(Certo ou Errado) A arma de fogo semiautomática realiza automaticamente todas as fases do funcionamento, inclusive o disparo.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.3 — a semiautomática faz tudo automaticamente EXCETO o disparo; a automática inclui o disparo."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.3 — a semiautomática faz tudo automaticamente EXCETO o disparo; a automática inclui o disparo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 3.3"
 },
 {
  "id": "bz05-020",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 3.5",
  "enunciado": "(Certo ou Errado) Na arma de ação dupla, a ação sobre o gatilho provoca várias ações, culminando com o desengatilhamento.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3.5 — ação dupla."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3.5 — ação dupla.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 3.5"
 },
 {
  "id": "bz05-021",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 3.6",
  "enunciado": "(Certo ou Errado) A alma raiada apresenta superfície interna completamente lisa.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.6 — alma raiada tem sulcos helicoidais (raias); lisa é a espingarda cal. 12."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.6 — alma raiada tem sulcos helicoidais (raias); lisa é a espingarda cal. 12.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 3.6"
 },
 {
  "id": "bz05-022",
  "disc": "Armamento e Munição I",
  "assunto": "Tópico 3.7",
  "enunciado": "(Certo ou Errado) Alimentar é colocar o cartucho na câmara de combustão, em condições de disparo.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.7 — isso é carregar; alimentar é colocar a munição na arma através do carregador."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.7 — isso é carregar; alimentar é colocar a munição na arma através do carregador.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 5, Tópico 3.7"
 }
]);
