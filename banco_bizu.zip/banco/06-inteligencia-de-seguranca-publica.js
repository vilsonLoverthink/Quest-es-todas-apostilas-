/* Disciplina: Inteligência de Segurança Pública (34 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz06-001",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "definições de inteligência",
  "enunciado": "Segundo o dicionário, inteligência é a capacidade de:",
  "alts": [
   {
    "t": "obter dados sigilosos por qualquer meio."
   },
   {
    "t": "memorizar leis e artigos."
   },
   {
    "t": "compreender, resolver problemas e adaptar-se a novas situações.",
    "ok": true
   },
   {
    "t": "executar ordens sem questionar."
   }
  ],
  "resolucao": "==Gabarito: compreender, resolver problemas e adaptar-se a novas situações.== Tópico 1 — definições de inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, definições de inteligência"
 },
 {
  "id": "bz06-002",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "liderança e inteligência",
  "enunciado": "A liderança em segurança pública depende da capacidade de tomar decisões:",
  "alts": [
   {
    "t": "impulsivas e discricionárias."
   },
   {
    "t": "sigilosas e demoradas."
   },
   {
    "t": "baseadas apenas na intuição."
   },
   {
    "t": "fundamentadas, céleres e eficientes.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: fundamentadas, céleres e eficientes.== Tópico 2 — liderança e inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, liderança e inteligência"
 },
 {
  "id": "bz06-003",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "visão sistêmica",
  "enunciado": "Decisões tomadas sem o devido assessoramento:",
  "alts": [
   {
    "t": "dispensam a atividade de inteligência."
   },
   {
    "t": "reduzem o risco institucional."
   },
   {
    "t": "garantem maior celeridade sem riscos."
   },
   {
    "t": "aumentam o risco operacional e institucional.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: aumentam o risco operacional e institucional.== Tópico 2 — visão sistêmica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, visão sistêmica"
 },
 {
  "id": "bz06-004",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "evolução durante a Guerra Fria",
  "enunciado": "Na Guerra Fria (1947–1991), a inteligência tornou-se:",
  "alts": [
   {
    "t": "irrelevante diante do confronto direto."
   },
   {
    "t": "o principal campo de batalha, substituindo o confronto militar direto pelo equilíbrio mantido pela informação e pelo medo.",
    "ok": true
   },
   {
    "t": "restrita ao uso doméstico."
   },
   {
    "t": "atividade desprezada pelas potências."
   }
  ],
  "resolucao": "==Gabarito: o principal campo de batalha, substituindo o confronto militar direto pelo equilíbrio mantido pela informação e pelo medo.== Tópico 3 — evolução durante a Guerra Fria.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, evolução durante a Guerra Fria"
 },
 {
  "id": "bz06-005",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "história da inteligência no Brasil",
  "enunciado": "Em 1927, foram criados no Brasil:",
  "alts": [
   {
    "t": "o SISBIN e o SIPOM."
   },
   {
    "t": "a ABIN e o GSI."
   },
   {
    "t": "o Conselho de Defesa Nacional (CDN) e o Serviço Federal de Informações e Contra-Informação (SFICI).",
    "ok": true
   },
   {
    "t": "a DINTEL e a ESINT."
   }
  ],
  "resolucao": "==Gabarito: o Conselho de Defesa Nacional (CDN) e o Serviço Federal de Informações e Contra-Informação (SFICI).== Tópico 4 — história da inteligência no Brasil.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, história da inteligência no Brasil"
 },
 {
  "id": "bz06-006",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "estrutura do sistema de inteligência",
  "enunciado": "O órgão central do SISBIN (Sistema Brasileiro de Inteligência) é a:",
  "alts": [
   {
    "t": "ABIN.",
    "ok": true
   },
   {
    "t": "SENASP."
   },
   {
    "t": "DINTEL."
   },
   {
    "t": "PRF."
   }
  ],
  "resolucao": "==Gabarito: ABIN.== Tópico 5 — estrutura do sistema de inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, estrutura do sistema de inteligência"
 },
 {
  "id": "bz06-007",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "finalidade do SIPOM",
  "enunciado": "A finalidade do SIPOM é:",
  "alts": [
   {
    "t": "emitir CNH."
   },
   {
    "t": "substituir o Ministério Público."
   },
   {
    "t": "congregar, coordenar, orientar, supervisionar e fiscalizar tecnicamente as atividades de inteligência da Polícia Militar.",
    "ok": true
   },
   {
    "t": "executar prisões em flagrante."
   }
  ],
  "resolucao": "==Gabarito: congregar, coordenar, orientar, supervisionar e fiscalizar tecnicamente as atividades de inteligência da Polícia Militar.== Tópico 6 — finalidade do SIPOM.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, finalidade do SIPOM"
 },
 {
  "id": "bz06-008",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "ARI",
  "enunciado": "As Agências Regionais de Inteligência (ARI) são instaladas:",
  "alts": [
   {
    "t": "na Corregedoria."
   },
   {
    "t": "nos batalhões."
   },
   {
    "t": "nas companhias independentes."
   },
   {
    "t": "nos Grandes Comandos.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: nos Grandes Comandos.== Tópico 6 — ARI.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, ARI"
 },
 {
  "id": "bz06-009",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "AEI",
  "enunciado": "As Agências Especiais de Inteligência (AEI) compreendem:",
  "alts": [
   {
    "t": "a Escola de Inteligência."
   },
   {
    "t": "as Companhias independentes."
   },
   {
    "t": "os Grandes Comandos."
   },
   {
    "t": "a Corregedoria (SIl) e os Órgãos de Apoio (SAA).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: a Corregedoria (SIl) e os Órgãos de Apoio (SAA).== Tópico 6 — AEI.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, AEI"
 },
 {
  "id": "bz06-010",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "capacitação e treinamento",
  "enunciado": "Compete à DINTEL, por meio da ESINT, formular e executar:",
  "alts": [
   {
    "t": "cursos de formação de condutores."
   },
   {
    "t": "cursos de tiro de combate para civis."
   },
   {
    "t": "cursos de idiomas."
   },
   {
    "t": "cursos de Inteligência Policial (básico, intermediário, análise de dados e operações).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: cursos de Inteligência Policial (básico, intermediário, análise de dados e operações).== Tópico 7 — capacitação e treinamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, capacitação e treinamento"
 },
 {
  "id": "bz06-011",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "definição de ISP (DNISP 2015)",
  "enunciado": "Segundo a DNISP 2015, a Inteligência de Segurança Pública é o exercício permanente e sistemático de ações especializadas para:",
  "alts": [
   {
    "t": "reprimir manifestações públicas."
   },
   {
    "t": "produzir provas para o processo penal."
   },
   {
    "t": "identificar, avaliar e acompanhar ameaças reais ou potenciais, produzindo e salvaguardando conhecimentos para subsidiar tomadores de decisão.",
    "ok": true
   },
   {
    "t": "aplicar penalidades administrativas."
   }
  ],
  "resolucao": "==Gabarito: identificar, avaliar e acompanhar ameaças reais ou potenciais, produzindo e salvaguardando conhecimentos para subsidiar tomadores de decisão.== Tópico 8 — definição de ISP (DNISP 2015).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, definição de ISP (DNISP 2015)"
 },
 {
  "id": "bz06-012",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "inteligência vs. investigação",
  "enunciado": "Quanto à natureza, a inteligência de segurança pública é:",
  "alts": [
   {
    "t": "legislativa."
   },
   {
    "t": "judicial."
   },
   {
    "t": "executiva / de persecução penal."
   },
   {
    "t": "consultiva / de assessoramento.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: consultiva / de assessoramento.== Tópico 9 — inteligência vs. investigação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, inteligência vs. investigação"
 },
 {
  "id": "bz06-013",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "inteligência vs. investigação",
  "enunciado": "O caráter da inteligência é estratégico, preventivo e prospectivo, e seu horizonte temporal é de:",
  "alts": [
   {
    "t": "curto e médio prazo."
   },
   {
    "t": "médio e longo prazo.",
    "ok": true
   },
   {
    "t": "inexistente."
   },
   {
    "t": "apenas imediato."
   }
  ],
  "resolucao": "==Gabarito: médio e longo prazo.== Tópico 9 — inteligência vs. investigação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, inteligência vs. investigação"
 },
 {
  "id": "bz06-014",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "contrainteligência",
  "enunciado": "A contrainteligência tem como objetivo:",
  "alts": [
   {
    "t": "produzir conhecimento sobre o alvo externo."
   },
   {
    "t": "apurar autoria de crimes consumados."
   },
   {
    "t": "aplicar penas."
   },
   {
    "t": "proteger e salvaguardar, prevenindo, detectando e neutralizando espionagem, sabotagem ou infiltração de agentes rivais.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: proteger e salvaguardar, prevenindo, detectando e neutralizando espionagem, sabotagem ou infiltração de agentes rivais.== Tópico 10 — contrainteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, contrainteligência"
 },
 {
  "id": "bz06-015",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "exemplo de contrainteligência",
  "enunciado": "Impedir que criminosos descubram as operações ou vazem dados sigilosos é exemplo de:",
  "alts": [
   {
    "t": "contrainteligência.",
    "ok": true
   },
   {
    "t": "inteligência."
   },
   {
    "t": "policiamento ostensivo."
   },
   {
    "t": "perícia."
   }
  ],
  "resolucao": "==Gabarito: contrainteligência.== Tópico 10 — exemplo de contrainteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, exemplo de contrainteligência"
 },
 {
  "id": "bz06-016",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "dado vs. conhecimento",
  "enunciado": "O conhecimento é:",
  "alts": [
   {
    "t": "o dado bruto coletado em campo."
   },
   {
    "t": "um boato confirmado."
   },
   {
    "t": "o produto do tratamento analítico de múltiplos dados via metodologia própria, com significado, contexto e valor de suporte à decisão.",
    "ok": true
   },
   {
    "t": "uma informação sem análise."
   }
  ],
  "resolucao": "==Gabarito: o produto do tratamento analítico de múltiplos dados via metodologia própria, com significado, contexto e valor de suporte à decisão.== Tópico 11 — dado vs. conhecimento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, dado vs. conhecimento"
 },
 {
  "id": "bz06-017",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "níveis de assessoramento",
  "enunciado": "O nível de assessoramento que apoia o planejamento e a execução direta de missões no terreno é o:",
  "alts": [
   {
    "t": "tático."
   },
   {
    "t": "estratégico."
   },
   {
    "t": "operacional.",
    "ok": true
   },
   {
    "t": "político."
   }
  ],
  "resolucao": "==Gabarito: operacional.== Tópico 11 — níveis de assessoramento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, níveis de assessoramento"
 },
 {
  "id": "bz06-018",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "operações em busca do dado negado",
  "enunciado": "As ações de coleta consistem em:",
  "alts": [
   {
    "t": "interceptação de sinais exclusivamente."
   },
   {
    "t": "procedimentos do ELO para obter o dado negado."
   },
   {
    "t": "infiltração obrigatória."
   },
   {
    "t": "procedimentos para obter dados em fontes abertas/disponíveis.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: procedimentos para obter dados em fontes abertas/disponíveis.== Tópico 12 — operações em busca do dado negado.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, operações em busca do dado negado"
 },
 {
  "id": "bz06-019",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "principais ações de busca",
  "enunciado": "Entre as principais ações de busca estão:",
  "alts": [
   {
    "t": "exclusivamente a coleta em redes sociais."
   },
   {
    "t": "somente a análise de relatórios internos."
   },
   {
    "t": "entrevista, provocação, entrada, desinformação, recrutamento operacional, infiltração, reconhecimento, interceptação de sinais e vigilância.",
    "ok": true
   },
   {
    "t": "apenas a leitura de jornais."
   }
  ],
  "resolucao": "==Gabarito: entrevista, provocação, entrada, desinformação, recrutamento operacional, infiltração, reconhecimento, interceptação de sinais e vigilância.== Tópico 12 — principais ações de busca.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, principais ações de busca"
 },
 {
  "id": "bz06-020",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "papéis na inteligência",
  "enunciado": "O agente de inteligência é aquele que:",
  "alts": [
   {
    "t": "é pessoa externa sem vínculo operacional."
   },
   {
    "t": "apenas assina relatórios."
   },
   {
    "t": "trabalha em campo, executa técnicas operacionais, realiza buscas e obtém o dado negado.",
    "ok": true
   },
   {
    "t": "trabalha apenas em gabinete."
   }
  ],
  "resolucao": "==Gabarito: trabalha em campo, executa técnicas operacionais, realiza buscas e obtém o dado negado.== Tópico 13 — papéis na inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, papéis na inteligência"
 },
 {
  "id": "bz06-021",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "sensor de inteligência",
  "enunciado": "O servidor policial que, no cumprimento de suas atribuições rotineiras na rua, observa, identifica e repassa dados relevantes é o:",
  "alts": [
   {
    "t": "analista."
   },
   {
    "t": "sensor de inteligência.",
    "ok": true
   },
   {
    "t": "informante recrutado."
   },
   {
    "t": "agente de busca."
   }
  ],
  "resolucao": "==Gabarito: sensor de inteligência.== Tópico 13/14 — sensor de inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, sensor de inteligência"
 },
 {
  "id": "bz06-022",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) A atividade de inteligência atua como órgão assessor, e a autoridade para decidir permanece com o Comando.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — “O Poder Decide; a Inteligência Ilumina”."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — “O Poder Decide; a Inteligência Ilumina”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 2"
 },
 {
  "id": "bz06-023",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 3",
  "enunciado": "(Certo ou Errado) Durante a Guerra Fria, a inteligência perdeu importância porque o confronto militar direto passou a predominar.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3 — a inteligência virou o principal campo de batalha, substituindo o confronto direto."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3 — a inteligência virou o principal campo de batalha, substituindo o confronto direto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 3"
 },
 {
  "id": "bz06-024",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) O SISBIN tem a ABIN como órgão central.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — estrutura do sistema de inteligência."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — estrutura do sistema de inteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 5"
 },
 {
  "id": "bz06-025",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) As Agências Locais de Inteligência (ALI) são instaladas nos Grandes Comandos.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — ARI é que fica nos Grandes Comandos; ALI = P-2 de batalhões, regimentos e cias independentes."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — ARI é que fica nos Grandes Comandos; ALI = P-2 de batalhões, regimentos e cias independentes.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 6"
 },
 {
  "id": "bz06-026",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) O ramo da atividade de ISP inclui a “atividade”, a inteligência e a contrainteligência.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 8 — “atividade” não é ramo; os ramos são inteligência e contrainteligência."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 8 — “atividade” não é ramo; os ramos são inteligência e contrainteligência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 8"
 },
 {
  "id": "bz06-027",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 9",
  "enunciado": "(Certo ou Errado) A investigação policial tem natureza executiva e finalidade de apurar materialidade, autoria e infração penal.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 9 — inteligência vs. investigação."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 9 — inteligência vs. investigação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 9"
 },
 {
  "id": "bz06-028",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) A contrainteligência tem o foco voltado exclusivamente para fora, monitorando organizações criminosas externas.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 10 — o foco da contrainteligência é para dentro (proteção do sigilo e das instalações)."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 10 — o foco da contrainteligência é para dentro (proteção do sigilo e das instalações).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 10"
 },
 {
  "id": "bz06-029",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) Dado e conhecimento são sinônimos na doutrina de inteligência.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 11 — dado é não tratado; conhecimento é o produto do tratamento analítico."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 11 — dado é não tratado; conhecimento é o produto do tratamento analítico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 11"
 },
 {
  "id": "bz06-030",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) As ações de busca visam obter o dado negado e são realizadas pelo Elemento de Operações (ELO).",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 12 — ações de busca."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 12 — ações de busca.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 12"
 },
 {
  "id": "bz06-031",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 15",
  "enunciado": "(Certo ou Errado) O policial na rua não deve expor informações sensíveis em redes sociais nem transformar boato em informação confirmada.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 15 — vedações e limites de atuação."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 15 — vedações e limites de atuação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 15"
 },
 {
  "id": "bz06-032",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "Tópico 15",
  "enunciado": "(Certo ou Errado) É permitido ao policial realizar diligências de inteligência por conta própria, ainda que fora de suas atribuições, se tiver curiosidade pessoal sobre o caso.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 15 — vedado; não se deve confundir curiosidade pessoal com necessidade institucional."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 15 — vedado; não se deve confundir curiosidade pessoal com necessidade institucional.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, Tópico 15"
 },
 {
  "id": "bz06-033",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "exemplo de inteligência (reforço)",
  "enunciado": "Uma agência coleta e analisa dados para descobrir como uma facção criminosa opera, a fim de assessorar o Comando na decisão. Essa atividade é de:",
  "alts": [
   {
    "t": "atividade administrativa: controla pessoal e patrimônio da corporação."
   },
   {
    "t": "investigação policial: apura autoria de crimes já ocorridos para instruir o inquérito."
   },
   {
    "t": "inteligência: olha para o alvo externo e produz conhecimento útil à decisão.",
    "ok": true
   },
   {
    "t": "contrainteligência: protege o sigilo de dados e a segurança das instalações da agência."
   }
  ],
  "resolucao": "==Gabarito: inteligência: olha para o alvo externo e produz conhecimento útil à decisão.== Tópico 10 — exemplo de inteligência (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, exemplo de inteligência (reforço)"
 },
 {
  "id": "bz06-034",
  "disc": "Inteligência de Segurança Pública",
  "assunto": "papéis na inteligência (reforço)",
  "enunciado": "Na doutrina de inteligência, a pessoa recrutada operacionalmente que fornece dados negados de forma sigilosa à agência é o:",
  "alts": [
   {
    "t": "informante, recrutado para fornecer dados negados sigilosamente.",
    "ok": true
   },
   {
    "t": "sensor de inteligência, policial que repassa dados observados na rotina da rua."
   },
   {
    "t": "colaborador, pessoa externa que apenas facilita o acesso a ambientes e dados."
   },
   {
    "t": "analista, que trabalha em gabinete correlacionando contextos e produzindo relatórios."
   }
  ],
  "resolucao": "==Gabarito: informante, recrutado para fornecer dados negados sigilosamente.== Tópico 13 — papéis na inteligência (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 6, papéis na inteligência (reforço)"
 }
]);
