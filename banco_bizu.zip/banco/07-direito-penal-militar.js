/* Disciplina: Direito Penal Militar (44 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz07-001",
  "disc": "Direito Penal Militar",
  "assunto": "conceito geral",
  "enunciado": "O Direito Militar, como gênero amplo, engloba as esferas:",
  "alts": [
   {
    "t": "penal, processual penal, administrativa disciplinar e a própria Justiça Militar.",
    "ok": true
   },
   {
    "t": "exclusivamente a processual civil."
   },
   {
    "t": "apenas a penal."
   },
   {
    "t": "somente a tributária e a civil."
   }
  ],
  "resolucao": "==Gabarito: penal, processual penal, administrativa disciplinar e a própria Justiça Militar.== Tópico 1 — conceito geral.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, conceito geral"
 },
 {
  "id": "bz07-002",
  "disc": "Direito Penal Militar",
  "assunto": "conceito de DPM",
  "enunciado": "Segundo Célio Lobão, o DPM é especial em razão do bem jurídico tutelado, fundamentado especificamente na:",
  "alts": [
   {
    "t": "liberdade de imprensa."
   },
   {
    "t": "propriedade privada e livre iniciativa."
   },
   {
    "t": "ordem tributária."
   },
   {
    "t": "disciplina e hierarquia, do serviço e do dever militar, acrescidos da condição de militar dos sujeitos do delito.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: disciplina e hierarquia, do serviço e do dever militar, acrescidos da condição de militar dos sujeitos do delito.== Tópico 2.1 — conceito de DPM.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, conceito de DPM"
 },
 {
  "id": "bz07-003",
  "disc": "Direito Penal Militar",
  "assunto": "conceito de crime militar",
  "enunciado": "O conceito amplo de crime militar adota o critério:",
  "alts": [
   {
    "t": "material, baseado na natureza intrínseca do ato."
   },
   {
    "t": "formal: é crime militar toda conduta que a lei expressamente define como tal (art. 9º do CPM).",
    "ok": true
   },
   {
    "t": "exclusivamente pessoal."
   },
   {
    "t": "exclusivamente territorial."
   }
  ],
  "resolucao": "==Gabarito: formal: é crime militar toda conduta que a lei expressamente define como tal (art. 9º do CPM).== Tópico 2.2 — conceito de crime militar.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, conceito de crime militar"
 },
 {
  "id": "bz07-004",
  "disc": "Direito Penal Militar",
  "assunto": "conceito formal",
  "enunciado": "No Brasil vigora, para o crime militar, o critério:",
  "alts": [
   {
    "t": "exclusivamente pessoal."
   },
   {
    "t": "estritamente legal (ratione legis).",
    "ok": true
   },
   {
    "t": "exclusivamente territorial."
   },
   {
    "t": "da gravidade da pena."
   }
  ],
  "resolucao": "==Gabarito: estritamente legal (ratione legis).== Tópico 3.1 — conceito formal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, conceito formal"
 },
 {
  "id": "bz07-005",
  "disc": "Direito Penal Militar",
  "assunto": "crimes impropriamente militares",
  "enunciado": "Os crimes impropriamente militares (Art. 9º, II e III):",
  "alts": [
   {
    "t": "só existem no CPM."
   },
   {
    "t": "exigem sempre estado de guerra."
   },
   {
    "t": "são exclusivos de oficiais."
   },
   {
    "t": "têm previsão idêntica ou similar no Código Penal ou em leis extravagantes, tornando-se militares quando praticados nas circunstâncias legais.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: têm previsão idêntica ou similar no Código Penal ou em leis extravagantes, tornando-se militares quando praticados nas circunstâncias legais.== Tópico 3.2 — crimes impropriamente militares.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, crimes impropriamente militares"
 },
 {
  "id": "bz07-006",
  "disc": "Direito Penal Militar",
  "assunto": "critérios de classificação",
  "enunciado": "O critério ratione materiae exige a verificação da dupla qualidade militar:",
  "alts": [
   {
    "t": "na pena e no regime."
   },
   {
    "t": "no ato (que afeta instituições e valores militares) e no sujeito (autor militar).",
    "ok": true
   },
   {
    "t": "na vítima e no juiz."
   },
   {
    "t": "no local e no tempo."
   }
  ],
  "resolucao": "==Gabarito: no ato (que afeta instituições e valores militares) e no sujeito (autor militar).== Tópico 3.3 — critérios de classificação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, critérios de classificação"
 },
 {
  "id": "bz07-007",
  "disc": "Direito Penal Militar",
  "assunto": "critérios de classificação",
  "enunciado": "O critério que leva em conta a qualidade ou condição das pessoas envolvidas (agente e/ou vítima militares da ativa) é o:",
  "alts": [
   {
    "t": "ratione loci."
   },
   {
    "t": "ratione personae.",
    "ok": true
   },
   {
    "t": "ratione temporis."
   },
   {
    "t": "ratione legis."
   }
  ],
  "resolucao": "==Gabarito: ratione personae.== Tópico 3.3 — critérios de classificação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, critérios de classificação"
 },
 {
  "id": "bz07-008",
  "disc": "Direito Penal Militar",
  "assunto": "ratione temporis",
  "enunciado": "O critério que se refere à época da prática do delito (tempo de guerra, manobras ou exercícios militares) é o:",
  "alts": [
   {
    "t": "ratione loci."
   },
   {
    "t": "ratione temporis.",
    "ok": true
   },
   {
    "t": "ratione legis."
   },
   {
    "t": "ratione personae."
   }
  ],
  "resolucao": "==Gabarito: ratione temporis.== Tópico 3.3 — ratione temporis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, ratione temporis"
 },
 {
  "id": "bz07-009",
  "disc": "Direito Penal Militar",
  "assunto": "ratione legis",
  "enunciado": "O critério que exige previsão do fato na legislação penal aplicável, combinada com o enquadramento nas hipóteses do art. 9º do CPM, é o:",
  "alts": [
   {
    "t": "ratione materiae."
   },
   {
    "t": "ratione personae."
   },
   {
    "t": "ratione loci."
   },
   {
    "t": "ratione legis.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: ratione legis.== Tópico 3.3 — ratione legis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, ratione legis"
 },
 {
  "id": "bz07-010",
  "disc": "Direito Penal Militar",
  "assunto": "alínea “a”",
  "enunciado": "O Art. 9º, II, “a” trata do crime cometido:",
  "alts": [
   {
    "t": "por militar contra patrimônio privado."
   },
   {
    "t": "por militar da reserva contra civil."
   },
   {
    "t": "por civil contra militar da reserva."
   },
   {
    "t": "por militar da ativa contra militar na ativa.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: por militar da ativa contra militar na ativa.== Tópico 3.4 — alínea “a”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, alínea “a”"
 },
 {
  "id": "bz07-011",
  "disc": "Direito Penal Militar",
  "assunto": "alínea “b”",
  "enunciado": "O Art. 9º, II, “b” abrange o crime praticado por militar da ativa:",
  "alts": [
   {
    "t": "apenas contra superior hierárquico."
   },
   {
    "t": "somente em tempo de guerra."
   },
   {
    "t": "em lugar sujeito à administração militar, contra militar da reserva/reformado ou contra civil.",
    "ok": true
   },
   {
    "t": "fora de serviço, em local público."
   }
  ],
  "resolucao": "==Gabarito: em lugar sujeito à administração militar, contra militar da reserva/reformado ou contra civil.== Tópico 3.4 — alínea “b”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, alínea “b”"
 },
 {
  "id": "bz07-012",
  "disc": "Direito Penal Militar",
  "assunto": "alínea “c”",
  "enunciado": "O Art. 9º, II, “c” aplica-se ao militar em serviço ou atuando em razão da função, contra reserva, reformado ou civil:",
  "alts": [
   {
    "t": "somente dentro do quartel."
   },
   {
    "t": "ainda que fora de lugar sujeito à administração militar, inclusive ao que avoca a função mesmo de folga.",
    "ok": true
   },
   {
    "t": "apenas se estiver de uniforme de gala."
   },
   {
    "t": "somente em horário de expediente."
   }
  ],
  "resolucao": "==Gabarito: ainda que fora de lugar sujeito à administração militar, inclusive ao que avoca a função mesmo de folga.== Tópico 3.4 — alínea “c”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, alínea “c”"
 },
 {
  "id": "bz07-013",
  "disc": "Direito Penal Militar",
  "assunto": "alínea “d”",
  "enunciado": "O Art. 9º, II, “d” alcança condutas praticadas por militar:",
  "alts": [
   {
    "t": "durante o período de manobras/exercício, inclusive nos momentos de descanso desses eventos.",
    "ok": true
   },
   {
    "t": "em férias."
   },
   {
    "t": "no exterior, em turismo."
   },
   {
    "t": "somente em combate real."
   }
  ],
  "resolucao": "==Gabarito: durante o período de manobras/exercício, inclusive nos momentos de descanso desses eventos.== Tópico 3.4 — alínea “d”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, alínea “d”"
 },
 {
  "id": "bz07-014",
  "disc": "Direito Penal Militar",
  "assunto": "aviso importante (JME)",
  "enunciado": "Na esfera estadual, os civis:",
  "alts": [
   {
    "t": "respondem sempre na Justiça Militar Estadual."
   },
   {
    "t": "respondem apenas se estiverem em quartel."
   },
   {
    "t": "NÃO respondem por crimes militares, sendo julgados pela Justiça Comum.",
    "ok": true
   },
   {
    "t": "respondem por todos os crimes militares."
   }
  ],
  "resolucao": "==Gabarito: NÃO respondem por crimes militares, sendo julgados pela Justiça Comum.== Tópico 3.5 — aviso importante (JME).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, aviso importante (JME)"
 },
 {
  "id": "bz07-015",
  "disc": "Direito Penal Militar",
  "assunto": "aviso importante",
  "enunciado": "A incidência do inciso III do art. 9º sobre civis restringe-se à esfera:",
  "alts": [
   {
    "t": "federal (JMU).",
    "ok": true
   },
   {
    "t": "municipal."
   },
   {
    "t": "estadual (JME)."
   },
   {
    "t": "eleitoral."
   }
  ],
  "resolucao": "==Gabarito: federal (JMU).== Tópico 3.5 — aviso importante.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, aviso importante"
 },
 {
  "id": "bz07-016",
  "disc": "Direito Penal Militar",
  "assunto": "aviso importante",
  "enunciado": "Um inativo (reserva/reformado) estadual que ofende guarnição em serviço responde na:",
  "alts": [
   {
    "t": "JMU."
   },
   {
    "t": "JME.",
    "ok": true
   },
   {
    "t": "Justiça Comum."
   },
   {
    "t": "Justiça Eleitoral."
   }
  ],
  "resolucao": "==Gabarito: JME.== Tópico 3.5 — aviso importante.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, aviso importante"
 },
 {
  "id": "bz07-017",
  "disc": "Direito Penal Militar",
  "assunto": "§§ 1º e 2º do art. 9º",
  "enunciado": "Os crimes dolosos contra a vida praticados por militares estaduais contra civis são de competência do:",
  "alts": [
   {
    "t": "Conselho de Justiça da JME."
   },
   {
    "t": "Tribunal do Júri (Justiça Comum).",
    "ok": true
   },
   {
    "t": "Justiça Militar da União."
   },
   {
    "t": "juiz de execução penal."
   }
  ],
  "resolucao": "==Gabarito: Tribunal do Júri (Justiça Comum).== Tópico 4 — §§ 1º e 2º do art. 9º.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, §§ 1º e 2º do art. 9º"
 },
 {
  "id": "bz07-018",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 157, qualificadoras",
  "enunciado": "No art. 157, quando o crime é praticado contra comandante de unidade ou oficial-general, a pena é de:",
  "alts": [
   {
    "t": "reclusão de 3 a 9 anos.",
    "ok": true
   },
   {
    "t": "reclusão de 12 a 30 anos."
   },
   {
    "t": "detenção simples."
   },
   {
    "t": "multa."
   }
  ],
  "resolucao": "==Gabarito: reclusão de 3 a 9 anos.== Tópico 5 — Art. 157, qualificadoras.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 157, qualificadoras"
 },
 {
  "id": "bz07-019",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 157",
  "enunciado": "Se da violência contra superior (art. 157) resultar morte, a pena é de:",
  "alts": [
   {
    "t": "detenção de 6 meses."
   },
   {
    "t": "reclusão de 3 a 9 anos."
   },
   {
    "t": "reclusão de 12 a 30 anos.",
    "ok": true
   },
   {
    "t": "reclusão de 2 a 4 anos."
   }
  ],
  "resolucao": "==Gabarito: reclusão de 12 a 30 anos.== Tópico 5 — Art. 157.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 157"
 },
 {
  "id": "bz07-020",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 158",
  "enunciado": "O Art. 158 do CPM trata da violência contra:",
  "alts": [
   {
    "t": "superior hierárquico em geral."
   },
   {
    "t": "inferior hierárquico."
   },
   {
    "t": "oficial de dia, de serviço, sentinela, vigia ou plantão.",
    "ok": true
   },
   {
    "t": "civil em lugar sujeito à administração militar."
   }
  ],
  "resolucao": "==Gabarito: oficial de dia, de serviço, sentinela, vigia ou plantão.== Tópico 5 — Art. 158.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 158"
 },
 {
  "id": "bz07-021",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 175",
  "enunciado": "Praticar violência contra inferior hierárquico é o crime previsto no:",
  "alts": [
   {
    "t": "Art. 157."
   },
   {
    "t": "Art. 163."
   },
   {
    "t": "Art. 175.",
    "ok": true
   },
   {
    "t": "Art. 158."
   }
  ],
  "resolucao": "==Gabarito: Art. 175.== Tópico 5 — Art. 175.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 175"
 },
 {
  "id": "bz07-022",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 176",
  "enunciado": "Ofender inferior hierárquico mediante ato de violência aviltante, humilhante ou degradante é o crime do:",
  "alts": [
   {
    "t": "Art. 175."
   },
   {
    "t": "Art. 195."
   },
   {
    "t": "Art. 176.",
    "ok": true
   },
   {
    "t": "Art. 202."
   }
  ],
  "resolucao": "==Gabarito: Art. 176.== Tópico 5 — Art. 176.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 176"
 },
 {
  "id": "bz07-023",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 196",
  "enunciado": "O Art. 196 (descumprimento de missão) prevê aumento de pena para oficial e para função de comando, respectivamente, de:",
  "alts": [
   {
    "t": "+ metade e +1/3."
   },
   {
    "t": "+1/3 e +1/6."
   },
   {
    "t": "+1/6 e +1/3."
   },
   {
    "t": "+1/3 e + metade.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: +1/3 e + metade.== Tópico 5 — Art. 196.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 196"
 },
 {
  "id": "bz07-024",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 202",
  "enunciado": "O crime de embriaguez em serviço (Art. 202) é de:",
  "alts": [
   {
    "t": "perigo abstrato, independente de resultado concreto.",
    "ok": true
   },
   {
    "t": "perigo concreto."
   },
   {
    "t": "dano consumado."
   },
   {
    "t": "ação penal privada."
   }
  ],
  "resolucao": "==Gabarito: perigo abstrato, independente de resultado concreto.== Tópico 5 — Art. 202.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 202"
 },
 {
  "id": "bz07-025",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 303",
  "enunciado": "A pena do peculato (Art. 303) é de:",
  "alts": [
   {
    "t": "reclusão até 8 anos."
   },
   {
    "t": "reclusão de 2 a 12 anos."
   },
   {
    "t": "reclusão de 3 a 15 anos.",
    "ok": true
   },
   {
    "t": "detenção."
   }
  ],
  "resolucao": "==Gabarito: reclusão de 3 a 15 anos.== Tópico 5 — Art. 303.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 303"
 },
 {
  "id": "bz07-026",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 303, § 1º",
  "enunciado": "No peculato, a pena aumenta em 1/3 quando o bem for de valor superior a:",
  "alts": [
   {
    "t": "100 salários mínimos."
   },
   {
    "t": "5 salários mínimos."
   },
   {
    "t": "20 salários mínimos.",
    "ok": true
   },
   {
    "t": "1 salário mínimo."
   }
  ],
  "resolucao": "==Gabarito: 20 salários mínimos.== Tópico 5 — Art. 303, § 1º.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 303, § 1º"
 },
 {
  "id": "bz07-027",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 308",
  "enunciado": "A corrupção passiva (Art. 308) tem pena de reclusão de:",
  "alts": [
   {
    "t": "2 a 12 anos.",
    "ok": true
   },
   {
    "t": "3 a 15 anos."
   },
   {
    "t": "2 a 6 anos."
   },
   {
    "t": "até 8 anos."
   }
  ],
  "resolucao": "==Gabarito: 2 a 12 anos.== Tópico 5 — Art. 308.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 308"
 },
 {
  "id": "bz07-028",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 309",
  "enunciado": "A corrupção ativa (Art. 309) consiste em:",
  "alts": [
   {
    "t": "desviar valores."
   },
   {
    "t": "dar, oferecer ou prometer vantagem indevida a militar para a prática, omissão ou retardamento de ato.",
    "ok": true
   },
   {
    "t": "receber vantagem em razão da função."
   },
   {
    "t": "solicitar vantagem indevida."
   }
  ],
  "resolucao": "==Gabarito: dar, oferecer ou prometer vantagem indevida a militar para a prática, omissão ou retardamento de ato.== Tópico 5 — Art. 309.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 309"
 },
 {
  "id": "bz07-029",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 311",
  "enunciado": "A falsificação de documento público (Art. 311) tem pena de:",
  "alts": [
   {
    "t": "reclusão de 2 a 6 anos.",
    "ok": true
   },
   {
    "t": "reclusão até 5 anos."
   },
   {
    "t": "reclusão de 3 a 9 anos."
   },
   {
    "t": "detenção até 1 ano."
   }
  ],
  "resolucao": "==Gabarito: reclusão de 2 a 6 anos.== Tópico 5 — Art. 311.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 311"
 },
 {
  "id": "bz07-030",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 2.2",
  "enunciado": "(Certo ou Errado) Crime militar, no conceito formal, é a conduta que a lei expressamente define como tal, independentemente da natureza intrínseca do ato.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2.2 — conceito amplo."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2.2 — conceito amplo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 2.2"
 },
 {
  "id": "bz07-031",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 3.2",
  "enunciado": "(Certo ou Errado) Os crimes propriamente militares possuem previsão idêntica no Código Penal comum.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.2 — os propriamente militares estão previstos apenas no CPM; os impropriamente é que têm correspondência na lei comum."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.2 — os propriamente militares estão previstos apenas no CPM; os impropriamente é que têm correspondência na lei comum.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 3.2"
 },
 {
  "id": "bz07-032",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 3.3",
  "enunciado": "(Certo ou Errado) O critério ratione loci considera o local do fato, como área sob administração militar, navios, aeronaves ou zonas de operação.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3.3 — ratione loci."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3.3 — ratione loci.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 3.3"
 },
 {
  "id": "bz07-033",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 3.4",
  "enunciado": "(Certo ou Errado) O militar da ativa deixa de ser considerado como tal, para o art. 9º, II, “a”, quando está de folga.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.4 — permanece na condição de ativa mesmo em férias, licença ou folga."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.4 — permanece na condição de ativa mesmo em férias, licença ou folga.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 3.4"
 },
 {
  "id": "bz07-034",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 3.5",
  "enunciado": "(Certo ou Errado) Na esfera estadual, civis respondem por crimes militares na Justiça Militar Estadual.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.5 — civis não respondem por crime militar na esfera estadual; são julgados pela Justiça Comum."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.5 — civis não respondem por crime militar na esfera estadual; são julgados pela Justiça Comum.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 3.5"
 },
 {
  "id": "bz07-035",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) Pela Lei nº 13.491/2017, crimes como abuso de autoridade, tortura e os do Estatuto do Desarmamento podem ser crimes militares por extensão quando cometidos por militares nas hipóteses do art. 9º, II.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — Lei nº 13.491/2017."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — Lei nº 13.491/2017.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 4"
 },
 {
  "id": "bz07-036",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) O crime de violência contra superior (Art. 157) pode ser configurado por mera ofensa verbal.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5 — é indispensável haver agressão física."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5 — é indispensável haver agressão física.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 5"
 },
 {
  "id": "bz07-037",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) O crime de embriaguez em serviço exige que da embriaguez resulte dano concreto ao serviço.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5 — Art. 202 é crime de perigo abstrato, independente de resultado concreto."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5 — Art. 202 é crime de perigo abstrato, independente de resultado concreto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 5"
 },
 {
  "id": "bz07-038",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) A corrupção passiva tem aumento de 1/3 quando o agente retarda, omite ou pratica ato infringindo dever funcional.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — Art. 308."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — Art. 308.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 5"
 },
 {
  "id": "bz07-039",
  "disc": "Direito Penal Militar",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) O peculato tem pena de reclusão de 3 a 15 anos, com aumento de 1/3 se o bem for de valor superior a 20 salários mínimos.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — Art. 303, § 1º."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — Art. 303, § 1º.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Tópico 5"
 },
 {
  "id": "bz07-040",
  "disc": "Direito Penal Militar",
  "assunto": "militar estadual (reforço)",
  "enunciado": "Conforme a EC 18 e o Art. 42 da CF/88, a natureza jurídica dos policiais militares e bombeiros militares é a de:",
  "alts": [
   {
    "t": "agentes da autoridade de trânsito, organizados mediante convênio com o Detran."
   },
   {
    "t": "militares da União, organizados com base na hierarquia e na disciplina."
   },
   {
    "t": "militares dos Estados, do DF e dos Territórios, organizados com base na hierarquia e na disciplina.",
    "ok": true
   },
   {
    "t": "servidores civis dos Estados, organizados com base na hierarquia e na disciplina."
   }
  ],
  "resolucao": "==Gabarito: militares dos Estados, do DF e dos Territórios, organizados com base na hierarquia e na disciplina.== Tópico 2.3 — militar estadual (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, militar estadual (reforço)"
 },
 {
  "id": "bz07-041",
  "disc": "Direito Penal Militar",
  "assunto": "Lei nº 13.491/2017 (reforço)",
  "enunciado": "Um PM da ativa pratica, nas hipóteses do art. 9º, II, um crime previsto em lei extravagante (por exemplo, tortura). Após a Lei nº 13.491/2017, esse crime passa a ser considerado:",
  "alts": [
   {
    "t": "crime comum, julgado exclusivamente pela Justiça comum."
   },
   {
    "t": "crime militar por extensão.",
    "ok": true
   },
   {
    "t": "crime de menor potencial ofensivo, afastado da Justiça Militar."
   },
   {
    "t": "crime de competência da Justiça Federal por conexão."
   }
  ],
  "resolucao": "==Gabarito: crime militar por extensão.== Tópico 4 — Lei nº 13.491/2017 (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Lei nº 13.491/2017 (reforço)"
 },
 {
  "id": "bz07-042",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 166 (reforço)",
  "enunciado": "Um militar publica, sem autorização, ato oficial e critica publicamente ato de superior. O fato configura o crime de:",
  "alts": [
   {
    "t": "ofensa aviltante a inferior hierárquico (Art. 176)."
   },
   {
    "t": "prevaricação (Art. 319)."
   },
   {
    "t": "publicação ou crítica indevida (Art. 166).",
    "ok": true
   },
   {
    "t": "recusa de obediência (Art. 163)."
   }
  ],
  "resolucao": "==Gabarito: publicação ou crítica indevida (Art. 166).== Tópico 5 — Art. 166 (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 166 (reforço)"
 },
 {
  "id": "bz07-043",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 195 (reforço)",
  "enunciado": "Um militar deixa o posto de serviço que lhe foi designado, sem ordem superior, antes do término da missão. O crime configurado é o de:",
  "alts": [
   {
    "t": "embriaguez em serviço (Art. 202)."
   },
   {
    "t": "recusa de obediência (Art. 163)."
   },
   {
    "t": "descumprimento de missão (Art. 196)."
   },
   {
    "t": "abandono de posto (Art. 195).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: abandono de posto (Art. 195).== Tópico 5 — Art. 195 (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 195 (reforço)"
 },
 {
  "id": "bz07-044",
  "disc": "Direito Penal Militar",
  "assunto": "Art. 319 (reforço)",
  "enunciado": "Um militar retarda indevidamente um ato de ofício para satisfazer sentimento pessoal. O crime configurado é o de:",
  "alts": [
   {
    "t": "peculato (Art. 303)."
   },
   {
    "t": "desvio (Art. 307)."
   },
   {
    "t": "concussão (Art. 305)."
   },
   {
    "t": "prevaricação (Art. 319).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: prevaricação (Art. 319).== Tópico 5 — Art. 319 (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 7, Art. 319 (reforço)"
 }
]);
