/* Disciplina: Direito Penal (29 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz08-001",
  "disc": "Direito Penal",
  "assunto": "competência legislativa em matéria penal",
  "enunciado": "Em regra, compete privativamente à União legislar sobre direito penal. Na prática, isso significa que:",
  "alts": [
   {
    "t": "o DF pode alterar tipos penais do CP."
   },
   {
    "t": "os Municípios podem criar crimes de interesse local."
   },
   {
    "t": "os Estados podem fixar penas para crimes regionais."
   },
   {
    "t": "Estados, Distrito Federal e Municípios não podem criar crimes, estabelecer penas ou modificar tipos penais por iniciativa própria.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: Estados, Distrito Federal e Municípios não podem criar crimes, estabelecer penas ou modificar tipos penais por iniciativa própria.== Parte 1, item 1 — competência legislativa em matéria penal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, competência legislativa em matéria penal"
 },
 {
  "id": "bz08-002",
  "disc": "Direito Penal",
  "assunto": "princípio da legalidade",
  "enunciado": "O princípio da legalidade se divide em dois pilares fundamentais:",
  "alts": [
   {
    "t": "insignificância e alteridade."
   },
   {
    "t": "reserva legal e anterioridade.",
    "ok": true
   },
   {
    "t": "taxatividade e adequação social."
   },
   {
    "t": "legalidade e proporcionalidade."
   }
  ],
  "resolucao": "==Gabarito: reserva legal e anterioridade.== Parte 1, item 2 — princípio da legalidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, princípio da legalidade"
 },
 {
  "id": "bz08-003",
  "disc": "Direito Penal",
  "assunto": "reserva legal em sentido formal",
  "enunciado": "Na reserva absoluta de lei, podem criar crimes, penas ou medidas de segurança:",
  "alts": [
   {
    "t": "o Governador, por decreto."
   },
   {
    "t": "o Ministro da Justiça, por portaria."
   },
   {
    "t": "somente o Poder Legislativo (Congresso Nacional), por lei ordinária/complementar.",
    "ok": true
   },
   {
    "t": "o Presidente da República, por medida provisória."
   }
  ],
  "resolucao": "==Gabarito: somente o Poder Legislativo (Congresso Nacional), por lei ordinária/complementar.== Parte 1, item 2 — reserva legal em sentido formal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, reserva legal em sentido formal"
 },
 {
  "id": "bz08-004",
  "disc": "Direito Penal",
  "assunto": "vedação ao emprego da analogia",
  "enunciado": "A analogia in malam partem é:",
  "alts": [
   {
    "t": "proibida, pois prejudica o réu ou cria crimes.",
    "ok": true
   },
   {
    "t": "aplicável apenas a militares."
   },
   {
    "t": "obrigatória em crimes graves."
   },
   {
    "t": "permitida, desde que bem fundamentada."
   }
  ],
  "resolucao": "==Gabarito: proibida, pois prejudica o réu ou cria crimes.== Parte 1, item 2 — vedação ao emprego da analogia.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, vedação ao emprego da analogia"
 },
 {
  "id": "bz08-005",
  "disc": "Direito Penal",
  "assunto": "alteridade",
  "enunciado": "Pelo princípio da alteridade, ninguém pode ser punido por:",
  "alts": [
   {
    "t": "danificar patrimônio alheio."
   },
   {
    "t": "ameaçar outra pessoa."
   },
   {
    "t": "causar mal apenas a si mesmo, salvo se atingir terceiro.",
    "ok": true
   },
   {
    "t": "causar lesão a terceiro."
   }
  ],
  "resolucao": "==Gabarito: causar mal apenas a si mesmo, salvo se atingir terceiro.== Parte 1, item 2 — alteridade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, alteridade"
 },
 {
  "id": "bz08-006",
  "disc": "Direito Penal",
  "assunto": "vetores do STF",
  "enunciado": "Os vetores do STF para a insignificância (MARI) são:",
  "alts": [
   {
    "t": "mínima ofensividade, ausência de periculosidade social, reduzida reprovabilidade e inexpressividade da lesão.",
    "ok": true
   },
   {
    "t": "motivo, autoria, resultado e intenção."
   },
   {
    "t": "mínima pena, antecedentes, reparação e interesse."
   },
   {
    "t": "materialidade, autoria, reincidência e indício."
   }
  ],
  "resolucao": "==Gabarito: mínima ofensividade, ausência de periculosidade social, reduzida reprovabilidade e inexpressividade da lesão.== Parte 1, item 2 — vetores do STF.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, vetores do STF"
 },
 {
  "id": "bz08-007",
  "disc": "Direito Penal",
  "assunto": "descaminho",
  "enunciado": "No descaminho (Art. 334 do CP), STF e STJ admitem a insignificância quando o tributo iludido não ultrapassa:",
  "alts": [
   {
    "t": "R$ 1.000,00."
   },
   {
    "t": "R$ 20.000,00.",
    "ok": true
   },
   {
    "t": "R$ 100.000,00."
   },
   {
    "t": "R$ 5.000,00."
   }
  ],
  "resolucao": "==Gabarito: R$ 20.000,00.== Parte 1, item 2 — descaminho.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, descaminho"
 },
 {
  "id": "bz08-008",
  "disc": "Direito Penal",
  "assunto": "abolitio criminis",
  "enunciado": "A abolitio criminis ocorre quando a lei posterior:",
  "alts": [
   {
    "t": "aumenta a pena do crime."
   },
   {
    "t": "deixa de considerar o fato como crime, extinguindo a punibilidade imediatamente.",
    "ok": true
   },
   {
    "t": "reduz a pena do crime."
   },
   {
    "t": "cria nova qualificadora."
   }
  ],
  "resolucao": "==Gabarito: deixa de considerar o fato como crime, extinguindo a punibilidade imediatamente.== Parte 1, item 3 — abolitio criminis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, abolitio criminis"
 },
 {
  "id": "bz08-009",
  "disc": "Direito Penal",
  "assunto": "tempo do crime",
  "enunciado": "Quanto ao tempo do crime, adota-se a teoria:",
  "alts": [
   {
    "t": "da ubiquidade."
   },
   {
    "t": "da intenção."
   },
   {
    "t": "da atividade (momento da ação ou omissão).",
    "ok": true
   },
   {
    "t": "do resultado."
   }
  ],
  "resolucao": "==Gabarito: da atividade (momento da ação ou omissão).== Parte 1, item 3 — tempo do crime.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, tempo do crime"
 },
 {
  "id": "bz08-010",
  "disc": "Direito Penal",
  "assunto": "iter criminis",
  "enunciado": "Na cogitação, no iter criminis:",
  "alts": [
   {
    "t": "há apenas pensamento, impunível.",
    "ok": true
   },
   {
    "t": "o crime está consumado."
   },
   {
    "t": "há tentativa."
   },
   {
    "t": "já há início da execução."
   }
  ],
  "resolucao": "==Gabarito: há apenas pensamento, impunível.== Parte 2, item 2 — iter criminis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, iter criminis"
 },
 {
  "id": "bz08-011",
  "disc": "Direito Penal",
  "assunto": "tentativa",
  "enunciado": "Na tentativa, a pena é reduzida de:",
  "alts": [
   {
    "t": "1/3 a 2/3, sendo a redução menor quanto mais próximo de consumar.",
    "ok": true
   },
   {
    "t": "1/2 a 2/3, sempre."
   },
   {
    "t": "metade, fixa."
   },
   {
    "t": "1/6 a 1/3, sempre."
   }
  ],
  "resolucao": "==Gabarito: 1/3 a 2/3, sendo a redução menor quanto mais próximo de consumar.== Parte 2, item 2 — tentativa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, tentativa"
 },
 {
  "id": "bz08-012",
  "disc": "Direito Penal",
  "assunto": "arrependimento eficaz",
  "enunciado": "O arrependimento eficaz ocorre quando o agente:",
  "alts": [
   {
    "t": "esgota os atos executórios, mas atua ativamente e salva a vítima.",
    "ok": true
   },
   {
    "t": "é impedido de prosseguir por terceiros."
   },
   {
    "t": "repara o dano após consumado o crime."
   },
   {
    "t": "para a execução por vontade própria antes de esgotar os atos."
   }
  ],
  "resolucao": "==Gabarito: esgota os atos executórios, mas atua ativamente e salva a vítima.== Parte 2, item 2 — arrependimento eficaz.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, arrependimento eficaz"
 },
 {
  "id": "bz08-013",
  "disc": "Direito Penal",
  "assunto": "crime impossível",
  "enunciado": "Usar açúcar achando que é veneno é exemplo de crime impossível por:",
  "alts": [
   {
    "t": "impropriedade absoluta do objeto."
   },
   {
    "t": "ineficácia absoluta do meio.",
    "ok": true
   },
   {
    "t": "desistência voluntária."
   },
   {
    "t": "arrependimento posterior."
   }
  ],
  "resolucao": "==Gabarito: ineficácia absoluta do meio.== Parte 2, item 2 — crime impossível.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, crime impossível"
 },
 {
  "id": "bz08-014",
  "disc": "Direito Penal",
  "assunto": "dolo",
  "enunciado": "No dolo eventual, o agente:",
  "alts": [
   {
    "t": "quer diretamente o resultado."
   },
   {
    "t": "assume o risco de produzir o resultado.",
    "ok": true
   },
   {
    "t": "não prevê o resultado."
   },
   {
    "t": "age com imperícia."
   }
  ],
  "resolucao": "==Gabarito: assume o risco de produzir o resultado.== Parte 2, item 3 — dolo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, dolo"
 },
 {
  "id": "bz08-015",
  "disc": "Direito Penal",
  "assunto": "modalidades de culpa",
  "enunciado": "A negligência corresponde a:",
  "alts": [
   {
    "t": "falta de aptidão técnica."
   },
   {
    "t": "ação precipitada."
   },
   {
    "t": "omissão do cuidado.",
    "ok": true
   },
   {
    "t": "dolo direto."
   }
  ],
  "resolucao": "==Gabarito: omissão do cuidado.== Parte 2, item 3 — modalidades de culpa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, modalidades de culpa"
 },
 {
  "id": "bz08-016",
  "disc": "Direito Penal",
  "assunto": "concurso de pessoas e crime culposo",
  "enunciado": "Segundo a doutrina brasileira citada, no crime culposo:",
  "alts": [
   {
    "t": "não se admite nenhum concurso."
   },
   {
    "t": "admite-se participação, mas não coautoria."
   },
   {
    "t": "admite-se apenas participação."
   },
   {
    "t": "admite-se coautoria, mas não participação.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: admite-se coautoria, mas não participação.== Parte 2, item 3 — concurso de pessoas e crime culposo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, concurso de pessoas e crime culposo"
 },
 {
  "id": "bz08-017",
  "disc": "Direito Penal",
  "assunto": "estado de necessidade",
  "enunciado": "No estado de necessidade, quem tem dever legal de enfrentar o perigo:",
  "alts": [
   {
    "t": "fica isento de pena em qualquer caso."
   },
   {
    "t": "pode alegá-lo livremente."
   },
   {
    "t": "não pode alegá-lo.",
    "ok": true
   },
   {
    "t": "só pode alegá-lo à noite."
   }
  ],
  "resolucao": "==Gabarito: não pode alegá-lo.== Parte 3, item 2 — estado de necessidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, estado de necessidade"
 },
 {
  "id": "bz08-018",
  "disc": "Direito Penal",
  "assunto": "excesso punível",
  "enunciado": "Continuar golpeando o agressor caído e imobilizado configura:",
  "alts": [
   {
    "t": "legítima defesa."
   },
   {
    "t": "excesso punível (doloso ou culposo).",
    "ok": true
   },
   {
    "t": "crime impossível."
   },
   {
    "t": "estado de necessidade."
   }
  ],
  "resolucao": "==Gabarito: excesso punível (doloso ou culposo).== Parte 3, item 2 — excesso punível.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, excesso punível"
 },
 {
  "id": "bz08-019",
  "disc": "Direito Penal",
  "assunto": "participação de menor importância",
  "enunciado": "A participação de menor importância gera redução de pena de:",
  "alts": [
   {
    "t": "extinção da pena."
   },
   {
    "t": "1/3 a 2/3."
   },
   {
    "t": "metade."
   },
   {
    "t": "1/6 a 1/3.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 1/6 a 1/3.== Parte 3, item 3 — participação de menor importância.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, participação de menor importância"
 },
 {
  "id": "bz08-020",
  "disc": "Direito Penal",
  "assunto": "Parte 1, item 2",
  "enunciado": "(Certo ou Errado) Medidas provisórias, decretos, portarias e costumes não podem criar crimes ou penas.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Parte 1, item 2 — reserva absoluta de lei."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Parte 1, item 2 — reserva absoluta de lei.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 1, item 2"
 },
 {
  "id": "bz08-021",
  "disc": "Direito Penal",
  "assunto": "Parte 1, item 2",
  "enunciado": "(Certo ou Errado) O princípio da insignificância é aplicável, sem exceções, a todos os crimes contra a Administração Pública.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Parte 1, item 2 — Súmula 599 do STJ: inaplicável (exceções raríssimas)."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Parte 1, item 2 — Súmula 599 do STJ: inaplicável (exceções raríssimas).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 1, item 2"
 },
 {
  "id": "bz08-022",
  "disc": "Direito Penal",
  "assunto": "Parte 1, item 3",
  "enunciado": "(Certo ou Errado) A abolitio criminis extingue a punibilidade imediatamente, soltando o réu preso.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Parte 1, item 3 — abolitio criminis."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Parte 1, item 3 — abolitio criminis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 1, item 3"
 },
 {
  "id": "bz08-023",
  "disc": "Direito Penal",
  "assunto": "Parte 1, item 3",
  "enunciado": "(Certo ou Errado) A lei mais grave retroage para alcançar fatos anteriores à sua vigência.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Parte 1, item 3 — a lei mais grave nunca retroage."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Parte 1, item 3 — a lei mais grave nunca retroage.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 1, item 3"
 },
 {
  "id": "bz08-024",
  "disc": "Direito Penal",
  "assunto": "Parte 2, item 2",
  "enunciado": "(Certo ou Errado) A preparação, em regra, não é punível, salvo quando constituir crime autônomo, como o porte ilegal de arma.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Parte 2, item 2 — iter criminis."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Parte 2, item 2 — iter criminis.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 2, item 2"
 },
 {
  "id": "bz08-025",
  "disc": "Direito Penal",
  "assunto": "Parte 2, item 2",
  "enunciado": "(Certo ou Errado) Na desistência voluntária e no arrependimento eficaz, o agente responde pela tentativa.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Parte 2, item 2 — afastam a tentativa; responde apenas pelos atos já praticados."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Parte 2, item 2 — afastam a tentativa; responde apenas pelos atos já praticados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 2, item 2"
 },
 {
  "id": "bz08-026",
  "disc": "Direito Penal",
  "assunto": "Parte 2, item 2",
  "enunciado": "(Certo ou Errado) No arrependimento posterior, o crime já se consumou e a pena é reduzida de 1/3 a 2/3.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Parte 2, item 2 — arrependimento posterior."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Parte 2, item 2 — arrependimento posterior.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 2, item 2"
 },
 {
  "id": "bz08-027",
  "disc": "Direito Penal",
  "assunto": "Parte 2, item 3",
  "enunciado": "(Certo ou Errado) O crime culposo existe apenas se houver previsão em lei.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Parte 2, item 3 — excepcionalidade do crime culposo."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Parte 2, item 3 — excepcionalidade do crime culposo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 2, item 3"
 },
 {
  "id": "bz08-028",
  "disc": "Direito Penal",
  "assunto": "Parte 3, item 1",
  "enunciado": "(Certo ou Errado) Na coação moral irresistível, o coagido é o único punido.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Parte 3, item 1 — só o coator é punido."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Parte 3, item 1 — só o coator é punido.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, Parte 3, item 1"
 },
 {
  "id": "bz08-029",
  "disc": "Direito Penal",
  "assunto": "coação moral irresistível (reforço)",
  "enunciado": "Na coação moral irresistível, em que alguém pratica o crime sob grave ameaça, a excludente de culpabilidade faz com que seja punido:",
  "alts": [
   {
    "t": "apenas o coator, autor da grave ameaça.",
    "ok": true
   },
   {
    "t": "apenas o coagido, que executou o ato."
   },
   {
    "t": "ambos, em coautoria."
   },
   {
    "t": "nenhum dos dois, pois o fato é atípico."
   }
  ],
  "resolucao": "==Gabarito: apenas o coator, autor da grave ameaça.== Parte 3, item 1 — coação moral irresistível (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 8, coação moral irresistível (reforço)"
 }
]);
