/* Disciplina: Direito Processual Penal (26 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz09-001",
  "disc": "Direito Processual Penal",
  "assunto": "prisão-pena",
  "enunciado": "A prisão-pena (prisão comum) é aquela decorrente de:",
  "alts": [
   {
    "t": "decisão cautelar antes da denúncia."
   },
   {
    "t": "condenação criminal, observados os requisitos constitucionais e legais para sua execução.",
    "ok": true
   },
   {
    "t": "simples suspeita policial."
   },
   {
    "t": "ordem administrativa do comandante."
   }
  ],
  "resolucao": "==Gabarito: condenação criminal, observados os requisitos constitucionais e legais para sua execução.== Tópico 1.1 — prisão-pena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prisão-pena"
 },
 {
  "id": "bz09-002",
  "disc": "Direito Processual Penal",
  "assunto": "prisões cautelares",
  "enunciado": "As prisões cautelares são utilizadas:",
  "alts": [
   {
    "t": "apenas em crimes de menor potencial ofensivo."
   },
   {
    "t": "somente após o trânsito em julgado."
   },
   {
    "t": "antes do trânsito em julgado da condenação, com finalidade cautelar, não podendo ser antecipação de pena.",
    "ok": true
   },
   {
    "t": "como forma de antecipação de pena."
   }
  ],
  "resolucao": "==Gabarito: antes do trânsito em julgado da condenação, com finalidade cautelar, não podendo ser antecipação de pena.== Tópico 1.2 — prisões cautelares.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prisões cautelares"
 },
 {
  "id": "bz09-003",
  "disc": "Direito Processual Penal",
  "assunto": "incisos I e II",
  "enunciado": "Segundo o CPP, é flagrante próprio a situação de quem:",
  "alts": [
   {
    "t": "é denunciado anonimamente."
   },
   {
    "t": "está cometendo a infração ou acaba de cometê-la.",
    "ok": true
   },
   {
    "t": "é perseguido por qualquer pessoa, logo após."
   },
   {
    "t": "é encontrado dias depois, sem qualquer indício."
   }
  ],
  "resolucao": "==Gabarito: está cometendo a infração ou acaba de cometê-la.== Tópico 2 — incisos I e II.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, incisos I e II"
 },
 {
  "id": "bz09-004",
  "disc": "Direito Processual Penal",
  "assunto": "inciso I",
  "enunciado": "O policial que presencia uma pessoa praticando um roubo encontra-se diante de flagrante:",
  "alts": [
   {
    "t": "presumido."
   },
   {
    "t": "próprio (art. 302, I).",
    "ok": true
   },
   {
    "t": "impróprio."
   },
   {
    "t": "ficto."
   }
  ],
  "resolucao": "==Gabarito: próprio (art. 302, I).== Tópico 2 — inciso I.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, inciso I"
 },
 {
  "id": "bz09-005",
  "disc": "Direito Processual Penal",
  "assunto": "inciso IV",
  "enunciado": "O flagrante presumido (ficto) ocorre quando o autor:",
  "alts": [
   {
    "t": "é perseguido logo após o crime."
   },
   {
    "t": "é denunciado por testemunha."
   },
   {
    "t": "está cometendo o crime."
   },
   {
    "t": "é encontrado logo depois com instrumentos, armas, objetos ou papéis que façam presumir ser ele o autor.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: é encontrado logo depois com instrumentos, armas, objetos ou papéis que façam presumir ser ele o autor.== Tópico 2 — inciso IV.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, inciso IV"
 },
 {
  "id": "bz09-006",
  "disc": "Direito Processual Penal",
  "assunto": "prisão temporária",
  "enunciado": "A prisão temporária é uma prisão cautelar destinada principalmente:",
  "alts": [
   {
    "t": "ao julgamento em plenário."
   },
   {
    "t": "à fase de execução da pena."
   },
   {
    "t": "ao cumprimento de pena definitiva."
   },
   {
    "t": "à fase de investigação criminal, nas hipóteses previstas em lei.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: à fase de investigação criminal, nas hipóteses previstas em lei.== Tópico 3 — prisão temporária.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prisão temporária"
 },
 {
  "id": "bz09-007",
  "disc": "Direito Processual Penal",
  "assunto": "prazos",
  "enunciado": "Na regra geral, a prisão temporária dura:",
  "alts": [
   {
    "t": "30 dias, prorrogáveis por 30."
   },
   {
    "t": "10 dias, sem prorrogação."
   },
   {
    "t": "5 dias, prorrogáveis por mais 5 dias em caso de extrema e comprovada necessidade.",
    "ok": true
   },
   {
    "t": "60 dias."
   }
  ],
  "resolucao": "==Gabarito: 5 dias, prorrogáveis por mais 5 dias em caso de extrema e comprovada necessidade.== Tópico 3 — prazos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prazos"
 },
 {
  "id": "bz09-008",
  "disc": "Direito Processual Penal",
  "assunto": "prazos",
  "enunciado": "Nos crimes hediondos e equiparados, a prisão temporária pode durar:",
  "alts": [
   {
    "t": "10 dias."
   },
   {
    "t": "5 dias, prorrogáveis por mais 5."
   },
   {
    "t": "90 dias, sem prorrogação."
   },
   {
    "t": "até 30 dias, prorrogáveis por mais 30 dias se houver necessidade comprovada.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: até 30 dias, prorrogáveis por mais 30 dias se houver necessidade comprovada.== Tópico 3 — prazos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prazos"
 },
 {
  "id": "bz09-009",
  "disc": "Direito Processual Penal",
  "assunto": "fundamentos",
  "enunciado": "Quando o acusado ameaça testemunhas ou interfere concretamente na produção da prova, o fundamento da preventiva é a:",
  "alts": [
   {
    "t": "garantia de aplicação da lei penal."
   },
   {
    "t": "garantia da ordem pública."
   },
   {
    "t": "garantia da ordem econômica."
   },
   {
    "t": "conveniência da instrução criminal.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: conveniência da instrução criminal.== Tópico 4 — fundamentos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, fundamentos"
 },
 {
  "id": "bz09-010",
  "disc": "Direito Processual Penal",
  "assunto": "fundamentos",
  "enunciado": "Quando há elementos concretos que indiquem risco de fuga, o fundamento da preventiva é a:",
  "alts": [
   {
    "t": "garantia de aplicação da lei penal.",
    "ok": true
   },
   {
    "t": "garantia da ordem pública."
   },
   {
    "t": "conveniência da instrução criminal."
   },
   {
    "t": "suspensão do processo."
   }
  ],
  "resolucao": "==Gabarito: garantia de aplicação da lei penal.== Tópico 4 — fundamentos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, fundamentos"
 },
 {
  "id": "bz09-011",
  "disc": "Direito Processual Penal",
  "assunto": "aspectos analisados",
  "enunciado": "Entre as finalidades da audiência de custódia está a verificação de:",
  "alts": [
   {
    "t": "a culpabilidade do preso."
   },
   {
    "t": "eventual violência, tortura ou maus-tratos por parte dos agentes de segurança.",
    "ok": true
   },
   {
    "t": "o valor do dano patrimonial."
   },
   {
    "t": "a quantidade de testemunhas."
   }
  ],
  "resolucao": "==Gabarito: eventual violência, tortura ou maus-tratos por parte dos agentes de segurança.== Tópico 5 — aspectos analisados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, aspectos analisados"
 },
 {
  "id": "bz09-012",
  "disc": "Direito Processual Penal",
  "assunto": "MDIP",
  "enunciado": "A morte decorrente de intervenção policial (MDIP) é:",
  "alts": [
   {
    "t": "o óbito de uma pessoa durante ação de agentes públicos, com implicações legais específicas para a investigação e a responsabilidade do Estado.",
    "ok": true
   },
   {
    "t": "sempre legítima defesa."
   },
   {
    "t": "sempre homicídio doloso qualificado."
   },
   {
    "t": "evento que dispensa investigação."
   }
  ],
  "resolucao": "==Gabarito: o óbito de uma pessoa durante ação de agentes públicos, com implicações legais específicas para a investigação e a responsabilidade do Estado.== Tópico 6 — MDIP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, MDIP"
 },
 {
  "id": "bz09-013",
  "disc": "Direito Processual Penal",
  "assunto": "constituição de defensor",
  "enunciado": "Esgotado o prazo sem a constituição de defensor, a autoridade deve intimar a instituição do investigado para que indique defensor em:",
  "alts": [
   {
    "t": "5 dias."
   },
   {
    "t": "24 horas."
   },
   {
    "t": "10 dias."
   },
   {
    "t": "48 horas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 48 horas.== Tópico 6 — constituição de defensor.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, constituição de defensor"
 },
 {
  "id": "bz09-014",
  "disc": "Direito Processual Penal",
  "assunto": "defesa preferencial",
  "enunciado": "A defesa do policial investigado em MDIP caberá preferencialmente:",
  "alts": [
   {
    "t": "ao Ministério Público."
   },
   {
    "t": "à Defensoria Pública.",
    "ok": true
   },
   {
    "t": "ao delegado de polícia."
   },
   {
    "t": "a advogado dativo do Judiciário."
   }
  ],
  "resolucao": "==Gabarito: à Defensoria Pública.== Tópico 6 — defesa preferencial.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, defesa preferencial"
 },
 {
  "id": "bz09-015",
  "disc": "Direito Processual Penal",
  "assunto": "medidas cautelares",
  "enunciado": "É medida cautelar diversa da prisão:",
  "alts": [
   {
    "t": "pena de reclusão."
   },
   {
    "t": "prisão temporária."
   },
   {
    "t": "prisão preventiva."
   },
   {
    "t": "comparecimento periódico em juízo, para informar e justificar atividades.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: comparecimento periódico em juízo, para informar e justificar atividades.== Tópico 7 — medidas cautelares.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, medidas cautelares"
 },
 {
  "id": "bz09-016",
  "disc": "Direito Processual Penal",
  "assunto": "medida V",
  "enunciado": "O recolhimento domiciliar, como medida cautelar diversa da prisão, ocorre:",
  "alts": [
   {
    "t": "durante o período noturno e nos dias de folga.",
    "ok": true
   },
   {
    "t": "apenas em horário comercial."
   },
   {
    "t": "em tempo integral, sempre."
   },
   {
    "t": "somente aos domingos."
   }
  ],
  "resolucao": "==Gabarito: durante o período noturno e nos dias de folga.== Tópico 7 — medida V.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, medida V"
 },
 {
  "id": "bz09-017",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 1.2",
  "enunciado": "(Certo ou Errado) As prisões cautelares podem ser utilizadas como antecipação de pena.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 1.2 — possuem finalidade cautelar e não podem ser antecipação de pena."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 1.2 — possuem finalidade cautelar e não podem ser antecipação de pena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 1.2"
 },
 {
  "id": "bz09-018",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O policial que encontra o autor, logo depois, com armas e objetos que façam presumir ser ele o autor da infração, está diante de flagrante presumido (ficto).",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — inciso IV."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — inciso IV.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 2"
 },
 {
  "id": "bz09-019",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O flagrante impróprio exige que a perseguição seja feita exclusivamente pela autoridade policial.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2 — a perseguição pode ser pela autoridade, pelo ofendido ou por qualquer pessoa."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2 — a perseguição pode ser pela autoridade, pelo ofendido ou por qualquer pessoa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 2"
 },
 {
  "id": "bz09-020",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 3",
  "enunciado": "(Certo ou Errado) Nos crimes hediondos e equiparados, a prisão temporária pode ser de 30 dias, prorrogáveis por mais 30.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3 — prazos."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3 — prazos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 3"
 },
 {
  "id": "bz09-021",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) A prisão preventiva só pode ser decretada após o trânsito em julgado.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 4 — pode ser decretada durante a investigação ou no curso do processo."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 4 — pode ser decretada durante a investigação ou no curso do processo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 4"
 },
 {
  "id": "bz09-022",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) As regras de defesa em casos de uso da força letal aplicam-se também aos membros das Forças Armadas em missões de GLO.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — constituição de defensor."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — constituição de defensor.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 6"
 },
 {
  "id": "bz09-023",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 7",
  "enunciado": "(Certo ou Errado) A proibição de contato com pessoa e a fiança estão entre as medidas cautelares diversas da prisão.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 7 — medidas III e VIII."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 7 — medidas III e VIII.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 7"
 },
 {
  "id": "bz09-024",
  "disc": "Direito Processual Penal",
  "assunto": "prazo da audiência de custódia (reforço)",
  "enunciado": "Após a prisão em flagrante, a pessoa presa deve ser apresentada à autoridade judicial na audiência de custódia no prazo máximo de:",
  "alts": [
   {
    "t": "72 horas após a prisão."
   },
   {
    "t": "24 horas após a prisão.",
    "ok": true
   },
   {
    "t": "48 horas após a prisão."
   },
   {
    "t": "5 dias após a prisão."
   }
  ],
  "resolucao": "==Gabarito: 24 horas após a prisão.== Tópico 5 — prazo da audiência de custódia (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, prazo da audiência de custódia (reforço)"
 },
 {
  "id": "bz09-025",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) Na audiência de custódia, o juiz analisa a legalidade da prisão e eventual violência dos agentes, mas não julga o mérito, isto é, não decide se o preso é culpado ou inocente.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — a custódia NÃO é julgamento de mérito (reforço)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — a custódia NÃO é julgamento de mérito (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 5"
 },
 {
  "id": "bz09-026",
  "disc": "Direito Processual Penal",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) O policial investigado em procedimento sobre uso da força letal pode constituir defensor em até 48 horas e, a qualquer tempo, contratar advogado particular, arcando com os custos.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 6 — constituição de defensor (reforço)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 6 — constituição de defensor (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 9, Tópico 6"
 }
]);
