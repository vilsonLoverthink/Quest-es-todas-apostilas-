/* Disciplina: Atendimento Pré-Hospitalar (15 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz10-001",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "definição",
  "enunciado": "O protocolo MARC 1 é:",
  "alts": [
   {
    "t": "um protocolo de negociação de reféns."
   },
   {
    "t": "a diretriz brasileira de atendimento pré-hospitalar para combate e suporte ao trauma, baseada no modelo internacional TCCC.",
    "ok": true
   },
   {
    "t": "uma norma de tiro policial."
   },
   {
    "t": "um protocolo de abordagem de trânsito."
   }
  ],
  "resolucao": "==Gabarito: a diretriz brasileira de atendimento pré-hospitalar para combate e suporte ao trauma, baseada no modelo internacional TCCC.== Tópico 1 — definição.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, definição"
 },
 {
  "id": "bz10-002",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "atenção",
  "enunciado": "O número 1 no nome MARC 1 indica que o protocolo é executado:",
  "alts": [
   {
    "t": "apenas por médicos no hospital."
   },
   {
    "t": "no nível do operador tático ou do primeiro interventor, usando o equipamento individual de primeiros socorros (IFAK).",
    "ok": true
   },
   {
    "t": "somente por equipes de resgate aéreo."
   },
   {
    "t": "em centros cirúrgicos."
   }
  ],
  "resolucao": "==Gabarito: no nível do operador tático ou do primeiro interventor, usando o equipamento individual de primeiros socorros (IFAK).== Tópico 1 — atenção.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, atenção"
 },
 {
  "id": "bz10-003",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "M",
  "enunciado": "Na etapa M, a principal prioridade é o sangramento arterial ou venoso grave porque:",
  "alts": [
   {
    "t": "mata em poucos minutos.",
    "ok": true
   },
   {
    "t": "pode esperar o hospital."
   },
   {
    "t": "causa apenas desconforto."
   },
   {
    "t": "é raro em combate."
   }
  ],
  "resolucao": "==Gabarito: mata em poucos minutos.== Tópico 1.1 — M.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, M"
 },
 {
  "id": "bz10-004",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "M",
  "enunciado": "Em locais de junção (virilha e axilas), realiza-se o wound packing com gaze hemostática, seguido de pressão direta firme por no mínimo:",
  "alts": [
   {
    "t": "3 minutos.",
    "ok": true
   },
   {
    "t": "30 segundos."
   },
   {
    "t": "10 minutos."
   },
   {
    "t": "1 hora."
   }
  ],
  "resolucao": "==Gabarito: 3 minutos.== Tópico 1.1 — M.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, M"
 },
 {
  "id": "bz10-005",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "A",
  "enunciado": "Em vítimas inconscientes que mantêm reflexos, utiliza-se:",
  "alts": [
   {
    "t": "a cânula nasofaríngea (NPA).",
    "ok": true
   },
   {
    "t": "o torniquete."
   },
   {
    "t": "o selo de tórax."
   },
   {
    "t": "a manta térmica."
   }
  ],
  "resolucao": "==Gabarito: a cânula nasofaríngea (NPA).== Tópico 1.2 — A.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, A"
 },
 {
  "id": "bz10-006",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "R",
  "enunciado": "A letra R do MARC trata de:",
  "alts": [
   {
    "t": "remoção do ferido."
   },
   {
    "t": "relato da ocorrência."
   },
   {
    "t": "respiração, especialmente o pneumotórax.",
    "ok": true
   },
   {
    "t": "reanimação cerebral."
   }
  ],
  "resolucao": "==Gabarito: respiração, especialmente o pneumotórax.== Tópico 1.3 — R.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, R"
 },
 {
  "id": "bz10-007",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "R",
  "enunciado": "No pneumotórax hipertensivo, com piora respiratória e choque, realiza-se:",
  "alts": [
   {
    "t": "a cricotireoidostomia, sempre."
   },
   {
    "t": "a descompressão por agulha.",
    "ok": true
   },
   {
    "t": "o wound packing."
   },
   {
    "t": "o torniquete."
   }
  ],
  "resolucao": "==Gabarito: a descompressão por agulha.== Tópico 1.3 — R.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, R"
 },
 {
  "id": "bz10-008",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "C",
  "enunciado": "Na etapa C, a conduta inclui retirar roupas molhadas, isolar a vítima do solo frio e:",
  "alts": [
   {
    "t": "dispensar a reavaliação dos curativos."
   },
   {
    "t": "oferecer água fria."
   },
   {
    "t": "mantê-la no chão molhado."
   },
   {
    "t": "envolvê-la em manta térmica aluminizada ou cobertores, reavaliando torniquetes e curativos.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: envolvê-la em manta térmica aluminizada ou cobertores, reavaliando torniquetes e curativos.== Tópico 1.4 — C.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, C"
 },
 {
  "id": "bz10-009",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "princípio fundamental",
  "enunciado": "O princípio fundamental do APH tático é:",
  "alts": [
   {
    "t": "intervenção médica correta + tempo tático correto.",
    "ok": true
   },
   {
    "t": "apenas o tempo tático."
   },
   {
    "t": "dispensar a segurança da cena."
   },
   {
    "t": "intervenção médica imediata em qualquer cenário."
   }
  ],
  "resolucao": "==Gabarito: intervenção médica correta + tempo tático correto.== Tópico 3 — princípio fundamental.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, princípio fundamental"
 },
 {
  "id": "bz10-010",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "procedimentos de combate",
  "enunciado": "“Procurar abrigo (sair do X)” significa:",
  "alts": [
   {
    "t": "permanecer exposto para atender a vítima."
   },
   {
    "t": "retirar o colete."
   },
   {
    "t": "abandonar a guarnição."
   },
   {
    "t": "identificar e neutralizar ameaças imediatas ou responder ao fogo inimigo.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: identificar e neutralizar ameaças imediatas ou responder ao fogo inimigo.== Tópico 4 — procedimentos de combate.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, procedimentos de combate"
 },
 {
  "id": "bz10-011",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "Tópico 1",
  "enunciado": "(Certo ou Errado) No protocolo MARC 1, a ordem de prioridade segue a letalidade das causas evitáveis de morte.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1 — foco principal."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1 — foco principal.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, Tópico 1"
 },
 {
  "id": "bz10-012",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "Tópico 1.1",
  "enunciado": "(Certo ou Errado) Em locais de junção (virilha e axilas), a conduta é o torniquete 5 a 7 cm acima da ferida.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 1.1 — nas junções realiza-se wound packing com gaze hemostática e pressão direta ≥ 3 min."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 1.1 — nas junções realiza-se wound packing com gaze hemostática e pressão direta ≥ 3 min.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, Tópico 1.1"
 },
 {
  "id": "bz10-013",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "Tópico 1.2",
  "enunciado": "(Certo ou Errado) A abertura das vias aéreas deve ser feita com hiperextensão cervical desnecessária para garantir a passagem do ar.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 1.2 — as manobras são feitas sem hiperextensão cervical desnecessária."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 1.2 — as manobras são feitas sem hiperextensão cervical desnecessária.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, Tópico 1.2"
 },
 {
  "id": "bz10-014",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "Tópico 1.3",
  "enunciado": "(Certo ou Errado) O selo de tórax valvulado é indicado para feridas torácicas abertas/aspirativas.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1.3 — R."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1.3 — R.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, Tópico 1.3"
 },
 {
  "id": "bz10-015",
  "disc": "Atendimento Pré-Hospitalar",
  "assunto": "Tópico 1.4",
  "enunciado": "(Certo ou Errado) A prevenção da hipotermia compõe a etapa C e é importante porque a hipotermia integra a tríade letal do trauma.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1.4 — C."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1.4 — C.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 10, Tópico 1.4"
 }
]);
