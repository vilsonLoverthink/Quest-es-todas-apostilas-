/* Disciplina: Diversidade Étnico-Sociocultural (16 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz11-001",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "conceitos fundamentais",
  "enunciado": "A diversidade étnico-sociocultural é o reconhecimento, a valorização e o respeito às diferentes:",
  "alts": [
   {
    "t": "regiões, com preferência pela mais rica."
   },
   {
    "t": "religiões, excluindo as minoritárias."
   },
   {
    "t": "classes sociais, para manter a hierarquia entre elas."
   },
   {
    "t": "culturas, etnias, tradições e modos de vida, promovendo inclusão e combate ao preconceito.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: culturas, etnias, tradições e modos de vida, promovendo inclusão e combate ao preconceito.== Tópico 1 — conceitos fundamentais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, conceitos fundamentais"
 },
 {
  "id": "bz11-002",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "discriminação racial",
  "enunciado": "A discriminação racial é qualquer distinção, exclusão, restrição ou tratamento desigual baseado em:",
  "alts": [
   {
    "t": "renda e escolaridade, apenas."
   },
   {
    "t": "raça, cor, descendência ou origem étnica, que prejudique ou limite direitos e oportunidades.",
    "ok": true
   },
   {
    "t": "preferência esportiva."
   },
   {
    "t": "idade e profissão, apenas."
   }
  ],
  "resolucao": "==Gabarito: raça, cor, descendência ou origem étnica, que prejudique ou limite direitos e oportunidades.== Tópico 1 — discriminação racial.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, discriminação racial"
 },
 {
  "id": "bz11-003",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "perfilamento racial",
  "enunciado": "O perfilamento racial é:",
  "alts": [
   {
    "t": "o cadastro de suspeitos por comportamento criminoso comprovado."
   },
   {
    "t": "a identificação e suspeita de indivíduos com base em raça, etnia ou aparência, sem evidências objetivas de envolvimento em atividades ilícitas.",
    "ok": true
   },
   {
    "t": "a análise técnica de impressões digitais."
   },
   {
    "t": "a abordagem baseada em fundada suspeita concreta."
   }
  ],
  "resolucao": "==Gabarito: a identificação e suspeita de indivíduos com base em raça, etnia ou aparência, sem evidências objetivas de envolvimento em atividades ilícitas.== Tópico 1 — perfilamento racial.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, perfilamento racial"
 },
 {
  "id": "bz11-004",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "racismo",
  "enunciado": "O racismo atinge:",
  "alts": [
   {
    "t": "somente servidores públicos."
   },
   {
    "t": "apenas menores de idade."
   },
   {
    "t": "um indivíduo específico, apenas."
   },
   {
    "t": "uma coletividade indeterminada de pessoas discriminadas por sua raça/etnia.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: uma coletividade indeterminada de pessoas discriminadas por sua raça/etnia.== Tópico 2 — racismo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, racismo"
 },
 {
  "id": "bz11-005",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "injúria racial",
  "enunciado": "A injúria racial consiste em:",
  "alts": [
   {
    "t": "ofender a dignidade ou decoro de um indivíduo específico valendo-se de elementos referentes a raça, cor, etnia, religião ou origem.",
    "ok": true
   },
   {
    "t": "negar atendimento a grupo inteiro."
   },
   {
    "t": "discriminar uma coletividade indeterminada."
   },
   {
    "t": "difundir boatos sobre uma instituição."
   }
  ],
  "resolucao": "==Gabarito: ofender a dignidade ou decoro de um indivíduo específico valendo-se de elementos referentes a raça, cor, etnia, religião ou origem.== Tópico 2 — injúria racial.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, injúria racial"
 },
 {
  "id": "bz11-006",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "pena da injúria racial",
  "enunciado": "A pena da injúria racial passou a ser de:",
  "alts": [
   {
    "t": "apenas multa."
   },
   {
    "t": "reclusão de 12 a 30 anos."
   },
   {
    "t": "detenção de 1 a 3 meses."
   },
   {
    "t": "reclusão de 2 a 5 anos, além de multa.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: reclusão de 2 a 5 anos, além de multa.== Tópico 2 — pena da injúria racial.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, pena da injúria racial"
 },
 {
  "id": "bz11-007",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "assistência obrigatória",
  "enunciado": "A vítima dos crimes de racismo deverá obrigatoriamente estar acompanhada de:",
  "alts": [
   {
    "t": "juiz de paz."
   },
   {
    "t": "advogado ou defensor público.",
    "ok": true
   },
   {
    "t": "representante da OAB."
   },
   {
    "t": "delegado de polícia."
   }
  ],
  "resolucao": "==Gabarito: advogado ou defensor público.== Tópico 2 — assistência obrigatória.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, assistência obrigatória"
 },
 {
  "id": "bz11-008",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "assédio moral",
  "enunciado": "O assédio moral consiste na exposição:",
  "alts": [
   {
    "t": "pontual a uma única crítica profissional."
   },
   {
    "t": "ao reconhecimento do mérito."
   },
   {
    "t": "a normas de segurança."
   },
   {
    "t": "repetitiva e prolongada do trabalhador a situações humilhantes, constrangedoras ou desqualificantes.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: repetitiva e prolongada do trabalhador a situações humilhantes, constrangedoras ou desqualificantes.== Tópico 3 — assédio moral.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, assédio moral"
 },
 {
  "id": "bz11-009",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "assédio moral",
  "enunciado": "É manifestação do assédio moral:",
  "alts": [
   {
    "t": "elogio público por desempenho."
   },
   {
    "t": "comentários pejorativos recorrentes, isolamento do indivíduo e sobrecarga proposital de tarefas.",
    "ok": true
   },
   {
    "t": "distribuição equilibrada de tarefas."
   },
   {
    "t": "reunião de feedback técnico."
   }
  ],
  "resolucao": "==Gabarito: comentários pejorativos recorrentes, isolamento do indivíduo e sobrecarga proposital de tarefas.== Tópico 3 — assédio moral.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, assédio moral"
 },
 {
  "id": "bz11-010",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "assédio sexual por ambientação",
  "enunciado": "O assédio sexual por ambientação:",
  "alts": [
   {
    "t": "exige superioridade hierárquica."
   },
   {
    "t": "é sempre crime do Art. 216-A."
   },
   {
    "t": "não exige hierarquia; as investidas indesejadas criam ambiente hostil, intimidador e ofensivo, podendo ser praticado por colegas ou terceiros.",
    "ok": true
   },
   {
    "t": "só ocorre entre chefe e subordinado."
   }
  ],
  "resolucao": "==Gabarito: não exige hierarquia; as investidas indesejadas criam ambiente hostil, intimidador e ofensivo, podendo ser praticado por colegas ou terceiros.== Tópico 3 — assédio sexual por ambientação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, assédio sexual por ambientação"
 },
 {
  "id": "bz11-011",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "medidas protetivas de urgência",
  "enunciado": "Segundo o STF, as medidas protetivas de urgência da Lei Maria da Penha passam a valer:",
  "alts": [
   {
    "t": "somente quando houver coabitação."
   },
   {
    "t": "apenas para vítimas menores de idade."
   },
   {
    "t": "para qualquer caso de violência de gênero contra a mulher, mesmo sem vínculo doméstico, familiar ou afetivo.",
    "ok": true
   },
   {
    "t": "somente para casais casados."
   }
  ],
  "resolucao": "==Gabarito: para qualquer caso de violência de gênero contra a mulher, mesmo sem vínculo doméstico, familiar ou afetivo.== Tópico 4 — medidas protetivas de urgência.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, medidas protetivas de urgência"
 },
 {
  "id": "bz11-012",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "Tópico 1",
  "enunciado": "(Certo ou Errado) Estatísticas indicam, segundo a apostila, que policiais negros são os que mais morrem em confrontos.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1 — contexto operacional."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1 — contexto operacional.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, Tópico 1"
 },
 {
  "id": "bz11-013",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O racismo é um tipo de injúria racial.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2 — o inverso: a injúria racial é um tipo de racismo."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2 — o inverso: a injúria racial é um tipo de racismo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, Tópico 2"
 },
 {
  "id": "bz11-014",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) Racismo e injúria racial são crimes imprescritíveis e inafiançáveis.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — quadro comparativo."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — quadro comparativo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, Tópico 2"
 },
 {
  "id": "bz11-015",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "Tópico 3",
  "enunciado": "(Certo ou Errado) O assédio moral exige superioridade hierárquica para ser caracterizado.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3 — o assédio moral não exige hierarquia."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3 — o assédio moral não exige hierarquia.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, Tópico 3"
 },
 {
  "id": "bz11-016",
  "disc": "Diversidade Étnico-Sociocultural",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) A violência vicária usa terceiros como instrumento para causar sofrimento psicológico à mulher.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — violência vicária."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — violência vicária.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 11, Tópico 4"
 }
]);
