/* Disciplina: Direito Constitucional (38 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz12-001",
  "disc": "Direito Constitucional",
  "assunto": "R-A (Racismo e Grupos Armados)",
  "enunciado": "Segundo o resumo prático da CF/88, são imprescritíveis e inafiançáveis:",
  "alts": [
   {
    "t": "a tortura e o tráfico."
   },
   {
    "t": "o racismo e a ação de grupos armados contra a ordem constitucional e o Estado Democrático.",
    "ok": true
   },
   {
    "t": "somente o homicídio doloso."
   },
   {
    "t": "o terrorismo e os crimes hediondos."
   }
  ],
  "resolucao": "==Gabarito: o racismo e a ação de grupos armados contra a ordem constitucional e o Estado Democrático.== Tópico 1 — R-A (Racismo e Grupos Armados).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, R-A (Racismo e Grupos Armados)"
 },
 {
  "id": "bz12-002",
  "disc": "Direito Constitucional",
  "assunto": "3T + H",
  "enunciado": "A sigla “3T + H” designa:",
  "alts": [
   {
    "t": "tortura, tráfico, terrorismo e hediondos, inafiançáveis e insuscetíveis de graça, indulto ou anistia.",
    "ok": true
   },
   {
    "t": "terrorismo, transporte, tributo e hediondos."
   },
   {
    "t": "tentativa, tráfico, tortura e homicídio."
   },
   {
    "t": "trânsito, trabalho, terra e honra."
   }
  ],
  "resolucao": "==Gabarito: tortura, tráfico, terrorismo e hediondos, inafiançáveis e insuscetíveis de graça, indulto ou anistia.== Tópico 1 — 3T + H.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, 3T + H"
 },
 {
  "id": "bz12-003",
  "disc": "Direito Constitucional",
  "assunto": "crimes hediondos",
  "enunciado": "Nos crimes hediondos e equiparados, respondem:",
  "alts": [
   {
    "t": "somente os executores."
   },
   {
    "t": "mandantes, executores e os que, podendo evitá-los, se omitirem.",
    "ok": true
   },
   {
    "t": "apenas os mandantes."
   },
   {
    "t": "somente quem tiver antecedentes."
   }
  ],
  "resolucao": "==Gabarito: mandantes, executores e os que, podendo evitá-los, se omitirem.== Tópico 1 — crimes hediondos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, crimes hediondos"
 },
 {
  "id": "bz12-004",
  "disc": "Direito Constitucional",
  "assunto": "inviolabilidade de domicílio",
  "enunciado": "O Art. 5º, XI da CF dispõe que a casa é asilo inviolável, ninguém nela podendo penetrar sem consentimento do morador, salvo:",
  "alts": [
   {
    "t": "somente por mandado, a qualquer hora."
   },
   {
    "t": "apenas em caso de denúncia anônima."
   },
   {
    "t": "flagrante delito, desastre, prestar socorro ou, durante o dia, por determinação judicial.",
    "ok": true
   },
   {
    "t": "a qualquer hora, por ordem de superior hierárquico."
   }
  ],
  "resolucao": "==Gabarito: flagrante delito, desastre, prestar socorro ou, durante o dia, por determinação judicial.== Tópico 2 — inviolabilidade de domicílio.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, inviolabilidade de domicílio"
 },
 {
  "id": "bz12-005",
  "disc": "Direito Constitucional",
  "assunto": "hipóteses constitucionais de entrada",
  "enunciado": "A entrada em domicílio mediante cumprimento de mandado de busca e apreensão só pode ocorrer:",
  "alts": [
   {
    "t": "durante o dia.",
    "ok": true
   },
   {
    "t": "durante a noite."
   },
   {
    "t": "apenas aos domingos."
   },
   {
    "t": "a qualquer hora."
   }
  ],
  "resolucao": "==Gabarito: durante o dia.== Tópico 2 — hipóteses constitucionais de entrada.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, hipóteses constitucionais de entrada"
 },
 {
  "id": "bz12-006",
  "disc": "Direito Constitucional",
  "assunto": "hipóteses constitucionais de entrada",
  "enunciado": "A qualquer momento (dia ou noite), é possível entrar em domicílio nas seguintes hipóteses:",
  "alts": [
   {
    "t": "mandado judicial e denúncia anônima."
   },
   {
    "t": "consentimento do morador, flagrante delito, desastre e prestar socorro.",
    "ok": true
   },
   {
    "t": "intuição do policial e nervosismo do suspeito."
   },
   {
    "t": "apenas mandado de busca e apreensão."
   }
  ],
  "resolucao": "==Gabarito: consentimento do morador, flagrante delito, desastre e prestar socorro.== Tópico 2 — hipóteses constitucionais de entrada.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, hipóteses constitucionais de entrada"
 },
 {
  "id": "bz12-007",
  "disc": "Direito Constitucional",
  "assunto": "diretrizes operacionais do STF",
  "enunciado": "Segundo as diretrizes do STF, o ingresso forçado sem mandado em caso de flagrante exige:",
  "alts": [
   {
    "t": "fundadas razões (justa causa), apoiadas em elementos concretos e anteriores ao ingresso.",
    "ok": true
   },
   {
    "t": "mera intuição subjetiva."
   },
   {
    "t": "apenas o nervosismo do suspeito."
   },
   {
    "t": "denúncia anônima desacompanhada de diligências."
   }
  ],
  "resolucao": "==Gabarito: fundadas razões (justa causa), apoiadas em elementos concretos e anteriores ao ingresso.== Tópico 2 — diretrizes operacionais do STF.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, diretrizes operacionais do STF"
 },
 {
  "id": "bz12-008",
  "disc": "Direito Constitucional",
  "assunto": "o que NÃO autoriza",
  "enunciado": "Não autoriza, por si só, o ingresso em domicílio:",
  "alts": [
   {
    "t": "o consentimento livre do morador."
   },
   {
    "t": "o flagrante delito comprovado."
   },
   {
    "t": "a mera intuição subjetiva, o nervosismo do suspeito, a fuga descontextualizada ou a denúncia anônima desacompanhada de diligências.",
    "ok": true
   },
   {
    "t": "o pedido de socorro."
   }
  ],
  "resolucao": "==Gabarito: a mera intuição subjetiva, o nervosismo do suspeito, a fuga descontextualizada ou a denúncia anônima desacompanhada de diligências.== Tópico 2 — o que NÃO autoriza.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, o que NÃO autoriza"
 },
 {
  "id": "bz12-009",
  "disc": "Direito Constitucional",
  "assunto": "o achado posterior não convalida a ilegalidade",
  "enunciado": "Se a guarnição entrar sem justa causa prévia, a apreensão de drogas ou armas encontradas será:",
  "alts": [
   {
    "t": "considerada prova lícita."
   },
   {
    "t": "convalidada pelo achado posterior."
   },
   {
    "t": "irrelevante para o processo."
   },
   {
    "t": "declarada prova ilícita, gerando a nulidade do processo e a apuração por abuso de autoridade.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: declarada prova ilícita, gerando a nulidade do processo e a apuração por abuso de autoridade.== Tópico 2 — o achado posterior não convalida a ilegalidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, o achado posterior não convalida a ilegalidade"
 },
 {
  "id": "bz12-010",
  "disc": "Direito Constitucional",
  "assunto": "magistrados e MP",
  "enunciado": "Magistrados e membros do MP não podem ser presos senão:",
  "alts": [
   {
    "t": "por ordem do comandante da PM."
   },
   {
    "t": "por ordem escrita do Tribunal competente, ressalvado o flagrante de crime inafiançável.",
    "ok": true
   },
   {
    "t": "por qualquer ordem verbal."
   },
   {
    "t": "por decisão do delegado, sempre."
   }
  ],
  "resolucao": "==Gabarito: por ordem escrita do Tribunal competente, ressalvado o flagrante de crime inafiançável.== Tópico 3.A — magistrados e MP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, magistrados e MP"
 },
 {
  "id": "bz12-011",
  "disc": "Direito Constitucional",
  "assunto": "magistrados e MP",
  "enunciado": "Em flagrante de magistrado, a PM deve fazer:",
  "alts": [
   {
    "t": "liberação imediata do magistrado."
   },
   {
    "t": "comunicação imediata e apresentação ao Presidente do Tribunal.",
    "ok": true
   },
   {
    "t": "apresentação ao prefeito."
   },
   {
    "t": "condução direta à delegacia comum, sem comunicação."
   }
  ],
  "resolucao": "==Gabarito: comunicação imediata e apresentação ao Presidente do Tribunal.== Tópico 3.A — magistrados e MP.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, magistrados e MP"
 },
 {
  "id": "bz12-012",
  "disc": "Direito Constitucional",
  "assunto": "Presidente da República",
  "enunciado": "O Presidente da República é imune, em infrações penais comuns antes de sentença condenatória definitiva, a:",
  "alts": [
   {
    "t": "qualquer prisão cautelar (flagrante, temporária, preventiva).",
    "ok": true
   },
   {
    "t": "somente à prisão temporária."
   },
   {
    "t": "apenas à prisão em flagrante."
   },
   {
    "t": "nenhuma prisão."
   }
  ],
  "resolucao": "==Gabarito: qualquer prisão cautelar (flagrante, temporária, preventiva).== Tópico 3.A — Presidente da República.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Presidente da República"
 },
 {
  "id": "bz12-013",
  "disc": "Direito Constitucional",
  "assunto": "governadores e prefeitos",
  "enunciado": "Governadores de Estado e Prefeitos Municipais:",
  "alts": [
   {
    "t": "não podem ser presos em hipótese alguma."
   },
   {
    "t": "só podem ser presos em flagrante de crime inafiançável."
   },
   {
    "t": "podem ser presos em flagrante e sofrer prisões cautelares; a prerrogativa limita-se ao foro (STJ para Governador; TJ para Prefeito).",
    "ok": true
   },
   {
    "t": "têm a mesma imunidade do Presidente."
   }
  ],
  "resolucao": "==Gabarito: podem ser presos em flagrante e sofrer prisões cautelares; a prerrogativa limita-se ao foro (STJ para Governador; TJ para Prefeito).== Tópico 3.A — governadores e prefeitos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, governadores e prefeitos"
 },
 {
  "id": "bz12-014",
  "disc": "Direito Constitucional",
  "assunto": "vereadores",
  "enunciado": "Os vereadores possuem:",
  "alts": [
   {
    "t": "imunidade formal e material."
   },
   {
    "t": "imunidade processual absoluta."
   },
   {
    "t": "unicamente imunidade material (opiniões, palavras e votos na circunscrição do município e no exercício do mandato).",
    "ok": true
   },
   {
    "t": "imunidade igual à dos senadores."
   }
  ],
  "resolucao": "==Gabarito: unicamente imunidade material (opiniões, palavras e votos na circunscrição do município e no exercício do mandato).== Tópico 3.A — vereadores.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, vereadores"
 },
 {
  "id": "bz12-015",
  "disc": "Direito Constitucional",
  "assunto": "prisão do advogado",
  "enunciado": "A ausência de representante da OAB na lavratura do procedimento de prisão do advogado gera:",
  "alts": [
   {
    "t": "nulidade absoluta da prisão.",
    "ok": true
   },
   {
    "t": "apenas advertência ao advogado."
   },
   {
    "t": "nenhuma consequência."
   },
   {
    "t": "mera irregularidade formal."
   }
  ],
  "resolucao": "==Gabarito: nulidade absoluta da prisão.== Tópico 3.B — prisão do advogado.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, prisão do advogado"
 },
 {
  "id": "bz12-016",
  "disc": "Direito Constitucional",
  "assunto": "militares dos Estados",
  "enunciado": "Quanto às punições disciplinares militares:",
  "alts": [
   {
    "t": "o Judiciário não pode analisar nada."
   },
   {
    "t": "cabe habeas corpus para discutir o mérito."
   },
   {
    "t": "não cabe habeas corpus em relação ao mérito, podendo o Judiciário analisar apenas aspectos de legalidade formal.",
    "ok": true
   },
   {
    "t": "o habeas corpus é obrigatório."
   }
  ],
  "resolucao": "==Gabarito: não cabe habeas corpus em relação ao mérito, podendo o Judiciário analisar apenas aspectos de legalidade formal.== Tópico 4 — militares dos Estados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, militares dos Estados"
 },
 {
  "id": "bz12-017",
  "disc": "Direito Constitucional",
  "assunto": "acumulação de cargos",
  "enunciado": "O militar estadual pode acumular cargos com:",
  "alts": [
   {
    "t": "três cargos de professor."
   },
   {
    "t": "somente cargos eletivos."
   },
   {
    "t": "qualquer cargo público."
   },
   {
    "t": "1 cargo de professor, 1 de profissional de saúde (profissão regulamentada) ou 1 técnico ou científico, havendo compatibilidade de horários.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 1 cargo de professor, 1 de profissional de saúde (profissão regulamentada) ou 1 técnico ou científico, havendo compatibilidade de horários.== Tópico 4 — acumulação de cargos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, acumulação de cargos"
 },
 {
  "id": "bz12-018",
  "disc": "Direito Constitucional",
  "assunto": "acumulação de cargos",
  "enunciado": "Havendo compatibilidade de horários na acumulação de cargos, prevalece sempre:",
  "alts": [
   {
    "t": "o cargo de saúde."
   },
   {
    "t": "o cargo técnico."
   },
   {
    "t": "o cargo de professor."
   },
   {
    "t": "a atividade policial militar.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: a atividade policial militar.== Tópico 4 — acumulação de cargos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, acumulação de cargos"
 },
 {
  "id": "bz12-019",
  "disc": "Direito Constitucional",
  "assunto": "rol taxativo",
  "enunciado": "Integram o rol taxativo do Art. 144 da CF/88 (órgãos de segurança pública):",
  "alts": [
   {
    "t": "somente PM e PC."
   },
   {
    "t": "polícias e guardas municipais."
   },
   {
    "t": "PF, PRF, PFF, polícias civis, polícias militares e corpos de bombeiros militares e polícias penais.",
    "ok": true
   },
   {
    "t": "somente PF e PRF."
   }
  ],
  "resolucao": "==Gabarito: PF, PRF, PFF, polícias civis, polícias militares e corpos de bombeiros militares e polícias penais.== Tópico 5 — rol taxativo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, rol taxativo"
 },
 {
  "id": "bz12-020",
  "disc": "Direito Constitucional",
  "assunto": "competências da PM",
  "enunciado": "A Polícia Militar tem competência constitucional para:",
  "alts": [
   {
    "t": "a polícia judiciária e a investigação de crimes comuns."
   },
   {
    "t": "a segurança de bens municipais apenas."
   },
   {
    "t": "o policiamento ostensivo e a preservação da ordem pública.",
    "ok": true
   },
   {
    "t": "o patrulhamento de rodovias federais, com exclusividade."
   }
  ],
  "resolucao": "==Gabarito: o policiamento ostensivo e a preservação da ordem pública.== Tópico 5 — competências da PM.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, competências da PM"
 },
 {
  "id": "bz12-021",
  "disc": "Direito Constitucional",
  "assunto": "órgãos complementares",
  "enunciado": "As guardas municipais destinam-se à proteção de bens, serviços e instalações municipais, e:",
  "alts": [
   {
    "t": "substituem a PM no policiamento ostensivo."
   },
   {
    "t": "integram o rol taxativo do Art. 144."
   },
   {
    "t": "não integram o rol taxativo das polícias nem têm atribuição de polícia judiciária/investigativa.",
    "ok": true
   },
   {
    "t": "têm atribuição de polícia judiciária."
   }
  ],
  "resolucao": "==Gabarito: não integram o rol taxativo das polícias nem têm atribuição de polícia judiciária/investigativa.== Tópico 5 — órgãos complementares.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, órgãos complementares"
 },
 {
  "id": "bz12-022",
  "disc": "Direito Constitucional",
  "assunto": "Justiça Militar Estadual",
  "enunciado": "O Juiz de Direito Militar (singular) julga:",
  "alts": [
   {
    "t": "crimes militares entre militares."
   },
   {
    "t": "crimes contra o patrimônio militar."
   },
   {
    "t": "homicídio doloso contra civil."
   },
   {
    "t": "crimes militares praticados contra civis e ações judiciais contra atos disciplinares militares.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: crimes militares praticados contra civis e ações judiciais contra atos disciplinares militares.== Tópico 6 — Justiça Militar Estadual.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Justiça Militar Estadual"
 },
 {
  "id": "bz12-023",
  "disc": "Direito Constitucional",
  "assunto": "Justiça Militar Estadual",
  "enunciado": "O Conselho de Justiça (colegiado) julga:",
  "alts": [
   {
    "t": "os crimes militares contra civis."
   },
   {
    "t": "os crimes militares cometidos contra militares, contra a administração militar ou contra o patrimônio sob administração militar.",
    "ok": true
   },
   {
    "t": "os homicídios dolosos contra civis."
   },
   {
    "t": "as ações contra atos disciplinares."
   }
  ],
  "resolucao": "==Gabarito: os crimes militares cometidos contra militares, contra a administração militar ou contra o patrimônio sob administração militar.== Tópico 6 — Justiça Militar Estadual.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Justiça Militar Estadual"
 },
 {
  "id": "bz12-024",
  "disc": "Direito Constitucional",
  "assunto": "homicídio doloso contra civil",
  "enunciado": "O homicídio doloso contra civil, ainda que cometido em serviço ou com arma da corporação, é de competência:",
  "alts": [
   {
    "t": "do Juiz de Direito Militar."
   },
   {
    "t": "da Justiça Militar da União."
   },
   {
    "t": "do Conselho de Justiça."
   },
   {
    "t": "privativa do Tribunal do Júri (Justiça Comum Estadual).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: privativa do Tribunal do Júri (Justiça Comum Estadual).== Tópico 6 — homicídio doloso contra civil.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, homicídio doloso contra civil"
 },
 {
  "id": "bz12-025",
  "disc": "Direito Constitucional",
  "assunto": "risco administrativo",
  "enunciado": "Na teoria do risco administrativo, aplicável aos atos comissivos, a responsabilidade do Estado é:",
  "alts": [
   {
    "t": "inexistente."
   },
   {
    "t": "objetiva, exigindo conduta estatal, dano e nexo causal, e admitindo excludentes.",
    "ok": true
   },
   {
    "t": "subjetiva, exigindo prova de culpa."
   },
   {
    "t": "sem excludentes, em qualquer caso."
   }
  ],
  "resolucao": "==Gabarito: objetiva, exigindo conduta estatal, dano e nexo causal, e admitindo excludentes.== Tópico 7.A — risco administrativo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, risco administrativo"
 },
 {
  "id": "bz12-026",
  "disc": "Direito Constitucional",
  "assunto": "excludentes",
  "enunciado": "São excludentes/atenuantes admitidas no risco administrativo:",
  "alts": [
   {
    "t": "somente o dolo do agente."
   },
   {
    "t": "nenhuma."
   },
   {
    "t": "apenas a culpa do Estado."
   },
   {
    "t": "culpa exclusiva ou concorrente da vítima, caso fortuito e força maior.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: culpa exclusiva ou concorrente da vítima, caso fortuito e força maior.== Tópico 7.A — excludentes.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, excludentes"
 },
 {
  "id": "bz12-027",
  "disc": "Direito Constitucional",
  "assunto": "falta do serviço",
  "enunciado": "Nas omissões do Estado, aplica-se, em regra, a teoria da falta do serviço, com responsabilidade:",
  "alts": [
   {
    "t": "subjetiva, exigindo comprovação de culpa administrativa.",
    "ok": true
   },
   {
    "t": "integral, sem excludentes."
   },
   {
    "t": "objetiva, sem necessidade de culpa."
   },
   {
    "t": "inexistente."
   }
  ],
  "resolucao": "==Gabarito: subjetiva, exigindo comprovação de culpa administrativa.== Tópico 7.B — falta do serviço.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, falta do serviço"
 },
 {
  "id": "bz12-028",
  "disc": "Direito Constitucional",
  "assunto": "risco integral",
  "enunciado": "A teoria do risco integral, em que o Estado é “segurador universal”, aplica-se, por exemplo, a:",
  "alts": [
   {
    "t": "toda omissão do Estado."
   },
   {
    "t": "somente danos ao patrimônio público."
   },
   {
    "t": "danos nucleares, danos ambientais e atos de guerra ou terrorismo contra aeronaves de matrícula brasileira.",
    "ok": true
   },
   {
    "t": "qualquer acidente de trânsito."
   }
  ],
  "resolucao": "==Gabarito: danos nucleares, danos ambientais e atos de guerra ou terrorismo contra aeronaves de matrícula brasileira.== Tópico 7.C — risco integral.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, risco integral"
 },
 {
  "id": "bz12-029",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 1",
  "enunciado": "(Certo ou Errado) Racismo e ação de grupos armados contra a ordem constitucional são imprescritíveis e inafiançáveis.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 1 — R-A."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 1 — R-A.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 1"
 },
 {
  "id": "bz12-030",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O mandado de busca e apreensão pode ser cumprido em domicílio a qualquer hora, inclusive à noite.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2 — determinação judicial: exclusivamente durante o dia."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2 — determinação judicial: exclusivamente durante o dia.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 2"
 },
 {
  "id": "bz12-031",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O nervosismo do suspeito, por si só, autoriza o ingresso forçado em domicílio sem mandado.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2 — o nervosismo NÃO autoriza o ingresso."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2 — o nervosismo NÃO autoriza o ingresso.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 2"
 },
 {
  "id": "bz12-032",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 3.A",
  "enunciado": "(Certo ou Errado) Vereadores possuem imunidade formal e podem ser presos apenas em flagrante de crime inafiançável.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 3.A — vereadores só têm imunidade material e são presos como qualquer cidadão."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 3.A — vereadores só têm imunidade material e são presos como qualquer cidadão.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 3.A"
 },
 {
  "id": "bz12-033",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 3.B",
  "enunciado": "(Certo ou Errado) A inobservância das garantias na prisão de advogado sujeita os policiais militares à responsabilização penal por abuso de autoridade.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3.B — prisão do advogado."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3.B — prisão do advogado.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 3.B"
 },
 {
  "id": "bz12-034",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) As guardas municipais integram o rol taxativo de órgãos de segurança pública do Art. 144 da CF/88.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5 — NÃO integram o rol taxativo."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5 — NÃO integram o rol taxativo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 5"
 },
 {
  "id": "bz12-035",
  "disc": "Direito Constitucional",
  "assunto": "Tópico 7.B",
  "enunciado": "(Certo ou Errado) Na responsabilidade do Estado por omissão, a regra é a responsabilidade objetiva, dispensando a prova de culpa.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 7.B — em regra é subjetiva (falta do serviço)."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 7.B — em regra é subjetiva (falta do serviço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, Tópico 7.B"
 },
 {
  "id": "bz12-036",
  "disc": "Direito Constitucional",
  "assunto": "autoridades com prerrogativas (reforço)",
  "enunciado": "Qual é a regra de prisão de Deputados Federais, Senadores e Deputados Estaduais desde a diplomação?",
  "alts": [
   {
    "t": "somente em flagrante de crime inafiançável, sem prisão preventiva ou temporária.",
    "ok": true
   },
   {
    "t": "somente por ordem escrita do Tribunal competente, ressalvado o flagrante inafiançável."
   },
   {
    "t": "qualquer prisão cautelar, como a de qualquer cidadão."
   },
   {
    "t": "em qualquer flagrante, afiançável ou não, além de prisão temporária."
   }
  ],
  "resolucao": "==Gabarito: somente em flagrante de crime inafiançável, sem prisão preventiva ou temporária.== Tópico 3.A — autoridades com prerrogativas (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, autoridades com prerrogativas (reforço)"
 },
 {
  "id": "bz12-037",
  "disc": "Direito Constitucional",
  "assunto": "competência privativa da União (reforço)",
  "enunciado": "Quem detém a competência privativa para legislar sobre normas gerais de organização, efetivos, material bélico, garantias, inatividades e pensões das PMs e CBMs?",
  "alts": [
   {
    "t": "os Estados, cada qual para a sua corporação."
   },
   {
    "t": "a União.",
    "ok": true
   },
   {
    "t": "os Municípios, por lei municipal."
   },
   {
    "t": "o CETRAN, por resolução."
   }
  ],
  "resolucao": "==Gabarito: a União.== Tópico 4 — competência privativa da União (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, competência privativa da União (reforço)"
 },
 {
  "id": "bz12-038",
  "disc": "Direito Constitucional",
  "assunto": "homicídio culposo contra civil (reforço)",
  "enunciado": "Um PM, em serviço, comete homicídio culposo contra um civil. A competência para julgar o caso é da:",
  "alts": [
   {
    "t": "Justiça Federal, por envolver agente público."
   },
   {
    "t": "Justiça Eleitoral, por ser crime de agente do Estado."
   },
   {
    "t": "Justiça Comum Estadual, por meio do Tribunal do Júri."
   },
   {
    "t": "Justiça Militar Estadual, se praticado em serviço ou situação militar.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: Justiça Militar Estadual, se praticado em serviço ou situação militar.== Tópico 6 — homicídio culposo contra civil (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 12, homicídio culposo contra civil (reforço)"
 }
]);
