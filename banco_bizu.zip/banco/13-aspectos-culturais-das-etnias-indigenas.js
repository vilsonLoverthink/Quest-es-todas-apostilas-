/* Disciplina: Aspectos Culturais das Etnias Indígenas (40 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz13-001",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "povo Terena",
  "enunciado": "O povo Terena pertence ao tronco linguístico:",
  "alts": [
   {
    "t": "Tupi-Guarani."
   },
   {
    "t": "Aruaque.",
    "ok": true
   },
   {
    "t": "Macro-Jê."
   },
   {
    "t": "Karib."
   }
  ],
  "resolucao": "==Gabarito: Aruaque.== Tópico 1 — povo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, povo Terena"
 },
 {
  "id": "bz13-002",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "povo Terena",
  "enunciado": "Os Terena migraram historicamente da região do:",
  "alts": [
   {
    "t": "planalto andino."
   },
   {
    "t": "Chaco boliviano e paraguaio, fixando-se no Pantanal e Cerrado.",
    "ok": true
   },
   {
    "t": "Amazônia ocidental."
   },
   {
    "t": "litoral atlântico."
   }
  ],
  "resolucao": "==Gabarito: Chaco boliviano e paraguaio, fixando-se no Pantanal e Cerrado.== Tópico 1 — povo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, povo Terena"
 },
 {
  "id": "bz13-003",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "povo Terena",
  "enunciado": "Os Terena destacaram-se como povo:",
  "alts": [
   {
    "t": "exclusivamente caçador-coletor."
   },
   {
    "t": "apenas pescador nômade."
   },
   {
    "t": "agricultor, pelo domínio técnico da agricultura.",
    "ok": true
   },
   {
    "t": "pastoril."
   }
  ],
  "resolucao": "==Gabarito: agricultor, pelo domínio técnico da agricultura.== Tópico 1 — povo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, povo Terena"
 },
 {
  "id": "bz13-004",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "governança Terena",
  "enunciado": "Na governança Terena, a figura central é o Cacique, apoiado pelo:",
  "alts": [
   {
    "t": "Conselho de Defesa Nacional."
   },
   {
    "t": "Conselho Tribal/de Aldeia, que assessora, fiscaliza e pode substituir a liderança.",
    "ok": true
   },
   {
    "t": "Conselho de Justiça."
   },
   {
    "t": "Aty Guasu."
   }
  ],
  "resolucao": "==Gabarito: Conselho Tribal/de Aldeia, que assessora, fiscaliza e pode substituir a liderança.== Tópico 1 — governança Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, governança Terena"
 },
 {
  "id": "bz13-005",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "governança Terena",
  "enunciado": "Hoje, a escolha do cacique Terena é feita predominantemente por:",
  "alts": [
   {
    "t": "indicação da FUNAI."
   },
   {
    "t": "eleição formal.",
    "ok": true
   },
   {
    "t": "herança familiar obrigatória."
   },
   {
    "t": "sorteio."
   }
  ],
  "resolucao": "==Gabarito: eleição formal.== Tópico 1 — governança Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, governança Terena"
 },
 {
  "id": "bz13-006",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Guarani e Kaiowá",
  "enunciado": "O termo conjunto “Guarani-Kaiowá” é usado politicamente para unificar lutas, mas:",
  "alts": [
   {
    "t": "são povos com identidades distintas; apenas os Nandeva se autodenominam estritamente Guarani.",
    "ok": true
   },
   {
    "t": "os povos são idênticos em todos os aspectos."
   },
   {
    "t": "designa povos de outro tronco linguístico."
   },
   {
    "t": "refere-se a um único povo sem distinções."
   }
  ],
  "resolucao": "==Gabarito: são povos com identidades distintas; apenas os Nandeva se autodenominam estritamente Guarani.== Tópico 1 — Guarani e Kaiowá.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Guarani e Kaiowá"
 },
 {
  "id": "bz13-007",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tekoha",
  "enunciado": "O conceito de Tekoha designa:",
  "alts": [
   {
    "t": "um ritual de batismo."
   },
   {
    "t": "uma assembleia política."
   },
   {
    "t": "um tipo de grafismo."
   },
   {
    "t": "o lugar físico, ecológico e sagrado onde é possível realizar o modo tradicional de ser e viver.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: o lugar físico, ecológico e sagrado onde é possível realizar o modo tradicional de ser e viver.== Tópico 1 — Tekoha.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tekoha"
 },
 {
  "id": "bz13-008",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Terena x Guarani-Kaiowá",
  "enunciado": "Em relação à organização espacial, a aldeia Terena é:",
  "alts": [
   {
    "t": "seminômade, organizada em torno do Tekoha."
   },
   {
    "t": "restrita à mata fechada."
   },
   {
    "t": "dispersa e sem núcleo comum."
   },
   {
    "t": "semiurbana/sedentária, com núcleo central compartilhado e setores residenciais/roças nas margens.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: semiurbana/sedentária, com núcleo central compartilhado e setores residenciais/roças nas margens.== Tópico 2 — Terena x Guarani-Kaiowá.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Terena x Guarani-Kaiowá"
 },
 {
  "id": "bz13-009",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "quadro comparativo",
  "enunciado": "O espaço sagrado dos Guarani-Kaiowá é:",
  "alts": [
   {
    "t": "a igreja da aldeia, apenas."
   },
   {
    "t": "o campo de futebol."
   },
   {
    "t": "a casa de reza, espaço de culto a Nhanderu.",
    "ok": true
   },
   {
    "t": "o centro comunitário."
   }
  ],
  "resolucao": "==Gabarito: a casa de reza, espaço de culto a Nhanderu.== Tópico 2 — quadro comparativo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, quadro comparativo"
 },
 {
  "id": "bz13-010",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Terena",
  "enunciado": "No grafismo Terena masculino (linhas retas, ângulos e triângulos), o peixe simboliza:",
  "alts": [
   {
    "t": "cura/medicina."
   },
   {
    "t": "coragem."
   },
   {
    "t": "força."
   },
   {
    "t": "fartura e aliança matrimonial.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: fartura e aliança matrimonial.== Tópico 3 — grafismo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Terena"
 },
 {
  "id": "bz13-011",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Terena",
  "enunciado": "No grafismo Terena masculino, a cobra simboliza:",
  "alts": [
   {
    "t": "coragem.",
    "ok": true
   },
   {
    "t": "beleza."
   },
   {
    "t": "força."
   },
   {
    "t": "fartura."
   }
  ],
  "resolucao": "==Gabarito: coragem.== Tópico 3 — grafismo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Terena"
 },
 {
  "id": "bz13-012",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Terena",
  "enunciado": "No grafismo Terena masculino, a tartaruga simboliza:",
  "alts": [
   {
    "t": "fartura."
   },
   {
    "t": "coragem."
   },
   {
    "t": "cura/medicina.",
    "ok": true
   },
   {
    "t": "força."
   }
  ],
  "resolucao": "==Gabarito: cura/medicina.== Tópico 3 — grafismo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Terena"
 },
 {
  "id": "bz13-013",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Terena feminino",
  "enunciado": "No grafismo Terena feminino, o círculo simboliza:",
  "alts": [
   {
    "t": "luta, lamento, luto e retomada política.",
    "ok": true
   },
   {
    "t": "alegria."
   },
   {
    "t": "beleza."
   },
   {
    "t": "fartura."
   }
  ],
  "resolucao": "==Gabarito: luta, lamento, luto e retomada política.== Tópico 3 — grafismo Terena feminino.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Terena feminino"
 },
 {
  "id": "bz13-014",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Terena feminino",
  "enunciado": "No grafismo Terena feminino, a borboleta simboliza:",
  "alts": [
   {
    "t": "coragem."
   },
   {
    "t": "luto."
   },
   {
    "t": "beleza.",
    "ok": true
   },
   {
    "t": "alegria."
   }
  ],
  "resolucao": "==Gabarito: beleza.== Tópico 3 — grafismo Terena feminino.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Terena feminino"
 },
 {
  "id": "bz13-015",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "o que prova o grafismo",
  "enunciado": "Segundo as autoras de referência, o grafismo ameríndio é:",
  "alts": [
   {
    "t": "ornamento sem significado."
   },
   {
    "t": "um código visual e linguagem estruturada, e não mero enfeite decorativo.",
    "ok": true
   },
   {
    "t": "arte primitiva e decorativa."
   },
   {
    "t": "prática abolida."
   }
  ],
  "resolucao": "==Gabarito: um código visual e linguagem estruturada, e não mero enfeite decorativo.== Tópico 3 — o que prova o grafismo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, o que prova o grafismo"
 },
 {
  "id": "bz13-016",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "linguagens",
  "enunciado": "Os cursos de formação bilíngue Ara Vera e Teko Arandu estão ligados aos:",
  "alts": [
   {
    "t": "Guarani e Kaiowá.",
    "ok": true
   },
   {
    "t": "Terena."
   },
   {
    "t": "Kadiwéu."
   },
   {
    "t": "Guató."
   }
  ],
  "resolucao": "==Gabarito: Guarani e Kaiowá.== Tópico 4 — linguagens.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, linguagens"
 },
 {
  "id": "bz13-017",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "cerâmica Terena",
  "enunciado": "A cerâmica Terena é uma tradição milenar:",
  "alts": [
   {
    "t": "industrial."
   },
   {
    "t": "masculina, em argila branca com pintura vermelha."
   },
   {
    "t": "exclusivamente ritual masculina."
   },
   {
    "t": "feminina, de modelagem manual em barro avermelhado com pintura em argila branca.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: feminina, de modelagem manual em barro avermelhado com pintura em argila branca.== Tópico 4 — cerâmica Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, cerâmica Terena"
 },
 {
  "id": "bz13-018",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "agricultura de coivara",
  "enunciado": "A agricultura de coivara é um sistema tradicional:",
  "alts": [
   {
    "t": "de irrigação contínua."
   },
   {
    "t": "de cultivo permanente sem descanso do solo."
   },
   {
    "t": "mecanizado de monocultura."
   },
   {
    "t": "itinerante de corte, secagem, queima controlada fertilizante, cultivo temporário e longo pousio.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: itinerante de corte, secagem, queima controlada fertilizante, cultivo temporário e longo pousio.== Tópico 4 — agricultura de coivara.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, agricultura de coivara"
 },
 {
  "id": "bz13-019",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "armadura espiritual",
  "enunciado": "A Armadura espiritual (Mborai) dos Guarani-Kaiowá é:",
  "alts": [
   {
    "t": "um ritual de colheita."
   },
   {
    "t": "uma vestimenta de metal."
   },
   {
    "t": "a cobertura da pele com grafismos sagrados, urucum e jenipapo, como couraça contra malefícios espirituais e perigos físicos.",
    "ok": true
   },
   {
    "t": "um tipo de arma de caça."
   }
  ],
  "resolucao": "==Gabarito: a cobertura da pele com grafismos sagrados, urucum e jenipapo, como couraça contra malefícios espirituais e perigos físicos.== Tópico 6 — armadura espiritual.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, armadura espiritual"
 },
 {
  "id": "bz13-020",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "proteção Terena",
  "enunciado": "Para os Terena, o preto/carvão de buriti e os grafismos zoomórficos têm o papel de:",
  "alts": [
   {
    "t": "marcar posse de terras."
   },
   {
    "t": "apenas enfeitar."
   },
   {
    "t": "repelir influências negativas da terra e resguardar guerreiros e curandeiros.",
    "ok": true
   },
   {
    "t": "atrair caça."
   }
  ],
  "resolucao": "==Gabarito: repelir influências negativas da terra e resguardar guerreiros e curandeiros.== Tópico 6 — proteção Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, proteção Terena"
 },
 {
  "id": "bz13-021",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Nhanderu",
  "enunciado": "Nhanderu é:",
  "alts": [
   {
    "t": "o criador supremo na cosmovisão Guarani e Kaiowá.",
    "ok": true
   },
   {
    "t": "uma dança masculina."
   },
   {
    "t": "o cacique Terena."
   },
   {
    "t": "o chefe do Conselho de Aldeia."
   }
  ],
  "resolucao": "==Gabarito: o criador supremo na cosmovisão Guarani e Kaiowá.== Tópico 7 — Nhanderu.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Nhanderu"
 },
 {
  "id": "bz13-022",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Nhemongarai",
  "enunciado": "O Nhemongarai é o ritual sagrado de:",
  "alts": [
   {
    "t": "assembleia política."
   },
   {
    "t": "retomada de terra."
   },
   {
    "t": "batismo espiritual e consagração, em que a pessoa recebe seu nome sagrado revelado pelo rezador.",
    "ok": true
   },
   {
    "t": "colheita de mandioca apenas."
   }
  ],
  "resolucao": "==Gabarito: batismo espiritual e consagração, em que a pessoa recebe seu nome sagrado revelado pelo rezador.== Tópico 7 — Nhemongarai.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Nhemongarai"
 },
 {
  "id": "bz13-023",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Dança da Ema",
  "enunciado": "Na Dança da Ema, os dançarinos mimetizam o movimento da ema (kipaé), culminando na:",
  "alts": [
   {
    "t": "assinatura de acordos políticos."
   },
   {
    "t": "partilha de caça."
   },
   {
    "t": "queima de uma réplica da ema."
   },
   {
    "t": "elevação do guerreiro mais corajoso sobre uma rede de bastões entrelaçados.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: elevação do guerreiro mais corajoso sobre uma rede de bastões entrelaçados.== Tópico 8 — Dança da Ema.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Dança da Ema"
 },
 {
  "id": "bz13-024",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Aty Guasu",
  "enunciado": "O Aty Guasu é:",
  "alts": [
   {
    "t": "um ritual de nominação."
   },
   {
    "t": "o conselho político Terena."
   },
   {
    "t": "uma festa agrícola."
   },
   {
    "t": "a grande assembleia geral Guarani e Kaiowá que delibera sobre autodefesa, retomadas e demarcação dos tekoha.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: a grande assembleia geral Guarani e Kaiowá que delibera sobre autodefesa, retomadas e demarcação dos tekoha.== Tópico 9 — Aty Guasu.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Aty Guasu"
 },
 {
  "id": "bz13-025",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Kuñangue Aty Guasu",
  "enunciado": "O Kuñangue Aty Guasu é a instância:",
  "alts": [
   {
    "t": "dos rezadores."
   },
   {
    "t": "dos caciques Terena."
   },
   {
    "t": "das mulheres Kaiowá e Guarani.",
    "ok": true
   },
   {
    "t": "da juventude Terena."
   }
  ],
  "resolucao": "==Gabarito: das mulheres Kaiowá e Guarani.== Tópico 9 — Kuñangue Aty Guasu.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Kuñangue Aty Guasu"
 },
 {
  "id": "bz13-026",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Conselho do Povo Terena",
  "enunciado": "O Conselho do Povo Terena foi rearticulado formalmente em:",
  "alts": [
   {
    "t": "1988, em Campo Grande."
   },
   {
    "t": "2023, em Dourados."
   },
   {
    "t": "2012, na Aldeia Imbirussu (Aquidauana/MS).",
    "ok": true
   },
   {
    "t": "2009, em Raposa Serra do Sol."
   }
  ],
  "resolucao": "==Gabarito: 2012, na Aldeia Imbirussu (Aquidauana/MS).== Tópico 9 — Conselho do Povo Terena.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Conselho do Povo Terena"
 },
 {
  "id": "bz13-027",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "tensões e fatores de conflito",
  "enunciado": "O confinamento de cerca de 15 mil habitantes em aproximadamente 3.474 hectares inviabilizou:",
  "alts": [
   {
    "t": "a produção agrícola tradicional de subsistência e a dispersão geográfica familiar.",
    "ok": true
   },
   {
    "t": "a criação de conselhos."
   },
   {
    "t": "o comércio urbano."
   },
   {
    "t": "a atuação da Funai."
   }
  ],
  "resolucao": "==Gabarito: a produção agrícola tradicional de subsistência e a dispersão geográfica familiar.== Tópico 10 — tensões e fatores de conflito.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, tensões e fatores de conflito"
 },
 {
  "id": "bz13-028",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "fases do processo demarcatório",
  "enunciado": "A primeira fase do ciclo demarcatório (E3DHR) é a de:",
  "alts": [
   {
    "t": "Estudo, com levantamento antropológico e ambiental.",
    "ok": true
   },
   {
    "t": "Registro em cartório."
   },
   {
    "t": "Declaração, por portaria do Ministério da Justiça."
   },
   {
    "t": "Homologação, por decreto presidencial."
   }
  ],
  "resolucao": "==Gabarito: Estudo, com levantamento antropológico e ambiental.== Tópico 11 — fases do processo demarcatório.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, fases do processo demarcatório"
 },
 {
  "id": "bz13-029",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "fases do processo demarcatório",
  "enunciado": "Na fase “Declarada”, o ato é:",
  "alts": [
   {
    "t": "decreto do Presidente da República."
   },
   {
    "t": "portaria expedida pelo Ministério da Justiça.",
    "ok": true
   },
   {
    "t": "registro na SPU."
   },
   {
    "t": "parecer da FUNAI."
   }
  ],
  "resolucao": "==Gabarito: portaria expedida pelo Ministério da Justiça.== Tópico 11 — fases do processo demarcatório.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, fases do processo demarcatório"
 },
 {
  "id": "bz13-030",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "fases do processo demarcatório",
  "enunciado": "A homologação da terra indígena é feita por:",
  "alts": [
   {
    "t": "portaria da FUNAI."
   },
   {
    "t": "decreto assinado pelo Presidente da República.",
    "ok": true
   },
   {
    "t": "ato do INCRA."
   },
   {
    "t": "decisão do Governador."
   }
  ],
  "resolucao": "==Gabarito: decreto assinado pelo Presidente da República.== Tópico 11 — fases do processo demarcatório.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, fases do processo demarcatório"
 },
 {
  "id": "bz13-031",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "fases do processo demarcatório",
  "enunciado": "O registro em cartório de imóveis e na Secretaria de Patrimônio da União (SPU) corresponde à fase:",
  "alts": [
   {
    "t": "Demarcada."
   },
   {
    "t": "Declarada."
   },
   {
    "t": "Registrada/Regularizada.",
    "ok": true
   },
   {
    "t": "Delimitada."
   }
  ],
  "resolucao": "==Gabarito: Registrada/Regularizada.== Tópico 11 — fases do processo demarcatório.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, fases do processo demarcatório"
 },
 {
  "id": "bz13-032",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "origem da tese",
  "enunciado": "A tese do marco temporal surgiu em 2009, no julgamento da:",
  "alts": [
   {
    "t": "Terra Indígena Taunay."
   },
   {
    "t": "Terra Indígena Buriti."
   },
   {
    "t": "Terra Indígena Raposa Serra do Sol (STF).",
    "ok": true
   },
   {
    "t": "Terra Indígena Guyraroká."
   }
  ],
  "resolucao": "==Gabarito: Terra Indígena Raposa Serra do Sol (STF).== Tópico 12 — origem da tese.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, origem da tese"
 },
 {
  "id": "bz13-033",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "tese do indigenato",
  "enunciado": "Segundo a tese do indigenato (Art. 231 da CF/88), formulada por João Mendes Júnior, o direito territorial indígena é:",
  "alts": [
   {
    "t": "originário e congênito, anterior ao Estado brasileiro; a demarcação é ato declaratório.",
    "ok": true
   },
   {
    "t": "dependente de ocupação em 1988."
   },
   {
    "t": "concedido por lei federal."
   },
   {
    "t": "criado pela demarcação, que é constitutiva."
   }
  ],
  "resolucao": "==Gabarito: originário e congênito, anterior ao Estado brasileiro; a demarcação é ato declaratório.== Tópico 12 — tese do indigenato.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, tese do indigenato"
 },
 {
  "id": "bz13-034",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) Os Terena e os Guarani-Kaiowá pertencem ao mesmo tronco linguístico.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 2 — Terena: Aruaque; Guarani-Kaiowá: Tupi-Guarani."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 2 — Terena: Aruaque; Guarani-Kaiowá: Tupi-Guarani.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 2"
 },
 {
  "id": "bz13-035",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) A Dança da Ema é de caráter estritamente masculino.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 8 — Dança da Ema."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 8 — Dança da Ema.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 8"
 },
 {
  "id": "bz13-036",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) A demarcação de terras indígenas é um ato constitutivo de direito, segundo a tese do indigenato.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 12 — o ato de demarcar é puramente declaratório."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 12 — o ato de demarcar é puramente declaratório.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 12"
 },
 {
  "id": "bz13-037",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) As igrejas pentecostais e missões protestantes podem funcionar tanto como rede de apoio familiar quanto como fator de novos atritos com a religiosidade tradicional.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 10 — influência religiosa."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 10 — influência religiosa.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 10"
 },
 {
  "id": "bz13-038",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) A fase “Delimitada” do processo demarcatório é concluída por decreto do Presidente da República.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 11 — a Delimitada envolve parecer/relatório aprovados pela FUNAI; o decreto presidencial é a Homologação."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 11 — a Delimitada envolve parecer/relatório aprovados pela FUNAI; o decreto presidencial é a Homologação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 11"
 },
 {
  "id": "bz13-039",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "grafismo Guarani-Kaiowá (reforço)",
  "enunciado": "No grafismo Guarani-Kaiowá, o urucum e o jenipapo comunicam, respectivamente:",
  "alts": [
   {
    "t": "fixação/proteção e vida/energia."
   },
   {
    "t": "vida/energia e fixação/proteção.",
    "ok": true
   },
   {
    "t": "luto/retomada e alegria/beleza."
   },
   {
    "t": "fartura/aliança e coragem/força."
   }
  ],
  "resolucao": "==Gabarito: vida/energia e fixação/proteção.== Tópico 3 — grafismo Guarani-Kaiowá (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, grafismo Guarani-Kaiowá (reforço)"
 },
 {
  "id": "bz13-040",
  "disc": "Aspectos Culturais das Etnias Indígenas",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) Mesmo após a Lei nº 14.701/2023 (Lei do Marco Temporal), o STF declarou inconstitucional a data de corte de 5 de outubro de 1988 e fixou prazo de 10 anos para concluir as demarcações pendentes.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 12 — Lei nº 14.701/2023 (reforço)."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 12 — Lei nº 14.701/2023 (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 13, Tópico 12"
 }
]);
