/* Disciplina: Direitos Humanos (24 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz14-001",
  "disc": "Direitos Humanos",
  "assunto": "conceito e natureza",
  "enunciado": "Os direitos humanos são, quanto à natureza:",
  "alts": [
   {
    "t": "restritos a cidadãos de um Estado."
   },
   {
    "t": "exclusivos de cada país."
   },
   {
    "t": "concedidos pelo governo."
   },
   {
    "t": "supranacionais e universais, tendo como núcleo central a dignidade da pessoa humana.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: supranacionais e universais, tendo como núcleo central a dignidade da pessoa humana.== Tópico 1.1 — conceito e natureza.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, conceito e natureza"
 },
 {
  "id": "bz14-002",
  "disc": "Direitos Humanos",
  "assunto": "finalidade",
  "enunciado": "A finalidade primordial dos direitos humanos é:",
  "alts": [
   {
    "t": "proteger apenas criminosos."
   },
   {
    "t": "limitar a atuação policial."
   },
   {
    "t": "proteger o indivíduo contra o arbítrio e os excessos do Estado.",
    "ok": true
   },
   {
    "t": "substituir a Constituição."
   }
  ],
  "resolucao": "==Gabarito: proteger o indivíduo contra o arbítrio e os excessos do Estado.== Tópico 1.1 — finalidade.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, finalidade"
 },
 {
  "id": "bz14-003",
  "disc": "Direitos Humanos",
  "assunto": "distinção terminológica",
  "enunciado": "Os direitos fundamentais são aqueles:",
  "alts": [
   {
    "t": "positivados na ordem constitucional interna de cada país.",
    "ok": true
   },
   {
    "t": "positivados em tratados internacionais."
   },
   {
    "t": "naturais, independentes de positivação."
   },
   {
    "t": "criados pela ONU."
   }
  ],
  "resolucao": "==Gabarito: positivados na ordem constitucional interna de cada país.== Tópico 1.2 — distinção terminológica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, distinção terminológica"
 },
 {
  "id": "bz14-004",
  "disc": "Direitos Humanos",
  "assunto": "distinção terminológica",
  "enunciado": "Os direitos humanos propriamente ditos são positivados:",
  "alts": [
   {
    "t": "na ordem constitucional de cada país."
   },
   {
    "t": "em decretos estaduais."
   },
   {
    "t": "na ordem jurídica internacional (tratados, pactos e declarações).",
    "ok": true
   },
   {
    "t": "apenas em leis municipais."
   }
  ],
  "resolucao": "==Gabarito: na ordem jurídica internacional (tratados, pactos e declarações).== Tópico 1.2 — distinção terminológica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, distinção terminológica"
 },
 {
  "id": "bz14-005",
  "disc": "Direitos Humanos",
  "assunto": "funções fundamentais",
  "enunciado": "A função de defesa e liberdade frente ao Estado corresponde ao dever de:",
  "alts": [
   {
    "t": "promoção da igualdade material."
   },
   {
    "t": "abstenção/não ingerência estatal.",
    "ok": true
   },
   {
    "t": "prestação social."
   },
   {
    "t": "proteção perante terceiros."
   }
  ],
  "resolucao": "==Gabarito: abstenção/não ingerência estatal.== Tópico 1.3 — funções fundamentais.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, funções fundamentais"
 },
 {
  "id": "bz14-006",
  "disc": "Direitos Humanos",
  "assunto": "mitos e verdades",
  "enunciado": "Quanto aos “mitos e verdades”, a apostila esclarece que os direitos humanos:",
  "alts": [
   {
    "t": "impedem qualquer atuação policial."
   },
   {
    "t": "servem apenas a presos."
   },
   {
    "t": "não foram criados para proteger criminosos, mas para assegurar garantias processuais mínimas e coibir abusos estatais contra qualquer indivíduo.",
    "ok": true
   },
   {
    "t": "protegem exclusivamente criminosos."
   }
  ],
  "resolucao": "==Gabarito: não foram criados para proteger criminosos, mas para assegurar garantias processuais mínimas e coibir abusos estatais contra qualquer indivíduo.== Tópico 1.4 — mitos e verdades.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, mitos e verdades"
 },
 {
  "id": "bz14-007",
  "disc": "Direitos Humanos",
  "assunto": "esquema sinóptico",
  "enunciado": "Na 1ª dimensão dos direitos humanos, o valor central é a:",
  "alts": [
   {
    "t": "liberdade (direitos civis e políticos), com postura negativa do Estado.",
    "ok": true
   },
   {
    "t": "paz, com segurança global."
   },
   {
    "t": "igualdade material, com postura positiva."
   },
   {
    "t": "fraternidade, com postura cooperativa."
   }
  ],
  "resolucao": "==Gabarito: liberdade (direitos civis e políticos), com postura negativa do Estado.== Tópico 2 — esquema sinóptico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, esquema sinóptico"
 },
 {
  "id": "bz14-008",
  "disc": "Direitos Humanos",
  "assunto": "esquema sinóptico",
  "enunciado": "A 3ª dimensão (fraternidade/solidariedade) abrange direitos:",
  "alts": [
   {
    "t": "difusos e coletivos (meio ambiente, desenvolvimento, autodeterminação dos povos), com postura cooperativa.",
    "ok": true
   },
   {
    "t": "de paz, apenas."
   },
   {
    "t": "econômicos e sociais."
   },
   {
    "t": "civis e políticos."
   }
  ],
  "resolucao": "==Gabarito: difusos e coletivos (meio ambiente, desenvolvimento, autodeterminação dos povos), com postura cooperativa.== Tópico 2 — esquema sinóptico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, esquema sinóptico"
 },
 {
  "id": "bz14-009",
  "disc": "Direitos Humanos",
  "assunto": "esquema sinóptico",
  "enunciado": "O valor central da 4ª dimensão é:",
  "alts": [
   {
    "t": "igualdade formal."
   },
   {
    "t": "liberdade."
   },
   {
    "t": "paz."
   },
   {
    "t": "biotecnologia/democracia (patrimônio genético, informação e pluralismo).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: biotecnologia/democracia (patrimônio genético, informação e pluralismo).== Tópico 2 — esquema sinóptico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, esquema sinóptico"
 },
 {
  "id": "bz14-010",
  "disc": "Direitos Humanos",
  "assunto": "sistema global",
  "enunciado": "O sistema global (ONU) fundamenta-se na:",
  "alts": [
   {
    "t": "Carta da ONU (1945) e na Carta Internacional de Direitos Humanos.",
    "ok": true
   },
   {
    "t": "Carta da OEA."
   },
   {
    "t": "Convenção Americana."
   },
   {
    "t": "Constituição do Império."
   }
  ],
  "resolucao": "==Gabarito: Carta da ONU (1945) e na Carta Internacional de Direitos Humanos.== Tópico 3.1 — sistema global.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, sistema global"
 },
 {
  "id": "bz14-011",
  "disc": "Direitos Humanos",
  "assunto": "sistema global",
  "enunciado": "Compõem a Carta Internacional de Direitos Humanos:",
  "alts": [
   {
    "t": "o CCFRAL e o PBUFAF."
   },
   {
    "t": "DUDH, PIDCP e PIDESC.",
    "ok": true
   },
   {
    "t": "somente a Carta da OEA."
   },
   {
    "t": "apenas o Pacto de San José."
   }
  ],
  "resolucao": "==Gabarito: DUDH, PIDCP e PIDESC.== Tópico 3.1 — sistema global.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, sistema global"
 },
 {
  "id": "bz14-012",
  "disc": "Direitos Humanos",
  "assunto": "sistema regional",
  "enunciado": "O sistema interamericano (OEA) tem como base normativa:",
  "alts": [
   {
    "t": "a Declaração Universal."
   },
   {
    "t": "a Carta da ONU."
   },
   {
    "t": "o Pacto de San José da Costa Rica (1969).",
    "ok": true
   },
   {
    "t": "o PIDCP."
   }
  ],
  "resolucao": "==Gabarito: o Pacto de San José da Costa Rica (1969).== Tópico 3.2 — sistema regional.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, sistema regional"
 },
 {
  "id": "bz14-013",
  "disc": "Direitos Humanos",
  "assunto": "princípio de atuação",
  "enunciado": "A atuação do sistema interamericano é:",
  "alts": [
   {
    "t": "obrigatória antes de qualquer processo interno."
   },
   {
    "t": "subsidiária e complementar à jurisdição interna, exigindo-se em regra o esgotamento dos recursos internos.",
    "ok": true
   },
   {
    "t": "principal, dispensando a jurisdição interna."
   },
   {
    "t": "restrita a crimes militares."
   }
  ],
  "resolucao": "==Gabarito: subsidiária e complementar à jurisdição interna, exigindo-se em regra o esgotamento dos recursos internos.== Tópico 3.2 — princípio de atuação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, princípio de atuação"
 },
 {
  "id": "bz14-014",
  "disc": "Direitos Humanos",
  "assunto": "hierarquia dos tratados",
  "enunciado": "Os tratados de direitos humanos aprovados pelo rito ordinário possuem status:",
  "alts": [
   {
    "t": "supralegal (abaixo da Constituição e acima das leis ordinárias).",
    "ok": true
   },
   {
    "t": "de decreto."
   },
   {
    "t": "de lei ordinária."
   },
   {
    "t": "de emenda constitucional."
   }
  ],
  "resolucao": "==Gabarito: supralegal (abaixo da Constituição e acima das leis ordinárias).== Tópico 4.2 — hierarquia dos tratados.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, hierarquia dos tratados"
 },
 {
  "id": "bz14-015",
  "disc": "Direitos Humanos",
  "assunto": "aplicações práticas",
  "enunciado": "Entre as aplicações práticas dos direitos humanos na atividade policial, estão:",
  "alts": [
   {
    "t": "dispensa do tratamento digno ao preso."
   },
   {
    "t": "ingresso livre em domicílios."
   },
   {
    "t": "uso irrestrito da força e prova a qualquer custo."
   },
   {
    "t": "uso da força balizado, inviolabilidade de domicílio, vedação a provas ilícitas e humanização no tratamento de custodiados.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: uso da força balizado, inviolabilidade de domicílio, vedação a provas ilícitas e humanização no tratamento de custodiados.== Tópico 4.3 — aplicações práticas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, aplicações práticas"
 },
 {
  "id": "bz14-016",
  "disc": "Direitos Humanos",
  "assunto": "CCFRAL",
  "enunciado": "O CCFRAL (ONU, 1979) é:",
  "alts": [
   {
    "t": "o Código de Conduta para os Funcionários Responsáveis pela Aplicação da Lei.",
    "ok": true
   },
   {
    "t": "um pacto sobre direitos econômicos."
   },
   {
    "t": "um protocolo de APH."
   },
   {
    "t": "um tratado sobre armas de fogo."
   }
  ],
  "resolucao": "==Gabarito: o Código de Conduta para os Funcionários Responsáveis pela Aplicação da Lei.== Tópico 5 — CCFRAL.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, CCFRAL"
 },
 {
  "id": "bz14-017",
  "disc": "Direitos Humanos",
  "assunto": "PBUFAF",
  "enunciado": "O PBUFAF (ONU, 1990) submete o uso da força e de armas de fogo à:",
  "alts": [
   {
    "t": "conveniência política."
   },
   {
    "t": "discricionariedade do policial."
   },
   {
    "t": "vontade do suspeito."
   },
   {
    "t": "legalidade, necessidade, proporcionalidade e moderação.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: legalidade, necessidade, proporcionalidade e moderação.== Tópico 6 — PBUFAF.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, PBUFAF"
 },
 {
  "id": "bz14-018",
  "disc": "Direitos Humanos",
  "assunto": "PBUFAF",
  "enunciado": "O emprego de métodos não violentos e a verbalização, segundo o PBUFAF:",
  "alts": [
   {
    "t": "devem sempre preceder o uso da força.",
    "ok": true
   },
   {
    "t": "só são usados após o uso da força."
   },
   {
    "t": "são dispensáveis."
   },
   {
    "t": "são proibidos."
   }
  ],
  "resolucao": "==Gabarito: devem sempre preceder o uso da força.== Tópico 6 — PBUFAF.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, PBUFAF"
 },
 {
  "id": "bz14-019",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 1.4",
  "enunciado": "(Certo ou Errado) Os direitos humanos foram criados com a finalidade exclusiva de proteger criminosos.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 1.4 — mito: visam coibir abusos e assegurar garantias mínimas a qualquer indivíduo."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 1.4 — mito: visam coibir abusos e assegurar garantias mínimas a qualquer indivíduo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 1.4"
 },
 {
  "id": "bz14-020",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) A 1ª dimensão dos direitos humanos exige do Estado uma postura negativa (abstenção).",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — esquema sinóptico."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — esquema sinóptico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 2"
 },
 {
  "id": "bz14-021",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 3.2",
  "enunciado": "(Certo ou Errado) O sistema interamericano atua de forma subsidiária e complementar à jurisdição interna dos países.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 3.2 — princípio de atuação."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 3.2 — princípio de atuação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 3.2"
 },
 {
  "id": "bz14-022",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 4.2",
  "enunciado": "(Certo ou Errado) Os tratados de direitos humanos aprovados pelo rito ordinário têm status de emenda constitucional.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 4.2 — o rito ordinário confere status supralegal; o rito especial (art. 5º, § 3º) é que equivale a emenda."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 4.2 — o rito ordinário confere status supralegal; o rito especial (art. 5º, § 3º) é que equivale a emenda.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 4.2"
 },
 {
  "id": "bz14-023",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 5",
  "enunciado": "(Certo ou Errado) Segundo o CCFRAL, há dever de denunciar irregularidades funcionais sem sofrer retaliações.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5 — CCFRAL."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5 — CCFRAL.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 5"
 },
 {
  "id": "bz14-024",
  "disc": "Direitos Humanos",
  "assunto": "Tópico 6",
  "enunciado": "(Certo ou Errado) Pelo PBUFAF, a arma de fogo pode ser usada como primeiro recurso em qualquer abordagem.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 6 — é medida extrema e excepcionalíssima; a verbalização e métodos não violentos precedem."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 6 — é medida extrema e excepcionalíssima; a verbalização e métodos não violentos precedem.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 14, Tópico 6"
 }
]);
