/* Disciplina: Atendimento à Pessoa com TEA (27 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz15-001",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "definição de emergência psiquiátrica",
  "enunciado": "A emergência psiquiátrica é a situação de crise em que ocorre:",
  "alts": [
   {
    "t": "uma infração de trânsito."
   },
   {
    "t": "apenas um quadro leve de ansiedade."
   },
   {
    "t": "prejuízo grave do funcionamento geral da mente, com o paciente incapaz de assumir responsabilidades sobre si e/ou outros.",
    "ok": true
   },
   {
    "t": "um problema exclusivamente físico."
   }
  ],
  "resolucao": "==Gabarito: prejuízo grave do funcionamento geral da mente, com o paciente incapaz de assumir responsabilidades sobre si e/ou outros.== Tópico 1 — definição de emergência psiquiátrica.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, definição de emergência psiquiátrica"
 },
 {
  "id": "bz15-002",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "luta ou fuga",
  "enunciado": "A reação de “luta ou fuga” ocorre em 3 etapas. Na primeira:",
  "alts": [
   {
    "t": "o estresse leva sinais do sistema nervoso simpático à glândula adrenal.",
    "ok": true
   },
   {
    "t": "o cérebro desliga o sistema nervoso."
   },
   {
    "t": "a adrenal libera catecolaminas no sangue."
   },
   {
    "t": "a reação produz efeitos em várias partes do corpo."
   }
  ],
  "resolucao": "==Gabarito: o estresse leva sinais do sistema nervoso simpático à glândula adrenal.== Tópico 2 — luta ou fuga.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, luta ou fuga"
 },
 {
  "id": "bz15-003",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "causas e diagnóstico",
  "enunciado": "Sobre as causas do autismo, a apostila afirma que:",
  "alts": [
   {
    "t": "não possuem causas totalmente conhecidas.",
    "ok": true
   },
   {
    "t": "são totalmente conhecidas e únicas."
   },
   {
    "t": "decorrem de má educação."
   },
   {
    "t": "decorrem sempre de trauma."
   }
  ],
  "resolucao": "==Gabarito: não possuem causas totalmente conhecidas.== Tópico 3 — causas e diagnóstico.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, causas e diagnóstico"
 },
 {
  "id": "bz15-004",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "situação e contexto",
  "enunciado": "Segundo o IBGE, a estimativa de pessoas com TEA no Brasil é de:",
  "alts": [
   {
    "t": "24 milhões."
   },
   {
    "t": "240 mil."
   },
   {
    "t": "2,4 milhões.",
    "ok": true
   },
   {
    "t": "500 mil."
   }
  ],
  "resolucao": "==Gabarito: 2,4 milhões.== Tópico 4 — situação e contexto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, situação e contexto"
 },
 {
  "id": "bz15-005",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "situação e contexto",
  "enunciado": "O TEA ocorre:",
  "alts": [
   {
    "t": "de 4 a 5 vezes mais em meninos.",
    "ok": true
   },
   {
    "t": "de 4 a 5 vezes mais em meninas."
   },
   {
    "t": "igualmente em meninos e meninas."
   },
   {
    "t": "somente em adultos."
   }
  ],
  "resolucao": "==Gabarito: de 4 a 5 vezes mais em meninos.== Tópico 4 — situação e contexto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, situação e contexto"
 },
 {
  "id": "bz15-006",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "características (OPAS)",
  "enunciado": "Segundo a OPAS, é característica da pessoa com TEA:",
  "alts": [
   {
    "t": "facilidade em mudar de rotina."
   },
   {
    "t": "ausência de qualquer padrão repetitivo."
   },
   {
    "t": "dificuldade na transição de uma atividade para outra e foco em detalhes.",
    "ok": true
   },
   {
    "t": "preferência por lugares barulhentos, sempre."
   }
  ],
  "resolucao": "==Gabarito: dificuldade na transição de uma atividade para outra e foco em detalhes.== Tópico 5 — características (OPAS).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, características (OPAS)"
 },
 {
  "id": "bz15-007",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "níveis de autismo",
  "enunciado": "O nível 1 de autismo necessita de:",
  "alts": [
   {
    "t": "suporte intermediário."
   },
   {
    "t": "maior suporte."
   },
   {
    "t": "pouco suporte.",
    "ok": true
   },
   {
    "t": "internação."
   }
  ],
  "resolucao": "==Gabarito: pouco suporte.== Tópico 6 — níveis de autismo.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, níveis de autismo"
 },
 {
  "id": "bz15-008",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "símbolos de identificação",
  "enunciado": "O Cordão de Girassol identifica:",
  "alts": [
   {
    "t": "doenças ocultas em geral.",
    "ok": true
   },
   {
    "t": "exclusivamente o autismo."
   },
   {
    "t": "somente deficiência visual."
   },
   {
    "t": "apenas deficiência física."
   }
  ],
  "resolucao": "==Gabarito: doenças ocultas em geral.== Tópico 7 — símbolos de identificação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, símbolos de identificação"
 },
 {
  "id": "bz15-009",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "rainha das alternativas táticas",
  "enunciado": "A primeira intervenção, “A Rainha das Alternativas Táticas”, é composta por:",
  "alts": [
   {
    "t": "5 passos."
   },
   {
    "t": "3 passos."
   },
   {
    "t": "12 passos."
   },
   {
    "t": "9 passos do diagrama tático.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 9 passos do diagrama tático.== Tópico 8 — rainha das alternativas táticas.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, rainha das alternativas táticas"
 },
 {
  "id": "bz15-010",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "passos do diagrama tático",
  "enunciado": "O quarto passo do diagrama tático é:",
  "alts": [
   {
    "t": "coletar informações."
   },
   {
    "t": "estabelecer contato sem concessões.",
    "ok": true
   },
   {
    "t": "solicitar apoio de área."
   },
   {
    "t": "diminuir o estresse."
   }
  ],
  "resolucao": "==Gabarito: estabelecer contato sem concessões.== Tópico 8 — passos do diagrama tático.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, passos do diagrama tático"
 },
 {
  "id": "bz15-011",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "dicas no atendimento",
  "enunciado": "Entre as dicas no atendimento está:",
  "alts": [
   {
    "t": "usar frases longas e complexas."
   },
   {
    "t": "tocar a pessoa sem aviso."
   },
   {
    "t": "gritar para que a pessoa entenda."
   },
   {
    "t": "falar pausadamente, usar frases curtas, nunca gritar e usar estímulos visuais.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: falar pausadamente, usar frases curtas, nunca gritar e usar estímulos visuais.== Tópico 9 — dicas no atendimento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, dicas no atendimento"
 },
 {
  "id": "bz15-012",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "dicas no atendimento",
  "enunciado": "Na abordagem a pessoa com TEA, é recomendado:",
  "alts": [
   {
    "t": "formar círculo de policiais ao redor da pessoa."
   },
   {
    "t": "aproximar-se rapidamente, tocando-a."
   },
   {
    "t": "repreender movimentos de autoestimulação."
   },
   {
    "t": "manter distância física para não ser invasivo e evitar acúmulo de pessoas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: manter distância física para não ser invasivo e evitar acúmulo de pessoas.== Tópico 9 — dicas no atendimento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, dicas no atendimento"
 },
 {
  "id": "bz15-013",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "dicas no atendimento",
  "enunciado": "As Pranchas de Comunicação para Emergências (Comunic@TEA / CAA) são usadas para indicar:",
  "alts": [
   {
    "t": "apenas o endereço da vítima."
   },
   {
    "t": "dados bancários."
   },
   {
    "t": "sintomas, local da dor, sim/não e alfabeto/números.",
    "ok": true
   },
   {
    "t": "dados do veículo."
   }
  ],
  "resolucao": "==Gabarito: sintomas, local da dor, sim/não e alfabeto/números.== Tópico 9 — dicas no atendimento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, dicas no atendimento"
 },
 {
  "id": "bz15-014",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "cuidados gerais e APH",
  "enunciado": "Durante o momento de estresse da pessoa com TEA, pode ocorrer:",
  "alts": [
   {
    "t": "ausência de qualquer reação."
   },
   {
    "t": "crise convulsiva.",
    "ok": true
   },
   {
    "t": "aumento da cooperação."
   },
   {
    "t": "melhora imediata da comunicação."
   }
  ],
  "resolucao": "==Gabarito: crise convulsiva.== Tópico 10 — cuidados gerais e APH.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, cuidados gerais e APH"
 },
 {
  "id": "bz15-015",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "cuidados gerais e APH",
  "enunciado": "Em caso de severa agitação, deve-se acionar:",
  "alts": [
   {
    "t": "nenhum serviço."
   },
   {
    "t": "somente a imprensa."
   },
   {
    "t": "suporte médico imediato e a rede de atendimento (SAMU, Bombeiros, Assistência Social).",
    "ok": true
   },
   {
    "t": "apenas a Guarda Municipal."
   }
  ],
  "resolucao": "==Gabarito: suporte médico imediato e a rede de atendimento (SAMU, Bombeiros, Assistência Social).== Tópico 10 — cuidados gerais e APH.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, cuidados gerais e APH"
 },
 {
  "id": "bz15-016",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "cuidados extras",
  "enunciado": "Quanto à compreensão, as pessoas com TEA entendem as coisas de forma:",
  "alts": [
   {
    "t": "muito direta e objetiva; sinais não verbais como “piscadinhas” podem não ser óbvios.",
    "ok": true
   },
   {
    "t": "somente por gestos sutis."
   },
   {
    "t": "igual à população geral."
   },
   {
    "t": "figurada e irônica."
   }
  ],
  "resolucao": "==Gabarito: muito direta e objetiva; sinais não verbais como “piscadinhas” podem não ser óbvios.== Tópico 10 — cuidados extras.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, cuidados extras"
 },
 {
  "id": "bz15-017",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "contenção em crise agressiva",
  "enunciado": "Os tipos de contenção em crise agressiva são:",
  "alts": [
   {
    "t": "verbal, escrita e visual."
   },
   {
    "t": "química, mecânica e física.",
    "ok": true
   },
   {
    "t": "elétrica, térmica e sonora."
   },
   {
    "t": "militar, civil e comunitária."
   }
  ],
  "resolucao": "==Gabarito: química, mecânica e física.== Tópico 11 — contenção em crise agressiva.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, contenção em crise agressiva"
 },
 {
  "id": "bz15-018",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "fatores de risco",
  "enunciado": "É fator de risco no atendimento:",
  "alts": [
   {
    "t": "equipe numerosa e treinada."
   },
   {
    "t": "equipe com menos de 5 membros, ausência de protocolos e falta de treinamento.",
    "ok": true
   },
   {
    "t": "protocolos bem definidos."
   },
   {
    "t": "uso moderado da força."
   }
  ],
  "resolucao": "==Gabarito: equipe com menos de 5 membros, ausência de protocolos e falta de treinamento.== Tópico 11 — fatores de risco.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, fatores de risco"
 },
 {
  "id": "bz15-019",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "meltdown x shutdown",
  "enunciado": "O shutdown (desligamento) caracteriza-se por:",
  "alts": [
   {
    "t": "excesso de comunicação verbal."
   },
   {
    "t": "crise interna, com retirada/dissociação, isolamento, paralisia e ausência de comunicação.",
    "ok": true
   },
   {
    "t": "comportamento hiperativo."
   },
   {
    "t": "crise explosiva e agressiva."
   }
  ],
  "resolucao": "==Gabarito: crise interna, com retirada/dissociação, isolamento, paralisia e ausência de comunicação.== Tópico 12 — meltdown x shutdown.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, meltdown x shutdown"
 },
 {
  "id": "bz15-020",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "prevenção e gerenciamento",
  "enunciado": "A prevenção e o gerenciamento da crise incluem:",
  "alts": [
   {
    "t": "aumentar a estimulação sensorial."
   },
   {
    "t": "evitar o uso de suportes visuais."
   },
   {
    "t": "identificar gatilhos, manter rotina estruturada, reduzir estimulação sensorial e oferecer suportes visuais.",
    "ok": true
   },
   {
    "t": "mudar a rotina frequentemente."
   }
  ],
  "resolucao": "==Gabarito: identificar gatilhos, manter rotina estruturada, reduzir estimulação sensorial e oferecer suportes visuais.== Tópico 13 — prevenção e gerenciamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, prevenção e gerenciamento"
 },
 {
  "id": "bz15-021",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 7",
  "enunciado": "(Certo ou Errado) A pessoa com TEA pode não obedecer a ordens nem ter noção do perigo em uma emergência.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 7 — placa “Autista a Bordo”."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 7 — placa “Autista a Bordo”.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 7"
 },
 {
  "id": "bz15-022",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 11",
  "enunciado": "(Certo ou Errado) O primeiro recurso de intervenção em crise agressiva deve ser a contenção física.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 11 — deve ser sempre a COMUNICAÇÃO."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 11 — deve ser sempre a COMUNICAÇÃO.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 11"
 },
 {
  "id": "bz15-023",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 12",
  "enunciado": "(Certo ou Errado) Meltdown e shutdown são crises idênticas, ambas explosivas e agressivas.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 12 — meltdown é explosivo; shutdown é interno, com retirada e paralisia."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 12 — meltdown é explosivo; shutdown é interno, com retirada e paralisia.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 12"
 },
 {
  "id": "bz15-024",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 9",
  "enunciado": "(Certo ou Errado) Pais e responsáveis conhecem melhor a pessoa com TEA que qualquer outra pessoa.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 9 — dicas no atendimento."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 9 — dicas no atendimento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 9"
 },
 {
  "id": "bz15-025",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 4",
  "enunciado": "(Certo ou Errado) O diagnóstico do autismo baseia-se no comportamento.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 4 — situação e contexto."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 4 — situação e contexto.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 4"
 },
 {
  "id": "bz15-026",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "Tópico 10",
  "enunciado": "(Certo ou Errado) É recomendado deixar materiais como tesouras ao alcance da pessoa com TEA para que ela se acalme.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 10 — não se deve deixar materiais ao alcance."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 10 — não se deve deixar materiais ao alcance.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, Tópico 10"
 },
 {
  "id": "bz15-027",
  "disc": "Atendimento à Pessoa com TEA",
  "assunto": "contenção em crise agressiva (reforço)",
  "enunciado": "No atendimento a uma pessoa com TEA em crise agressiva, o primeiro recurso de intervenção, antes de qualquer tipo de contenção, deve ser:",
  "alts": [
   {
    "t": "a comunicação.",
    "ok": true
   },
   {
    "t": "a contenção química."
   },
   {
    "t": "a contenção física com equipe numerosa."
   },
   {
    "t": "a contenção mecânica."
   }
  ],
  "resolucao": "==Gabarito: a comunicação.== Tópico 11 — contenção em crise agressiva (reforço).",
  "base": "Resumão CFS-31 Só Bizu, Módulo 15, contenção em crise agressiva (reforço)"
 }
]);
