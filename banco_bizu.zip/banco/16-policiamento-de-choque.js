/* Disciplina: Policiamento de Choque (34 questoes, Resumão CFS-31 Só Bizu). Cada questao: id, disc, assunto, enunciado, alts, resolucao, base. */
window.BANCO_PARTES = (window.BANCO_PARTES || []).concat([
 {
  "id": "bz16-001",
  "disc": "Policiamento de Choque",
  "assunto": "conceitos básicos",
  "enunciado": "O Policiamento Ostensivo Especializado de Choque emprega:",
  "alts": [
   {
    "t": "efetivo comum, sem equipamento específico."
   },
   {
    "t": "apenas viaturas de trânsito."
   },
   {
    "t": "efetivo especializado, com armamentos, munições e equipamentos específicos para o restabelecimento da ordem pública.",
    "ok": true
   },
   {
    "t": "somente agentes à paisana."
   }
  ],
  "resolucao": "==Gabarito: efetivo especializado, com armamentos, munições e equipamentos específicos para o restabelecimento da ordem pública.== Tópico 1 — conceitos básicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, conceitos básicos"
 },
 {
  "id": "bz16-002",
  "disc": "Policiamento de Choque",
  "assunto": "conceitos básicos",
  "enunciado": "O policiamento de choque tem caráter:",
  "alts": [
   {
    "t": "investigativo."
   },
   {
    "t": "administrativo."
   },
   {
    "t": "repressivo, suplementando o policiamento ostensivo geral no controle de massas.",
    "ok": true
   },
   {
    "t": "exclusivamente preventivo e assistencial."
   }
  ],
  "resolucao": "==Gabarito: repressivo, suplementando o policiamento ostensivo geral no controle de massas.== Tópico 1 — conceitos básicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, conceitos básicos"
 },
 {
  "id": "bz16-003",
  "disc": "Policiamento de Choque",
  "assunto": "grupamentos humanos",
  "enunciado": "A turba agressiva caracteriza-se por atos de violência, como ocorre em:",
  "alts": [
   {
    "t": "conflitos políticos e étnicos ou rebeliões prisionais.",
    "ok": true
   },
   {
    "t": "saques de mercados."
   },
   {
    "t": "eventos religiosos pacíficos."
   },
   {
    "t": "tentativas de fuga em pânico."
   }
  ],
  "resolucao": "==Gabarito: conflitos políticos e étnicos ou rebeliões prisionais.== Tópico 2 — grupamentos humanos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, grupamentos humanos"
 },
 {
  "id": "bz16-004",
  "disc": "Policiamento de Choque",
  "assunto": "grupamentos humanos",
  "enunciado": "A turba predatória tem por objetivo:",
  "alts": [
   {
    "t": "praticar violência política."
   },
   {
    "t": "buscar a fuga."
   },
   {
    "t": "negociar com a polícia."
   },
   {
    "t": "apoderar-se de materiais, como alimentos ou outros bens (saques).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: apoderar-se de materiais, como alimentos ou outros bens (saques).== Tópico 2 — grupamentos humanos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, grupamentos humanos"
 },
 {
  "id": "bz16-005",
  "disc": "Policiamento de Choque",
  "assunto": "grupamentos humanos",
  "enunciado": "A turba em pânico:",
  "alts": [
   {
    "t": "obedece às ordens."
   },
   {
    "t": "pratica saques."
   },
   {
    "t": "pratica violência deliberada."
   },
   {
    "t": "procura a fuga, sendo conduzida à destruição.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: procura a fuga, sendo conduzida à destruição.== Tópico 2 — grupamentos humanos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, grupamentos humanos"
 },
 {
  "id": "bz16-006",
  "disc": "Policiamento de Choque",
  "assunto": "fatores psicológicos",
  "enunciado": "São fatores psicológicos que influenciam as massas:",
  "alts": [
   {
    "t": "número, sugestão, contágio, anonimato, novidade, expansão das emoções reprimidas, imitação e influência das redes sociais.",
    "ok": true
   },
   {
    "t": "apenas o clima e o relevo."
   },
   {
    "t": "somente o tipo de armamento policial."
   },
   {
    "t": "exclusivamente a renda."
   }
  ],
  "resolucao": "==Gabarito: número, sugestão, contágio, anonimato, novidade, expansão das emoções reprimidas, imitação e influência das redes sociais.== Tópico 3 — fatores psicológicos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, fatores psicológicos"
 },
 {
  "id": "bz16-007",
  "disc": "Policiamento de Choque",
  "assunto": "gestão e administração de multidões",
  "enunciado": "A administração de multidões, em sua fase preventiva, consiste em:",
  "alts": [
   {
    "t": "uso imediato da força."
   },
   {
    "t": "dispersão da turba."
   },
   {
    "t": "restauração da ordem após a quebra."
   },
   {
    "t": "ações de recebimento e análise de informações e deliberações sobre ações preventivas.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: ações de recebimento e análise de informações e deliberações sobre ações preventivas.== Tópico 4 — gestão e administração de multidões.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, gestão e administração de multidões"
 },
 {
  "id": "bz16-008",
  "disc": "Policiamento de Choque",
  "assunto": "planejamento",
  "enunciado": "O planejamento, na administração de multidões, é o:",
  "alts": [
   {
    "t": "conjunto de ações no local para conter a turba."
   },
   {
    "t": "conjunto de processos e procedimentos prévios destinados à organização de ações estratégicas, táticas e operacionais.",
    "ok": true
   },
   {
    "t": "momento de negociar."
   },
   {
    "t": "ato de dispersar a massa."
   }
  ],
  "resolucao": "==Gabarito: conjunto de processos e procedimentos prévios destinados à organização de ações estratégicas, táticas e operacionais.== Tópico 4 — planejamento.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, planejamento"
 },
 {
  "id": "bz16-009",
  "disc": "Policiamento de Choque",
  "assunto": "controle de multidões",
  "enunciado": "O controle de multidões é o conjunto de procedimentos destinados a:",
  "alts": [
   {
    "t": "organizar eventos esportivos."
   },
   {
    "t": "restaurar a ordem pública quebrada pela ação da turba.",
    "ok": true
   },
   {
    "t": "registrar ocorrências de trânsito."
   },
   {
    "t": "prevenir o planejamento da operação."
   }
  ],
  "resolucao": "==Gabarito: restaurar a ordem pública quebrada pela ação da turba.== Tópico 5 — controle de multidões.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, controle de multidões"
 },
 {
  "id": "bz16-010",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção indireta",
  "enunciado": "A ação de presença, na intervenção indireta, consiste em:",
  "alts": [
   {
    "t": "repelir a massa."
   },
   {
    "t": "dispor efetivo no local para transmitir sensação de segurança, colher informações, identificar interlocutores e dissuadir comportamentos.",
    "ok": true
   },
   {
    "t": "prender lideranças imediatamente."
   },
   {
    "t": "dispersar a multidão."
   }
  ],
  "resolucao": "==Gabarito: dispor efetivo no local para transmitir sensação de segurança, colher informações, identificar interlocutores e dissuadir comportamentos.== Tópico 5.1 — intervenção indireta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção indireta"
 },
 {
  "id": "bz16-011",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção indireta",
  "enunciado": "“Conter”, na intervenção indireta, significa:",
  "alts": [
   {
    "t": "manter a multidão em uma área delimitada por efetivo policial ou estruturas físicas (grades, viaturas).",
    "ok": true
   },
   {
    "t": "retirá-la definitivamente."
   },
   {
    "t": "seguir a passeata."
   },
   {
    "t": "dividir a massa."
   }
  ],
  "resolucao": "==Gabarito: manter a multidão em uma área delimitada por efetivo policial ou estruturas físicas (grades, viaturas).== Tópico 5.1 — intervenção indireta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção indireta"
 },
 {
  "id": "bz16-012",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção indireta",
  "enunciado": "“Acompanhar” consiste em:",
  "alts": [
   {
    "t": "manter a multidão confinada."
   },
   {
    "t": "seguir uma passeata visando minimizar os efeitos da quebra da ordem.",
    "ok": true
   },
   {
    "t": "dispersar a massa."
   },
   {
    "t": "negociar com lideranças."
   }
  ],
  "resolucao": "==Gabarito: seguir uma passeata visando minimizar os efeitos da quebra da ordem.== Tópico 5.1 — intervenção indireta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção indireta"
 },
 {
  "id": "bz16-013",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção indireta",
  "enunciado": "“Negociar” é:",
  "alts": [
   {
    "t": "conter a multidão em área."
   },
   {
    "t": "usar munição de elastômero."
   },
   {
    "t": "repelir a massa."
   },
   {
    "t": "estabelecer vínculo de mediação com os manifestantes ou lideranças, tentando convencê-los a não prejudicar a ordem pública.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: estabelecer vínculo de mediação com os manifestantes ou lideranças, tentando convencê-los a não prejudicar a ordem pública.== Tópico 5.1 — intervenção indireta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção indireta"
 },
 {
  "id": "bz16-014",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção direta",
  "enunciado": "Repelir é a ação utilizada para:",
  "alts": [
   {
    "t": "retirar a massa definitivamente do local."
   },
   {
    "t": "negociar com líderes."
   },
   {
    "t": "acompanhar a passeata."
   },
   {
    "t": "recuar a massa em uma direção até um limite pré-definido, afastando-a temporariamente, permitindo a detenção de desordeiros.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: recuar a massa em uma direção até um limite pré-definido, afastando-a temporariamente, permitindo a detenção de desordeiros.== Tópico 5.2 — intervenção direta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção direta"
 },
 {
  "id": "bz16-015",
  "disc": "Policiamento de Choque",
  "assunto": "intervenção direta",
  "enunciado": "Dispersar é a ação que:",
  "alts": [
   {
    "t": "desloca a massa, dividindo-a, desagregando-a e enfraquecendo-a, com o objetivo de retirada definitiva do local.",
    "ok": true
   },
   {
    "t": "transmite sensação de segurança."
   },
   {
    "t": "afasta a massa apenas temporariamente."
   },
   {
    "t": "mantém a massa em área delimitada."
   }
  ],
  "resolucao": "==Gabarito: desloca a massa, dividindo-a, desagregando-a e enfraquecendo-a, com o objetivo de retirada definitiva do local.== Tópico 5.2 — intervenção direta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, intervenção direta"
 },
 {
  "id": "bz16-016",
  "disc": "Policiamento de Choque",
  "assunto": "dissuadir",
  "enunciado": "Dissuadir é o ato de:",
  "alts": [
   {
    "t": "acompanhar a passeata."
   },
   {
    "t": "conter a multidão."
   },
   {
    "t": "dispersar a massa."
   },
   {
    "t": "desestimular líderes ou integrantes a não praticarem atos que quebrem a ordem, na transição entre a intervenção indireta e a direta.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: desestimular líderes ou integrantes a não praticarem atos que quebrem a ordem, na transição entre a intervenção indireta e a direta.== Tópico 5.3 — dissuadir.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, dissuadir"
 },
 {
  "id": "bz16-017",
  "disc": "Policiamento de Choque",
  "assunto": "constituição do pelotão de choque",
  "enunciado": "O Pelotão de Choque Padrão é composto de:",
  "alts": [
   {
    "t": "10 homens (mínimo 5)."
   },
   {
    "t": "100 homens."
   },
   {
    "t": "50 homens (mínimo 30)."
   },
   {
    "t": "30 homens (recomendável no mínimo 18).",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: 30 homens (recomendável no mínimo 18).== Tópico 6 — constituição do pelotão de choque.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, constituição do pelotão de choque"
 },
 {
  "id": "bz16-018",
  "disc": "Policiamento de Choque",
  "assunto": "constituição do pelotão de choque",
  "enunciado": "Deve-se evitar fixar número de escudeiros inferior a:",
  "alts": [
   {
    "t": "3."
   },
   {
    "t": "5."
   },
   {
    "t": "12.",
    "ok": true
   },
   {
    "t": "30."
   }
  ],
  "resolucao": "==Gabarito: 12.== Tópico 6 — constituição do pelotão de choque.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, constituição do pelotão de choque"
 },
 {
  "id": "bz16-019",
  "disc": "Policiamento de Choque",
  "assunto": "fatores antes da ação",
  "enunciado": "No planejamento da desobstrução de vias, deve-se observar, antes da ação:",
  "alts": [
   {
    "t": "exclusivamente a opinião da imprensa."
   },
   {
    "t": "apenas o horário."
   },
   {
    "t": "o local obstruído, o número e perfil dos causadores, a forma de obstrução, as condições climáticas e a presença de pessoas não envolvidas.",
    "ok": true
   },
   {
    "t": "somente a quantidade de munição."
   }
  ],
  "resolucao": "==Gabarito: o local obstruído, o número e perfil dos causadores, a forma de obstrução, as condições climáticas e a presença de pessoas não envolvidas.== Tópico 7 — fatores antes da ação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, fatores antes da ação"
 },
 {
  "id": "bz16-020",
  "disc": "Policiamento de Choque",
  "assunto": "fatores na ação",
  "enunciado": "Entre os fatores observados na ação de desobstrução está:",
  "alts": [
   {
    "t": "a demonstração de força desde a chegada (desembarque tático e disciplina).",
    "ok": true
   },
   {
    "t": "o uso indiscriminado de munição."
   },
   {
    "t": "o desembarque desordenado."
   },
   {
    "t": "a ausência de ordem de desobstrução."
   }
  ],
  "resolucao": "==Gabarito: a demonstração de força desde a chegada (desembarque tático e disciplina).== Tópico 7 — fatores na ação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, fatores na ação"
 },
 {
  "id": "bz16-021",
  "disc": "Policiamento de Choque",
  "assunto": "fatores na ação",
  "enunciado": "A munição de elastômero (impacto controlado), na desobstrução, é usada:",
  "alts": [
   {
    "t": "contra pessoas pacíficas."
   },
   {
    "t": "como instrumento de punição."
   },
   {
    "t": "de forma indiscriminada contra todos."
   },
   {
    "t": "de forma pontual, para reprimir os autores que atentem contra policiais ou terceiros.",
    "ok": true
   }
  ],
  "resolucao": "==Gabarito: de forma pontual, para reprimir os autores que atentem contra policiais ou terceiros.== Tópico 7 — fatores na ação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, fatores na ação"
 },
 {
  "id": "bz16-022",
  "disc": "Policiamento de Choque",
  "assunto": "atuação conjunta",
  "enunciado": "Na atuação conjunta, o Policiamento Ordinário, que já está presente quando chega a Tropa de Choque:",
  "alts": [
   {
    "t": "avança à frente da Tropa de Choque."
   },
   {
    "t": "dispensa a integração."
   },
   {
    "t": "faz a segurança dos locais já dominados, avançando à retaguarda da Tropa de Choque (resgate e captura de infratores).",
    "ok": true
   },
   {
    "t": "abandona o local."
   }
  ],
  "resolucao": "==Gabarito: faz a segurança dos locais já dominados, avançando à retaguarda da Tropa de Choque (resgate e captura de infratores).== Tópico 7 — atuação conjunta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, atuação conjunta"
 },
 {
  "id": "bz16-023",
  "disc": "Policiamento de Choque",
  "assunto": "resistência passiva",
  "enunciado": "Diante de resistência passiva na desobstrução, deve-se:",
  "alts": [
   {
    "t": "ignorar a ocorrência."
   },
   {
    "t": "partir para o confronto imediato."
   },
   {
    "t": "evitar o confronto direto, usando técnicas de menor potencial ofensivo e evitando “criar a ocorrência”.",
    "ok": true
   },
   {
    "t": "usar força letal."
   }
  ],
  "resolucao": "==Gabarito: evitar o confronto direto, usando técnicas de menor potencial ofensivo e evitando “criar a ocorrência”.== Tópico 7 — resistência passiva.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, resistência passiva"
 },
 {
  "id": "bz16-024",
  "disc": "Policiamento de Choque",
  "assunto": "pós-operação",
  "enunciado": "Após a desobstrução, a Tropa de Choque:",
  "alts": [
   {
    "t": "mantém a guarda para evitar o retorno dos manifestantes e permitir a limpeza da via; depois o Policiamento de Área reassume.",
    "ok": true
   },
   {
    "t": "retira-se imediatamente."
   },
   {
    "t": "inicia nova operação."
   },
   {
    "t": "dispersa a imprensa."
   }
  ],
  "resolucao": "==Gabarito: mantém a guarda para evitar o retorno dos manifestantes e permitir a limpeza da via; depois o Policiamento de Área reassume.== Tópico 7 — pós-operação.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, pós-operação"
 },
 {
  "id": "bz16-025",
  "disc": "Policiamento de Choque",
  "assunto": "reintegração de posse",
  "enunciado": "Na reintegração de posse, a “ameaça” é:",
  "alts": [
   {
    "t": "a invasão consumada."
   },
   {
    "t": "o risco real e iminente de que a posse será violada, sem ato concreto ainda.",
    "ok": true
   },
   {
    "t": "a privação do poder de fato sobre a coisa."
   },
   {
    "t": "o ato que embaraça o exercício da posse."
   }
  ],
  "resolucao": "==Gabarito: o risco real e iminente de que a posse será violada, sem ato concreto ainda.== Tópico 8 — reintegração de posse.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, reintegração de posse"
 },
 {
  "id": "bz16-026",
  "disc": "Policiamento de Choque",
  "assunto": "reintegração de posse",
  "enunciado": "A turbação é:",
  "alts": [
   {
    "t": "a regularização da posse."
   },
   {
    "t": "o ato que embaraça o livre exercício da posse (perturbação da posse tranquila).",
    "ok": true
   },
   {
    "t": "o risco de violação futura."
   },
   {
    "t": "a privação violenta da posse."
   }
  ],
  "resolucao": "==Gabarito: o ato que embaraça o livre exercício da posse (perturbação da posse tranquila).== Tópico 8 — reintegração de posse.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, reintegração de posse"
 },
 {
  "id": "bz16-027",
  "disc": "Policiamento de Choque",
  "assunto": "reintegração de posse",
  "enunciado": "O esbulho é:",
  "alts": [
   {
    "t": "o ato pelo qual alguém priva outra pessoa do poder de fato sobre a coisa (violenta, clandestina ou com abuso de confiança).",
    "ok": true
   },
   {
    "t": "o risco iminente de violação."
   },
   {
    "t": "a perturbação da posse tranquila."
   },
   {
    "t": "o registro em cartório."
   }
  ],
  "resolucao": "==Gabarito: o ato pelo qual alguém priva outra pessoa do poder de fato sobre a coisa (violenta, clandestina ou com abuso de confiança).== Tópico 8 — reintegração de posse.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, reintegração de posse"
 },
 {
  "id": "bz16-028",
  "disc": "Policiamento de Choque",
  "assunto": "atuação da PM",
  "enunciado": "Na reintegração de posse, a PM atua em situações de flagrante para:",
  "alts": [
   {
    "t": "substituir o juiz na decisão da posse."
   },
   {
    "t": "decidir sobre a propriedade do imóvel."
   },
   {
    "t": "preservar a ordem pública, conter a violência e impedir que um crime se concretize.",
    "ok": true
   },
   {
    "t": "cobrar indenização."
   }
  ],
  "resolucao": "==Gabarito: preservar a ordem pública, conter a violência e impedir que um crime se concretize.== Tópico 8 — atuação da PM.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, atuação da PM"
 },
 {
  "id": "bz16-029",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 2",
  "enunciado": "(Certo ou Errado) O tumulto é uma desordem de pequena proporção, que pode surgir de forma inopinada ou não.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 2 — grupamentos humanos."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 2 — grupamentos humanos.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 2"
 },
 {
  "id": "bz16-030",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 4/5",
  "enunciado": "(Certo ou Errado) A fase preventiva da gestão de multidões é o controle de multidões.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 4/5 — preventiva = administração; controle = restauração da ordem quebrada."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 4/5 — preventiva = administração; controle = restauração da ordem quebrada.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 4/5"
 },
 {
  "id": "bz16-031",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 5.1",
  "enunciado": "(Certo ou Errado) A intervenção indireta compreende presença, contenção, acompanhamento e negociação.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5.1 — intervenção indireta."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5.1 — intervenção indireta.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 5.1"
 },
 {
  "id": "bz16-032",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 5.2",
  "enunciado": "(Certo ou Errado) Repelir tem o objetivo de retirar a massa definitivamente do local.",
  "alts": [
   {
    "t": "Certo",
    "erro": "Certo",
    "motivo": "Tópico 5.2 — repelir afasta temporariamente; a retirada definitiva é a dispersão."
   },
   {
    "t": "Errado",
    "ok": true
   }
  ],
  "resolucao": "A afirmação está ==ERRADA==. Tópico 5.2 — repelir afasta temporariamente; a retirada definitiva é a dispersão.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 5.2"
 },
 {
  "id": "bz16-033",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 5.3",
  "enunciado": "(Certo ou Errado) Dissuadir caracteriza o momento de transição entre a intervenção indireta e a direta.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 5.3 — dissuadir."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 5.3 — dissuadir.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 5.3"
 },
 {
  "id": "bz16-034",
  "disc": "Policiamento de Choque",
  "assunto": "Tópico 8",
  "enunciado": "(Certo ou Errado) Na reintegração de posse, a PM atua em situações de flagrante para impedir que um crime (invasão, ameaça ou agressão) se concretize.",
  "alts": [
   {
    "t": "Certo",
    "ok": true
   },
   {
    "t": "Errado",
    "erro": "Errado",
    "motivo": "Tópico 8 — atuação da PM."
   }
  ],
  "resolucao": "A afirmação está ==CERTA==. Tópico 8 — atuação da PM.",
  "base": "Resumão CFS-31 Só Bizu, Módulo 16, Tópico 8"
 }
]);
