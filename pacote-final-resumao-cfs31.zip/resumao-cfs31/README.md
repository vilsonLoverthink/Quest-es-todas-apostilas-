# Resumão CFS-31 — Só Bizu da Prova

Material de estudo reformatado a partir da apostila escaneada de 168 páginas (16 módulos), com banco de questões.

## Arquivos
| Arquivo | Conteúdo |
|---|---|
| `Resumao_CFS31_Apostila_Completa.pdf` / `.docx` | Apostila reformatada: 16 módulos, 211 páginas, grifos coloridos, 344 questões com gabarito em miniatura de cabeça para baixo |
| `Banco_de_Questoes_CFS31.pdf` / `.docx` | Banco de questões: 1.044 questões únicas (815 múltipla escolha, 229 Certo/Errado), 355 páginas |
| `questoes_bizu_importar_v2.json` | Banco no formato de importação (`id`, `disc`, `assunto`, `enunciado`, `alts`, `resolucao`, `base`) |

## Origem das questões do banco
- 526 do Banco Bizu (enviado) · 307 novas · 211 adaptadas dos cadernos da apostila.
- Questões repetidas ou quase iguais foram removidas.

## Limitações conhecidas
- O texto veio de OCR; trechos duvidosos foram conferidos na imagem, mas não página por página.
- A alternativa correta ainda é a mais longa em cerca de 50% das questões de múltipla escolha (era 78%).
- Os cadernos de questões originais não estão anexados na forma original.
- A importação do JSON no aplicativo não foi testada.
